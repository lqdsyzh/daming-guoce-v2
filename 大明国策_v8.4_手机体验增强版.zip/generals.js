// ============================================
// 《大明国策》v8.3 明代名将库
// 按年代分池（卒于开局前者不入）· 统率/忠心/兵种/专长/对敌加成
// 史据：《明史》卷95·兵志 / 卷171·王越传 / 卷195·王守仁传 / 卷198·杨一清传 /
//       卷222·谭纶传 / 卷238·戚继光传 / 卷242·俞大猷传 / 卷247·刘綎邓子龙传 /
//       卷250·孙承宗传 / 卷258·卢象升传 / 卷259·袁崇焕洪承畴传 / 卷262·孙传庭传 /
//       卷271·满桂传 / 卷309·李自成传 / 卷328·流贼传
// 铁律：名将有专长，择将与兵种相配方见其效
// ============================================

(function () {
    'use strict';
    if (window._v83Generals) return;
    window._v83Generals = true;

    // bonus: 对特定敌国的战力加成（作用进战场）
    // terrainBonus: 对特定地形的加成
    var GENERALS = {
        chenghua: [
            { name: '王越', ability: 88, loyalty: 75, arm: 'cav',
              tags: ['捣巢', '轻骑', '兼督'], bonus: { mongol: 1.18 }, terrainBonus: {},
              src: '《明史》卷171·王越传：红盐池之捷，两昼夜行八百里，捣其老营，获妇女驼马数十万。' },
            { name: '朱永', ability: 76, loyalty: 70, arm: 'line',
              tags: ['将门', '守御'], bonus: {}, terrainBonus: {},
              src: '《明史》·朱永传：将门世胄，成化朝屡佩将军印，积功封保国公。' },
            { name: '赵辅', ability: 70, loyalty: 65, arm: 'line',
              tags: ['抚蛮'], bonus: {}, terrainBonus: {},
              src: '《明史》·赵辅传：成化初佩征蛮将军印，与都御史韩雍定大藤峡。' }
        ],
        zhengde: [
            { name: '仇钺', ability: 74, loyalty: 70, arm: 'line',
              tags: ['缚反', '持重'], bonus: {}, terrainBonus: {},
              src: '《明史》·仇钺传：正德五年安化王寘鐇反，钺阳附而阴为内应，遂擒寘鐇。' },
            { name: '王守仁', ability: 92, loyalty: 80, arm: 'line',
              tags: ['神机', '抚降', '速战'], bonus: {}, terrainBonus: {},
              src: '《明史》卷195·王守仁传：宁王宸濠反，守仁躬率乌合之众，四十日而成擒。' },
            { name: '杨一清', ability: 85, loyalty: 75, arm: 'line',
              tags: ['总制三边', '练卒筑垒', '理财'], bonus: { mongol: 1.10 }, terrainBonus: {},
              src: '《明史》卷198·杨一清传：总制三边，练卒筑垒；后与太监张永合谋除刘瑾。' }
        ],
        jiajing: [
            { name: '戚继光', ability: 95, loyalty: 82, arm: 'firearm',
              tags: ['鸳鸯阵', '练兵', '治军严明', '筑城敌台', '车营'],
              bonus: { wokou: 1.45, annam: 1.15 }, terrainBonus: { coast: 1.18, hill: 1.12 },
              src: '《明史》卷238·戚继光传：嘉靖四十年台州九战九捷（花街斩首三百零八级，我军阵亡三人）；横屿斩倭二千六百余；隆庆二年总理蓟州，万历元至三年筑空心敌台千三百三十七座，造战车千一百零九辆。' },
            { name: '俞大猷', ability: 90, loyalty: 78, arm: 'navy',
              tags: ['水战', '御敌于海', '兵车营', '火攻'],
              bonus: { wokou: 1.30, annam: 1.12 }, terrainBonus: { coast: 1.22 },
              src: '《明史》卷242·俞大猷传：嘉靖三十四年王江泾大捷，斩首一千九百余级，为自有倭患以来第一功；隆庆三年广西古田夜擒韦银豹，斩首八千四百余。' },
            { name: '谭纶', ability: 82, loyalty: 78, arm: 'line',
              tags: ['节制调度', '募兵', '筑敌台', '文帅'],
              bonus: { wokou: 1.12 }, terrainBonus: {},
              src: '《明史》卷222·谭纶传：嘉靖四十二年主平海卫之捷；隆庆二年任蓟辽总督，修筑居庸关至山海关敌台三千座，募浙兵九千余。' },
            { name: '胡宗宪', ability: 86, loyalty: 70, arm: 'line',
              tags: ['七省经略', '用间', '抚倭', '-platform 款贡'],
              bonus: { wokou: 1.18 }, terrainBonus: {},
              src: '《明史》·胡宗宪传：总督浙直七省经略，平台款贡，抚降汪直、徐海之众。' },
            { name: '朱纨', ability: 72, loyalty: 85, arm: 'navy',
              tags: ['严海禁', '整饬海防'], bonus: { wokou: 1.10 }, terrainBonus: {},
              src: '《明史》卷205·朱纨传：嘉靖二十六年整饬海防，斩倭首。' },
            { name: '卢镗', ability: 78, loyalty: 72, arm: 'navy',
              tags: ['水战', '协战'], bonus: { wokou: 1.14 }, terrainBonus: {},
              src: '《明史》·卢镗传：王江泾之役与俞大猷协力，斩首一千九百余级；后参战桃渚、平海卫。' },
            { name: '侯继高', ability: 74, loyalty: 70, arm: 'navy',
              tags: ['海防', '伏兵', '长江口'], bonus: { wokou: 1.12 }, terrainBonus: {},
              src: '《明史》·侯继高传：守松江崇明，屡破倭船。' },
            { name: '柯海', ability: 76, loyalty: 68, arm: 'line',
              tags: ['攻巢', '合击'], bonus: { wokou: 1.10 }, terrainBonus: {},
              src: '《明史》·柯海传：嘉靖末平海卫之役与戚继光、俞大猷合击，生擒倭酋。' },
            { name: '许朝光', ability: 72, loyalty: 72, arm: 'line',
              tags: ['狼兵', '山地战', '招抚'], bonus: { wokou: 1.08 }, terrainBonus: { mount: 1.15 },
              src: '《明史》·许朝光传：率处州、温州狼兵抗倭，斩获甚众。' },
            { name: '刘显', ability: 80, loyalty: 68, arm: 'line',
              tags: ['攻坚', '持重'], bonus: {}, terrainBonus: {},
              src: '《明史》·刘显传：嘉靖四十二年平海卫之役左路军；谭纶评其作战精悍勇猛，俞大猷不如刘显。' }
        ],
        wanli: [
            { name: '李成梁', ability: 92, loyalty: 62, arm: 'cav',
              tags: ['辽东铁骑', '家丁', '斩首', '拓边'],
              bonus: { mongol: 1.35, jurchen: 1.20 }, terrainBonus: { plain: 1.12 },
              src: '《明史》卷238·李成梁传：镇辽东三十年，先后奏大捷十次；万历二年捣王杲古勒寨，斩首千余、擒王杲；万历十一年攻阿台，塔克世、觉昌安死于阵中；拓边七百里，筑宽甸六堡。《明史》评「边帅武功之盛，两百年來所未有」。' },
            { name: '李如松', ability: 90, loyalty: 70, arm: 'cav',
              tags: ['骑战', '攻坚', '督战', '宁夏平哱拜'],
              bonus: { mongol: 1.22 }, terrainBonus: {},
              src: '《明史》卷238·李如松传：宁夏之役主将，平哱拜之乱；朝鲜之役平稷山、克开城、夺王京。' },
            { name: '麻贵', ability: 84, loyalty: 66, arm: 'cav',
              tags: ['骑战', '伏兵', '突击'], bonus: { mongol: 1.15 }, terrainBonus: {},
              src: '《明史》卷238·麻贵传：朝鲜之役东路主将，与陈璘水师配合；曾任登莱、蓟镇总兵。' },
            { name: '刘綎', ability: 88, loyalty: 68, arm: 'cav',
              tags: ['巨刀', '伏兵', '督战', '抚降'],
              bonus: { mongol: 1.18, tusi: 1.20 }, terrainBonus: { mount: 1.15 },
              src: '《明史》卷247·刘綎传：平缅、平罗雄首功五十余级而抚降万余；平播州八道分兵，斩首一千六百余、俘七百三十余；萨尔浒东路主将，兵四万深入三百里战死；用镔铁刀百二十斤，世称「刘大刀」。' },
            { name: '邓子龙', ability: 82, loyalty: 76, arm: 'navy',
              tags: ['水战', '督战', '伏兵'], bonus: { wokou: 1.20, annam: 1.15 }, terrainBonus: { coast: 1.15 },
              src: '《明史》卷247·邓子龙传：万历初从父刘显讨九丝蛮先登擒酋；缅甸之役斩罕虔于姚关；朝鲜之役攻晋州，误中枪丸死，年五十二。' },
            { name: '杜松', ability: 80, loyalty: 74, arm: 'line',
              tags: ['攻坚', '督战', '伏兵'], bonus: { jurchen: 1.15 }, terrainBonus: {},
              src: '《明史》·杜松传：萨尔浒东路主将，率兵三万渡浑河攻吉林崖，中伏力战而死。' },
            { name: '马林', ability: 76, loyalty: 60, arm: 'cav',
              tags: ['骑战', '筑城'], bonus: { mongol: 1.12 }, terrainBonus: {},
              src: '《明史》·马林传：宁夏哱拜之役主帅，兵败被俘；萨尔浒西路主将，兵溃。' },
            { name: '袁崇焕', ability: 88, loyalty: 75, arm: 'firearm',
              tags: ['红夷大炮', '守城', '督战', '筑城'],
              bonus: { jurchen: 1.20, mongol: 1.10 }, terrainBonus: { pass: 1.20, hill: 1.10 },
              src: '《明史》卷259·袁崇焕传：天启六年宁远大捷，城上十一门红夷大炮，三日激战后金伤亡一万七千余，努尔哈赤退走；天启七年宁锦大捷；崇祯三年以十二条罪磔于西市。' },
            { name: '满桂', ability: 82, loyalty: 70, arm: 'cav',
              tags: ['蒙古骑兵', '守城', '督战'], bonus: { mongol: 1.20 }, terrainBonus: { pass: 1.12 },
              src: '《明史》卷271·满桂传：天启六年与袁崇焕共守宁远；崇祯二年己巳之变率五千骑勤王，苦战重伤，兵败死于阵。' },
            { name: '孙承宗', ability: 90, loyalty: 85, arm: 'line',
              tags: ['筑城', '练兵十万', '关宁锦防线', '文帅'],
              bonus: { jurchen: 1.12 }, terrainBonus: { pass: 1.15 },
              src: '《明史》卷250·孙承宗传：督师蓟辽，筑宁远城、练兵十万，主持宁远、锦州、塔山三城防线。' },
            { name: '熊廷弼', ability: 86, loyalty: 58, arm: 'line',
              tags: ['整军', '筹饷', '守为主'], bonus: { jurchen: 1.10 }, terrainBonus: {},
              src: '《明史》卷259·熊廷弼传：辽东经略，以守为主替代李成梁的攻为主；身殁传首。' },
            { name: '方逢时', ability: 78, loyalty: 72, arm: 'line',
              tags: ['总督调度', '开中制', '边政'], bonus: {}, terrainBonus: {},
              src: '《明史》卷241·方逢时传：隆庆和议主和之人，与王崇古、高拱共办俺答封贡。' },
            { name: '陈璘', ability: 80, loyalty: 72, arm: 'navy',
              tags: ['水战', '楼船', '火器'], bonus: { wokou: 1.18, annam: 1.12 }, terrainBonus: { coast: 1.15 },
              src: '《明史》卷247·陈璘传：万历朝鲜之役专将水兵，与刘綎陆军夹攻石曼子舟师于海中。' }
        ],
        tianqi: [
            { name: '祖宽', ability: 80, loyalty: 66, arm: 'cav',
              tags: ['骁勇', '伏兵', '突击'], bonus: { annam: 1.10 }, terrainBonus: {},
              src: '《明史》·祖宽传：崇祯六年救莱州；破张献忠于嵩县九皋山斩馘九百余，破汝州斩馘一千六百余。' },
            { name: '侯恂', ability: 74, loyalty: 70, arm: 'line',
              tags: ['练兵', '守河防'], bonus: {}, terrainBonus: {},
              src: '《明史》·侯恂传：任河南巡抚，练兵筑垒，御流寇。' }
        ],
        chongzhen: [
            { name: '孙传庭', ability: 92, loyalty: 80, arm: 'line',
              tags: ['屯田足食', '抚降', '督战', '秦兵'],
              bonus: { panjun: 1.25 }, terrainBonus: { plain: 1.10, basin: 1.12 },
              src: '《明史》卷262·孙传庭传：崇祯九年破高迎祥于盩啡，迎祥被擒磔死；十一年与曹变蛟大战李自成二十七日，自成引残卒入塞；十五年督师收复洛阳、郏县、宝丰；十六年出师潼关，雨败，父子俱殁。' },
            { name: '左良玉', ability: 78, loyalty: 48, arm: 'cav',
              tags: ['抚降', '拥兵自重', '楚军'],
              bonus: { panjun: 1.10 }, terrainBonus: {},
              src: '《明史》·左良玉传：崇祯十三年破张献忠于玛瑙山，斩首一千三百余级、降将二十五人；崇祯十七年兵变入武汉。' },
            { name: '卢象升', ability: 88, loyalty: 85, arm: 'cav',
              tags: ['治军严明', '骑战', '屯田', '天雄军'],
              bonus: { panjun: 1.22 }, terrainBonus: { plain: 1.12 },
              src: '《明史》卢象升传：崇祯二年募兵一万入卫，整大名广平顺德三府兵备称天雄军；六年临城西山等连败贼，斩贼魁十一人、收还男女二万；宣大任上大兴屯田，储谷二十余万石；崇祯十二年巨鹿蒿水桥矢尽炮药竭，身中四箭三刀而死。流贼称「卢阎王」。' },
            { name: '黄得功', ability: 78, loyalty: 72, arm: 'firearm',
              tags: ['操舟', '火器', '督战', '南明四镇'],
              bonus: { panjun: 1.15 }, terrainBonus: {},
              src: '《明史》·黄得功传：崇祯十五年与刘良佐战张献忠于六安夹山岭，斩首万余，献忠填尸溢溪壑。' },
            { name: '洪承畴', ability: 84, loyalty: 58, arm: 'line',
              tags: ['抚降', '屯田', '调度'], bonus: { panjun: 1.15 }, terrainBonus: {},
              src: '《明史》卷259·洪承畴传：崇祯四年受降高迎祥部众，伏击斩降卒三百二十人；十一年追李自成入西羌；十五年松山城破被俘。' },
            { name: '杨文岳', ability: 76, loyalty: 78, arm: 'line',
              tags: ['守御', '督战'], bonus: { panjun: 1.08 }, terrainBonus: {},
              src: '《明史》卷262·杨文岳传：崇祯中任陕西巡抚、延绥；十五年随督师出关，城固一战中流矢死，追谥忠烈。' },
            { name: '曹变蛟', ability: 80, loyalty: 76, arm: 'cav',
              tags: ['突击', '督战', '追亡'], bonus: { panjun: 1.15 }, terrainBonus: {},
              src: '《明史》·曹变蛟传：崇祯十一年与贺人龙大战李自成二十七日，迫其入塞窜山。' },
            { name: '贺人龙', ability: 76, loyalty: 62, arm: 'cav',
              tags: ['骑战', '追击', '伏击'], bonus: { panjun: 1.10 }, terrainBonus: {},
              src: '《明史》·贺人龙传：崇祯四年伏击斩受降贼三百二十人；十三年破张献忠于玛瑙山得首级一千三百余；十五年被孙传庭斩于咸阳。' }
        ]
    };

    // ====== 流贼/叛军首脑（敌我用，可为叛军首领） ======
    var REBEL_LEADERS = [
        { name: '李自成', ability: 92, kind: 'liukou', src: '《明史》卷309·李自成传：崇祯三年米脂起义；十四年踞河洛，有众五十万；十六年克潼关、据西安建大顺；十七年正月入北京。' },
        { name: '张献忠', ability: 90, kind: 'liukou', src: '《明史》·张献忠传：崇祯三年聚众十八寨起；八年大破凤阳，屠中都、掘皇陵；十四年陷襄阳；十六年陷武昌称大西王；十七年破成都称帝。' },
        { name: '罗汝才', ability: 84, kind: 'liukou', src: '《明史》·罗汝才传：十二年受熊文灿招抚于郧阳；十三年与献忠陷襄阳；十四年北走合李自成，后为自成所杀。' },
        { name: '刘国能', ability: 80, kind: 'liukou', src: '《明史》·刘国能传：崇祯十年在河南归顺朝廷。' },
        { name: '马元利', ability: 78, kind: 'liukou', src: '《明史纪事本末》：张献忠建大西，设五军都督府，左军马元利。' },
        { name: '曹文诏', ability: 85, kind: 'liukou', src: '《明史》·曹文诏传：《明史》评其为明季流贼中最剽悍的官军将帅。' },
        { name: '白彦章', ability: 76, kind: 'liukou', src: '《明史》流贼传：白彦章为流贼头目之一。' },
        { name: '袁宗皋', ability: 78, kind: 'liukou', src: '《明史》·袁宗皋传：与李自成、罗汝才等并起于河南。' },
        { name: '贺锦', ability: 80, kind: 'liukou', src: '《明史》：革左五营之左金王；崇祯十五年与张献忠合于皖北，攻舒城、六安、庐州。' },
        { name: '盖勍', ability: 74, kind: 'liukou', src: '《明史》流贼传：盖勍为崇祯间陕西流贼头目。' }
    ];

    // ====== 兵种匹配加成 ======
    // 名将兵种与所出兵种相符，则战力加成
    var ARM_MATCH = { line: 1.10, cav: 1.10, firearm: 1.12, navy: 1.12 };

    // ====== 取候选 ======
    function candidates(scriptId) {
        try {
            var out = [];
            var sid = scriptId || (GameState && GameState.script ? GameState.script.id : 'chenghua');
            var order = ['chenghua', 'zhengde', 'jiajing', 'wanli', 'tianqi', 'chongzhen'];
            // 年代：只取「剧本年代及以后」的名将（已故者不入）
            var startIdx = order.indexOf(sid);
            if (startIdx < 0) startIdx = 0;
            for (var i = startIdx; i < order.length; i++) {
                (GENERALS[order[i]] || []).forEach(function (g) {
                    out.push({
                        key: 'v83:' + g.name,
                        name: g.name,
                        ability: g.ability,
                        loyalty: g.loyalty,
                        arm: g.arm,
                        tags: g.tags,
                        bonus: g.bonus,
                        terrainBonus: g.terrainBonus,
                        src: g.src,
                        source: 'v83',
                        cat: 'military'
                    });
                });
            }
            return out;
        } catch (e) { return []; }
    }

    // ====== 敌国 → 兵种（用于加成计算） ======
    function enemyKindOf(pow) {
        return ({ mongol: 'mongol', tatar: 'oirat', jurchen: 'jurchen',
                  wokou: 'wokou', annam: 'annam', tusi: 'tusi', tibet: 'tibetan',
                  haixi: 'jurchen', yeren: 'jurchen', turpan: 'annam',
                  hami: 'oirat', sixi: 'annam', qinghai: 'mongol' })[pow] || 'beilu';
    }

    // ====== 计算某将对此敌的加成 ======
    function bonusFor(gen, pow, terrainKey) {
        var m = 1;
        try {
            if (!gen) return m;
            if (gen.bonus && gen.bonus[pow]) m *= gen.bonus[pow];
            else if (gen.bonus && gen.bonus[enemyKindOf(pow)]) m *= gen.bonus[enemyKindOf(pow)];
            if (gen.terrainBonus && terrainKey && gen.terrainBonus[terrainKey]) m *= gen.terrainBonus[terrainKey];
            // 兵种匹配：将军所长与主战兵种相合
            if (gen.arm && ARM_MATCH[gen.arm]) m *= ARM_MATCH[gen.arm];
        } catch (e) {}
        return m;
    }

    window.GENERALS = {
        POOL: GENERALS,
        REBEL_LEADERS: REBEL_LEADERS,
        candidates: candidates,
        bonusFor: bonusFor,
        enemyKindOf: enemyKindOf,
        ARM_MATCH: ARM_MATCH
    };

    console.log('✓ v8.3 明代名将库已装载（' + Object.keys(GENERALS).length + ' 个年代池 · ' +
        Object.keys(GENERALS).reduce(function (a, k) { return a + GENERALS[k].length; }, 0) + ' 名将）');
})();
