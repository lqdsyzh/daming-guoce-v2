// ============================================
// 《大明国策》v7.1 御前速览
// 今日待办 · 快捷施政 · 数值播报
// 挂在首页顶部，操作一步到位，不跳页
// ============================================

(function () {
    'use strict';
    if (window._v71QuickInstalled) return;
    window._v71QuickInstalled = true;

    // ---- 快捷施政：每项都有真实代价与权衡 ----
    var QUICK_ACTS = [
        { id: 'tax_light',  icon: '轻', label: '轻徭薄赋', cost: 0,
          desc: '减税三成，民心+8 国库-1500',
          run: function () {
            G.s.treasury = Math.max(0, G.s.treasury - 1500);
            G.s.stability = cl(G.s.stability + 8);
            G.s.prestige = cl(G.s.prestige + 4);
            G.f.civil = cl(G.f.civil + 5);
            return '轻徭薄赋：国库 -1500两，民心 +8';
          }},
        { id: 'tax_heavy',  icon: '重', label: '加急追比', cost: 0,
          desc: '征税八成，国库+2500 民心-12',
          run: function () {
            G.s.treasury += 2500;
            G.s.stability = cl(G.s.stability - 12);
            G.s.publicOpinion = cl((G.s.publicOpinion||50) - 8);
            G.f.civil = cl(G.f.civil - 8);
            G.f.eunuch = cl(G.f.eunuch + 6);
            return '加急追比：国库 +2500两，民心 -12';
          }},
        { id: 'relief',     icon: '赈', label: '开仓赈济', cost: 800,
          desc: '散粟安民，费银800 稳定+6',
          run: function () {
            if (G.s.treasury < 800) return null;
            G.s.treasury -= 800;
            G.s.stability = cl(G.s.stability + 6);
            G.s.prestige = cl(G.s.prestige + 3);
            G.s.publicOpinion = cl((G.s.publicOpinion||50) + 6);
            return '开仓赈济：费银 800两，稳定 +6';
          }},
        { id: 'rite',       icon: '祀', label: '祭天祈谷', cost: 1200,
          desc: '郊祀天坛，费银1200 天命+5',
          run: function () {
            if (G.s.treasury < 1200) return null;
            G.s.treasury -= 1200;
            G.s.mandate = cl(G.s.mandate + 5);
            G.s.stability = cl(G.s.stability + 2);
            return '祭天祈谷：费银 1200两，天命 +5';
          }},
        { id: 'court_audit',icon: '审', label: '清查吏治', cost: 0,
          desc: '究赃蠹弊，腐败-10 民生-4',
          run: function () {
            G.s.corruption = Math.max(0, G.s.corruption - 10);
            G.s.adminEfficiency = cl(G.s.adminEfficiency + 5);
            G.s.stability = cl(G.s.stability - 4);
            G.f.civil = cl(G.f.civil - 4);
            return '清查吏治：腐败 -10，行政 +5（民怨 +4）';
          }},
        { id: 'jijiang',    icon: '募', label: '募兵练武', cost: 1500,
          desc: '募勇三千，费银1500 军力+600',
          run: function () {
            if (G.s.treasury < 1500) return null;
            G.s.treasury -= 1500;
            G.s.militaryPower = G.s.militaryPower + 600;
            G.s.militaryFood = Math.max(0, (G.s.militaryFood||0) - 300);
            G.f.military = cl(G.f.military + 8);
            return '募兵练武：费银 1500两，军力 +600';
          }},
        { id: 'edict_grand', icon: '赦', label: '大赦天下', cost: 0,
          desc: '减刑省狱，稳定+10 威望-3',
          run: function () {
            G.s.stability = cl(G.s.stability + 10);
            G.s.mandate = cl(G.s.mandate + 3);
            G.s.prestige = Math.max(0, G.s.prestige - 3);
            G.f.eunuch = cl(G.f.eunuch - 5);
            G.f.civil = cl(G.f.civil + 4);
            return '大赦天下：稳定 +10，天命 +3（威望 -3）';
          }},
        { id: 'tuntian',    icon: '屯', label: '兴修屯田', cost: 1000,
          desc: '募民实边，费银1000 粮+1200',
          run: function () {
            if (G.s.treasury < 1000) return null;
            G.s.treasury -= 1000;
            G.s.food = (G.s.food||0) + 1200;
            G.s.agriculture = cl(G.s.agriculture + 4);
            G.f.military = cl(G.f.military + 4);
            return '兴修屯田：费银 1000两，粮 +1200';
          }}
    ];

    var G = null;
    function bind() {
        G = { s: GameState.stats, f: GameState.factions };
    }
    function cl(v) { return Math.max(0, Math.min(100, Math.round(v))); }

    // ---- 今日待办（真实反映当前状态，不是摆设） ----
    function todayTasks() {
        var out = [];
        try {
            bind();
            if (typeof sanitizeStats === 'function') sanitizeStats();
            var s = G.s;

            // 1. 国库告罄
            if (num(s.treasury) < 2000) {
                out.push({ lv: 'crit', txt: '国库将竭（' + num(s.treasury) + '两），须筹财或轻赋', goto: 'econ' });
            }
            // 2. 粮荒
            if (num(s.food) < 1500) {
                out.push({ lv: 'crit', txt: '仓粮不足（' + num(s.food) + '石），春荒在即', goto: 'people' });
            }
            // 3. 稳定告急
            if (num(s.stability) < 35) {
                out.push({ lv: 'crit', txt: '社稷不稳（' + num(s.stability) + '），民变将起', goto: 'people' });
            }
            // 4. 派系跋扈
            var over = [];
            for (var k in G.f) {
                if (!G.f.hasOwnProperty(k)) continue;
                if (G.f[k] > 80) over.push(fName(k) + ' ' + Math.round(G.f[k]));
            }
            if (over.length) {
                out.push({ lv: 'warn', txt: '派系跋扈：' + over.join('、'), goto: 'court' });
            }
            // 5. 派系濒散
            var low = [];
            var mins = { civil: 40, military: 30, royal: 20, eunuch: 25, consort: 15 };
            for (var k2 in mins) {
                if (!mins.hasOwnProperty(k2)) continue;
                if (G.f[k2] < mins[k2]) low.push(fName(k2) + ' ' + Math.round(G.f[k2]));
            }
            if (low.length) {
                out.push({ lv: 'warn', txt: '派系离心：' + low.join('、'), goto: 'court' });
            }
            // 6. 腐败
            if (num(s.corruption) > 60) {
                out.push({ lv: 'warn', txt: '腐败 ' + num(s.corruption) + '，岁入锐减，宜清查', goto: 'econ' });
            }
            // 7. 天命
            if (num(s.mandate) < 40) {
                out.push({ lv: 'crit', txt: '天命衰微（' + num(s.mandate) + '），神器有危', goto: 'realm' });
            }
            // 8. 待决急奏
            var mq = (GameState.memorialQueue && GameState.memorialQueue.length) || 0;
            if (mq > 0) {
                out.push({ lv: mq > 3 ? 'crit' : 'warn', txt: '待决急奏 ' + mq + ' 件，宜速批', goto: 'war' });
            }
            // 9. 叛乱风险
            var rr = (typeof rebellionRisk === 'function') ? rebellionRisk() : (100 - num(s.stability)) / 100;
            if (rr > 0.35) {
                out.push({ lv: rr > 0.55 ? 'crit' : 'warn',
                          txt: '叛乱风险 ' + Math.round(rr * 100) + '%，宜安抚', goto: 'people' });
            }
            // 10. 边患
            if (GameState.milOps && GameState.milOps.threat > 60) {
                out.push({ lv: 'warn', txt: '边情告急，宜增戍', goto: 'war' });
            }
        } catch (e) {}
        if (out.length === 0) {
            out.push({ lv: 'ok', txt: '四海升平，暂无急务', goto: '' });
        }
        return out.slice(0, 6);
    }

    function fName(k) {
        return ({ civil: '文官', military: '武将', royal: '宗室', eunuch: '宦官', consort: '外戚' })[k] || k;
    }

    // ---- 渲染 ----
    function renderQuick() {
        try {
            bind();
            var tasks = todayTasks();

            var h = '<div class="v71-quick" id="v71-quick">';

            // 今日待办
            h += '<div class="v71-tasks">';
            for (var i = 0; i < tasks.length; i++) {
                var t = tasks[i];
                var click = t.goto ? ' onclick="v71Goto(\'' + t.goto + '\')"' : '';
                h += '<div class="v71-task v71-' + t.lv + '"' + click + '>'
                   + '<span class="v71-dot"></span>'
                   + '<span class="v71-txt">' + clean(t.txt, '—') + '</span>'
                   + (t.goto ? '<span class="v71-go">›</span>' : '')
                   + '</div>';
            }
            h += '</div>';

            // 快捷施政
            h += '<div class="v71-acts">';
            for (var j = 0; j < QUICK_ACTS.length; j++) {
                var a = QUICK_ACTS[j];
                var afford = !a.cost || num(G.s.treasury) >= a.cost;
                h += '<button class="v71-act' + (afford ? '' : ' poor') + '" '
                   + 'title="' + clean(a.desc, '') + '" '
                   + 'onclick="v71Act(\'' + a.id + '\')">'
                   + '<span class="v71-act-icon">' + a.icon + '</span>'
                   + '<span class="v71-act-label">' + a.label + '</span>'
                   + '</button>';
            }
            h += '</div>';

            h += '</div>';
            return h;
        } catch (e) {
            return '';
        }
    }

    // ---- 执行 ----
    window.v71Act = function (id) {
        try {
            bind();
            if (typeof sanitizeStats === 'function') sanitizeStats();
            for (var i = 0; i < QUICK_ACTS.length; i++) {
                if (QUICK_ACTS[i].id !== id) continue;
                var r = QUICK_ACTS[i].run();
                if (r === null) {
                    if (typeof pushNews === 'function') pushNews('内库', '国库不足，诏令未行。', 'critical');
                    else alert('国库不足');
                } else {
                    if (typeof pushNews === 'function') pushNews('圣裁', r, 'normal');
                }
                if (typeof v71Float === 'function') v71Float(QUICK_ACTS[i].label);
                break;
            }
            sanitizeStats();
            if (typeof homeRefresh === 'function') homeRefresh();
            if (typeof updateUI === 'function') { try { updateUI(); } catch (e) {} }
            if (typeof saveGame === 'function') { try { saveGame(); } catch (e) {} }
        } catch (e) {}
    };

    window.v71Goto = function (blk) {
        try {
            if (typeof homeGotoBlock === 'function') homeGotoBlock(blk);
        } catch (e) {}
    };

    // ---- 数字飘字反馈（手感） ----
    window.v71Float = function (label) {
        try {
            var host = document.getElementById('v71-quick');
            if (!host) return;
            var d = document.createElement('div');
            d.className = 'v71-float';
            d.textContent = clean(label, '') + ' · 已施行';
            host.appendChild(d);
            setTimeout(function () { if (d.parentNode) d.parentNode.removeChild(d); }, 1400);
        } catch (e) {}
    };

    // ---- 挂到首页 hero 下方 ----
    window.v71Render = function () { return renderQuick(); };
    window.v71Ensure = function () {
        try {
            var hero = document.getElementById('home-hero');
            if (!hero) return;
            var old = document.getElementById('v71-quick');
            if (old) old.parentNode.removeChild(old);
            var h = renderQuick();
            if (h) hero.insertAdjacentHTML('afterend', h);
        } catch (e) {}
    };

    console.log('✓ v7.1 御前速览已装载（今日待办 + 8项快捷施政）');
})();
