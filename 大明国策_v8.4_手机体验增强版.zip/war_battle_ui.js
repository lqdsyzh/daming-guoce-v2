// ============================================
// 《大明国策》v8.3 出师择将浮层
// 舆图上点敌国据点／叛军 → 选帅、定兵、核饷 → 列阵出战
// 复用 exp-paper 外壳，保持明代折子风格统一
// ============================================

(function () {
    'use strict';
    if (window._v83Wzb) return;
    window._v83Wzb = true;

    var SEL = { mode: 'zone', targetId: null, troops: 10000, genKey: '', gen: null, cost: { silver: 0, food: 0 }, from: null, terrain: null, city: 1, foe: null };

    var TROOP_OPTIONS = [5000, 10000, 20000, 30000, 50000];

    function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]; }); }

    // ====== 打开：攻敌国据点 ======
    function openZone(zoneId) {
        try {
            if (typeof WAR === 'undefined') return;
            var w = WAR.state();
            var z = null;
            w.zones.forEach(function (x) { if (x.id === zoneId) z = x; });
            if (!z) return;
            SEL.mode = 'zone';
            SEL.targetId = zoneId;
            SEL.foe = z;
            var ter = WAR.zoneTerrain(z);
            SEL.terrain = ter;
            SEL.city = 1.15;
            SEL.from = (typeof WARB !== 'undefined') ? WARB.nearestGarrison(z.lon, z.lat) : null;
            if (!SEL.from) { if (typeof pushNews === 'function') pushNews('兵部', '附近无可用之师，须先移师。', 'critical'); return; }
            SEL.troops = Math.min(10000, SEL.from.troops);
            SEL.genKey = ''; SEL.gen = null;
            render('兴师攻取 · ' + z.nm, WAR.ENEMY_POWERS[z.pow].nm + ' · ' + z.nm);
            open();
        } catch (e) {}
    }

    // ====== 打开：平叛 ======
    function openRebel(rebelId) {
        try {
            if (typeof WAR === 'undefined') return;
            var w = WAR.state();
            var r = null;
            w.rebels.forEach(function (x) { if (x.id === rebelId) r = x; });
            if (!r) return;
            SEL.mode = 'rebel';
            SEL.targetId = rebelId;
            SEL.foe = r;
            var ter = WAR.terrainOf(r.prov);
            SEL.terrain = ter;
            SEL.city = WAR.cityDefense(r.prov);
            var prov = null;
            if (typeof ATLAS_LIST !== 'undefined') ATLAS_LIST.forEach(function (x) { if (x.id === r.prov) prov = x; });
            SEL.from = (typeof WARB !== 'undefined') ? WARB.nearestGarrison(prov ? prov.lon : 116, prov ? prov.lat : 39) : null;
            if (!SEL.from) { if (typeof pushNews === 'function') pushNews('兵部', '附近无可用之师。', 'critical'); return; }
            SEL.troops = Math.min(10000, SEL.from.troops);
            SEL.genKey = ''; SEL.gen = null;
            render('兴师平叛 · ' + r.provNm, r.leader + '据' + r.provNm + '自守');
            open();
        } catch (e) {}
    }

    // ====== 选帅池（复用出师系统的候选） ======
    function candidates() {
        try {
            // v8.3：优先用明代名将库（含专长与对敌加成）
            if (typeof GENERALS !== 'undefined' && GENERALS.candidates) {
                var g = GENERALS.candidates();
                if (g && g.length) return g;
            }
            if (typeof expCandidates === 'function') return expCandidates();
        } catch (e) {}
        return [];
    }

    function pickGen(key) {
        SEL.genKey = key;
        SEL.gen = null;
        candidates().forEach(function (c) { if (c.key === key) SEL.gen = c; });
        render();
    }

    function setTroops(v) {
        SEL.troops = v;
        render();
    }

    // ====== 渲染 ======
    function render(title, sub) {
        try {
            var body = document.getElementById('wzb-body');
            if (!body) return;
            var tEl = document.getElementById('wzb-title');
            if (tEl && title) tEl.textContent = title;
            var sEl = document.getElementById('wzb-subtitle');
            if (sEl) sEl.textContent = sub || sEl.textContent;

            var from = SEL.from;
            var foe = SEL.foe;
            var ter = SEL.terrain || { nm: '平原', def: 1.0, desc: '' };

            // 敌情摘要
            var foeLine;
            if (SEL.mode === 'zone') {
                foeLine = '敌军 ' + num(foe.troops, 0) + ' 人　士气 ' + num(foe.morale, 0)
                    + '　补给 ' + num(foe.supply, 0)
                    + '　地形' + ter.nm + '（守方战力×' + ter.def.toFixed(2) + '）';
            } else {
                foeLine = '乱兵 ' + num(foe.troops, 0) + ' 人　士气 ' + num(foe.morale, 0)
                    + '　地形' + ter.nm + '（守方×' + ter.def.toFixed(2) + '，城防×' + SEL.city.toFixed(2) + '）';
            }

            // 饷粮估算
            var dist = from ? (Math.abs(from.lon - (foe.lon || 0)) + Math.abs(from.lat - (foe.lat || 0))) : 1;
            var months = SEL.mode === 'zone' ? Math.max(1, Math.round(dist * 0.8)) : Math.max(1, Math.round(dist * 0.6) + 1);
            var cost = (typeof WARB !== 'undefined') ? WARB.warCost(SEL.troops, months) : { silver: 0, food: 0 };
            SEL.cost = cost;

            var foePow = (SEL.mode === 'zone' && SEL.foe) ? SEL.foe.pow : null;
            var terKey = (typeof WAR !== 'undefined') ? WAR.terrainKey(SEL.mode === 'zone' ? (WAR.zoneProvOf ? WAR.zoneProvOf(SEL.foe) : 'beizhili') : SEL.foe.prov) : 'plain';
            var genCards = candidates().map(function (c) {
                var on = (SEL.genKey === c.key);
                var b = (typeof GENERALS !== 'undefined') ? GENERALS.bonusFor(c, foePow, terKey) : 1;
                var bonusTxt = (b > 1.02) ? ('　<b style="color:#e0b96a">对敌 ×' + b.toFixed(2) + '</b>') : '';
                return '<div class="exp-gen ' + (on ? 'exp-gen-on' : '') + '" onclick="wzbPickGen(\'' + c.key + '\')">'
                    + '<b>' + esc(c.name) + '</b>' + bonusTxt
                    + '<span class="exp-gen-src">统率 ' + num(c.ability, 60) + '　忠心 ' + num(c.loyalty, 60)
                    + (c.tags && c.tags.length ? '　' + esc(c.tags.join('·')) : '') + '</span>'
                    + '<span class="exp-gen-src">' + esc(c.src || '') + '</span>'
                    + '</div>';
            }).join('');

            var troopBtns = TROOP_OPTIONS.map(function (v) {
                var dis = (from && v > from.troops) ? ' disabled' : '';
                return '<button class="cw-btn exp-pay ' + (SEL.troops === v ? 'exp-pay-on' : '') + '"' + dis
                    + ' onclick="wzbSetTroops(' + v + ')">' + (v / 10000) + ' 万</button>';
            }).join('');

            var tre = num(GameState.stats.treasury, 0);
            var mfood = num(GameState.stats.militaryFood, 0);
            var lack = (cost.silver > tre || cost.food > mfood);

            body.innerHTML =
                '<div class="exp-step">'
                + '<div class="exp-step-title">一、敌情</div>'
                + '<div class="exp-factors">' + esc(foeLine) + '</div>'
                + '<div class="exp-step-note">' + esc(ter.desc || '') + '　出师：'
                + (from ? esc(from.nm) + '（现有 ' + num(from.troops, 0) + ' 人）' : '—') + '</div>'
                + '</div>'

                + '<div class="exp-step">'
                + '<div class="exp-step-title">二、选帅（名将视年代在册）</div>'
                + '<div class="exp-gen-list">' + (genCards || '<div class="exp-step-note">无可用之帅，当以羁縻之师出战。</div>') + '</div>'
                + '</div>'

                + '<div class="exp-step">'
                + '<div class="exp-step-title">三、定兵（自驻军抽调，出征即减）</div>'
                + '<div class="exp-pay-row">' + troopBtns + '</div>'
                + '</div>'

                + '<div class="exp-step">'
                + '<div class="exp-step-title">四、核饷</div>'
                + '<div class="exp-factors">转输 ' + months + ' 月　太仓银 ' + cost.silver + ' 两'
                + '（现有 ' + tre + '）　军粮 ' + cost.food + ' 石（现有 ' + mfood + '）</div>'
                + (lack ? '<div class="exp-step-note" style="color:#c86a5a">饷粮不足，须先筹措。</div>' : '')
                + '</div>'

                + '<div class="exp-dispatch-row">'
                + '<button class="exp-dispatch-btn" ' + (lack ? 'disabled' : '') + ' onclick="wzbDispatch()">列 阵 出 战</button>'
                + '<div class="exp-hint">开战即入回合制战场：布阵、定战术、察地形、决胜负。</div>'
                + '</div>';
        } catch (e) {}
    }

    // ====== 出战 ======
    function dispatch() {
        try {
            var r;
            if (SEL.mode === 'zone') r = WARB.openZoneBattle(SEL.targetId, SEL.troops, SEL.gen);
            else r = WARB.openRebelBattle(SEL.targetId, SEL.troops, SEL.gen);
            if (!r || !r.ok) {
                if (typeof pushNews === 'function') pushNews('兵部', r && r.msg ? r.msg : '战事不成', 'critical');
                return;
            }
            close();
        } catch (e) {}
    }

    function close() {
        try {
            var m = document.getElementById('wzb-modal');
            if (m) m.classList.remove('active');
        } catch (e) {}
    }

    function open() {
        try {
            var m = document.getElementById('wzb-modal');
            if (m) m.classList.add('active');
        } catch (e) {}
    }

    window.wzbPickGen = pickGen;
    window.wzbSetTroops = setTroops;
    window.wzbDispatch = dispatch;
    window.wzbClose = close;
    window.wzbOpenZone = openZone;
    window.wzbOpenRebel = openRebel;

    console.log('✓ v8.3 出师择将浮层已装载');
})();
