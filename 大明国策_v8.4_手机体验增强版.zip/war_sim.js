// ============================================
// 《大明国策》v8.2 战争模拟内核
// 敌国势力 · 地形 · 攻防公式 · 叛乱蔓延
// 铁律：数值必须干净，公式必须可验算
// ============================================

(function () {
    'use strict';
    if (window._v82WarInstalled) return;
    window._v82WarInstalled = true;

    // ====== 地形类型 ======
    // 每省一地形，影响攻防、补给、产出
    var TERRAIN = {
        plain:  { nm:'平原', atk:1.00, def:1.00, supply:1.00, food:1.00, desc:'四野平旷，利战不利守' },
        hill:   { nm:'丘陵', atk:0.88, def:1.18, supply:0.92, food:0.95, desc:'高阜相望，步骑难驰' },
        mount:  { nm:'山岳', atk:0.68, def:1.45, supply:0.72, food:0.70, desc:'万山重叠，一夫当关' },
        river:  { nm:'河网', atk:0.86, def:1.12, supply:1.30, food:1.25, desc:'水网纵横，舟楫代马' },
        pass:   { nm:'关隘', atk:0.62, def:1.70, supply:0.65, food:0.60, desc:'一夫当关，万夫莫开' },
        steppe: { nm:'草原', atk:1.30, def:0.82, supply:0.60, food:0.80, desc:'驰骑纵横，利出不利守' },
        coast:  { nm:'海疆', atk:0.92, def:1.08, supply:1.15, food:1.10, desc:'舟师往来，潮汐为助' },
        basin:  { nm:'盆地', atk:1.05, def:1.00, supply:0.95, food:1.15, desc:'沃野四围，仓储易足' }
    };

    // ====== 明境各布政使司地形 ======
    var PROV_TERRAIN = {
        beizhili: 'plain',  nanzhili: 'river',  huguang: 'river',
        liaodong: 'pass',   shanxi:   'pass',  shaanxi: 'pass',
        gansu:    'pass',   ningxia:  'pass',  shandong: 'plain',
        henan:    'plain',  zhejiang: 'river', jiangxi: 'hill',
        fujian:   'coast',  guangdong:'coast', guangxi: 'hill',
        yunnan:   'mount',  guizhou:  'mount', sichuan: 'basin',
        hainan:   'coast'
    };

    // ====== 敌国势力（占据地图上的独立据点，非完整省份）======
    // 每个据点：id / 所属国 / 名称 / 多边形（经纬）/ 驻军 / 士气 / 补给 / 物产
    // ====== 敌国势力（据点为"势力范围"，非完整省份）======
    // 史据：《明史》卷327·鞑靼传 / 卷328·瓦剌朵颜传 / 卷329·哈密土鲁番 /
    //       卷330·西番诸卫 / 卷331·乌斯藏 / 卷321·安南 / 卷310-319·土司 /
    //       《清太祖实录》《清太宗实录》（女真诸部） / 《明史纪事本末》卷20
    var ENEMY_POWERS = {
        mongol: {
            nm: '北元·鞑靼', color: '#8a6a3a', stroke: '#5a4020',
            banner: '鞑', chief: '达延汗',
            desc: '漠北控弦之士，骑射为长。达延汗统一六万户，控弦十余万，秋高草美则寇边。',
            src: '《明史》卷327·鞑靼传：小王子最富强，控弦十余万。'
        },
        tatar: {
            nm: '瓦剌·四卫拉特', color: '#7a7a4a', stroke: '#4a4a28',
            banner: '瓦', chief: '马哈木',
            desc: '西徙万里，服元而叛元。亦先曾自称大元田盛大可汗，土木之变即其所为。',
            src: '《明史》卷328·瓦剌传：也先自立大元田盛大可汗。'
        },
        jurchen: {
            nm: '建州女真', color: '#7a4a3a', stroke: '#4a281c',
            banner: '真', chief: '努尔哈赤',
            desc: '起于赫图阿拉，以十三副遗甲起兵，十年间统一建州五部，缮甲厉兵。',
            src: '《清太祖实录》卷1：万历十一年五月，以十三副遗甲攻图伦城。'
        },
        haixi: {
            nm: '海西女真', color: '#8a5a4a', stroke: '#4a2c20',
            banner: '海', chief: '清佳砮',
            desc: '叶赫、哈达、辉发、乌拉四部，据松花江流域，与建州世为仇敌。',
            src: '《清太祖实录》卷6-12：叶赫、哈达、辉发、乌拉并称海西四部。'
        },
        yeren: {
            nm: '野人女真', color: '#6a5a4a', stroke: '#3c3024',
            banner: '野', chief: '宁古塔守将',
            desc: '东海窝集诸部，散处黑龙江下游，人多械劣，然出产貂皮。',
            src: '《明史》卷332：奴儿干都司辖卫三百八十四，羁縻东北。'
        },
        wokou: {
            nm: '倭寇·日本', color: '#4a5a7a', stroke: '#28364a',
            banner: '倭', chief: '岛津义经',
            desc: '日本诸岛之寇。嘉靖大倭寇起于九州、濑户内海，舟至东南，掠民夺货。',
            src: '《明史》卷322·日本传：倭之为寇，自洪武至嘉靖屡犯东南。'
        },
        annam: {
            nm: '安南', color: '#6a4a6a', stroke: '#3c283c',
            banner: '安', chief: '黎维潭',
            desc: '占交趾，黎莫二姓分据，叛服不常。明置安南都统使司，籍其土府五十三。',
            src: '《明史》卷321·安南传：然迄明之世，二姓分据，终不能归一。'
        },
        tusi: {
            nm: '西南土司', color: '#5a6a4a', stroke: '#333e28',
            banner: '蛮', chief: '杨应龙',
            desc: '溪峒徼外，峒官世袭，中朝羁縻而已。播州杨氏、麓川思氏皆曾称乱。',
            src: '《明史》卷311-316·土司传：土司之官，世袭其地，中朝不能制。'
        },
        tibet: {
            nm: '吐蕃·乌斯藏', color: '#6a5a6a', stroke: '#3c3040',
            banner: '蕃', chief: '大宝法王',
            desc: '西番佛国。明封八大法王，三年一贡，然驻节之兵未尝一至。',
            src: '《明史》卷331·乌斯藏：大宝法王领天下释教，三年一贡。'
        },
        turpan: {
            nm: '土鲁番', color: '#8a7a4a', stroke: '#4a4020',
            banner: '番', chief: '满速儿',
            desc: '嘉靖间据哈密，围肃州、犯甘州，与明三战三和。',
            src: '《明史》卷329·土鲁番：嘉靖十二年，贼退至瓜州。'
        },
        hami: {
            nm: '哈密卫', color: '#7a8a5a', stroke: '#3c4a28',
            banner: '哈', chief: '忠顺王',
            desc: '西域要冲，明之藩屏。永乐间岁贡马数千匹，嘉靖后失不复得。',
            src: '《明史》卷329·哈密卫：永乐九年贡马三千五百余匹。'
        },
        sixi: {
            nm: '西域诸国', color: '#6a7a8a', stroke: '#3c4a54',
            banner: '域', chief: '撒马儿罕',
            desc: '撒马儿罕、哈烈、别失八里、于阗，犬牙相接，商旅辐辏。',
            src: '《明史》卷332·西域四：撒马儿罕献狮子、西马、文豹。'
        },
        qinghai: {
            nm: '青海·西番', color: '#7a6a7a', stroke: '#40304a',
            banner: '青', chief: '亦卜只斤',
            desc: '曲先、安定诸卫，明初所置，后为蒙古所据，茶马互市在此。',
            src: '《明史》卷330·西番诸卫：曲先卫，宣德初复业四万余帐。'
        }
    };

    // ====== 敌国据点（史据坐标已核对；每国取代表据点）======
    var ENEMY_ZONES = [
        // --- 北元·鞑靼（漠北至漠南）---
        { id:'z_menghe', pow:'mongol', nm:'和林', poly:[[98,45.5],[102,44.8],[107,45.6],[108.5,48.4],[104.5,50],[100,48.6],[97,46.8]],
          troops:60000, morale:86, supply:58, food:900, note:'漠南旧都，蒙古汗庭所在', src:'《明史》卷327：本雅失里、阿鲁台皆居此。' },
        { id:'z_chahar', pow:'mongol', nm:'察哈尔', poly:[[112,42.6],[115,41.8],[119,42.6],[120,45],[116.5,46.2],[113.5,44.6]],
          troops:80000, morale:88, supply:62, food:1200, note:'达延汗汗庭锡林郭勒，控弦十余万', src:'《明史》卷327：小王子最富强，控弦十余万。' },
        { id:'z_duoyan', pow:'mongol', nm:'朵颜', poly:[[118,40.4],[121,40],[122.8,42],[121,43.4],[118.8,42.6]],
          troops:26000, morale:82, supply:64, food:500, note:'三卫之地，董狐狸长昂所居', src:'《明史》卷328·朵颜三卫。' },
        { id:'z_guihua', pow:'mongol', nm:'归化城', poly:[[109.8,39.8],[112.4,39.6],[113.6,41],[112.4,42.4],[110.4,41.6]],
          troops:50000, morale:84, supply:70, food:800, note:'俺答汗所居，三娘子主贡市三十年', src:'《明史》卷327：隆庆五年封俺答顺义王。' },
        { id:'z_keerqin', pow:'mongol', nm:'科尔沁', poly:[[121.4,43.4],[123.8,43],[125.4,44.4],[124.2,45.6],[121.8,45],[120.6,44.2]],
          troops:34000, morale:80, supply:66, food:600, note:'奥巴所居，献驼马以通贡市', src:'《清太宗实录》卷4：奥巴率嫩科尔沁归附。' },

        { id:'z_ordos', pow:'mongol', nm:'鄂尔多斯', poly:[[107.6,38.4],[110.8,37.8],[112.4,39.4],[111.6,40.8],[109,40.6],[107.4,39.6]],
          troops:30000, morale:78, supply:64, food:560, note:'河套之地，六旗驻牧，逼近长城', src:'《北虏考》：弘治间鄂尔多斯部尽入河套。' },

        // --- 瓦剌·四卫拉特 ---
        { id:'z_wala', pow:'tatar', nm:'瓦剌', poly:[[84,45.4],[88,44.6],[92,45.4],[93.4,47.6],[89.6,49],[85.6,47.8]],
          troops:40000, morale:84, supply:52, food:700, note:'也先汗庭所在，控弦西极', src:'《明史》卷328：也先自立大元田盛大可汗。' },
        { id:'z_yiji', pow:'tatar', nm:'亦集把', poly:[[82.6,43.2],[86,42.6],[88.4,44],[87.6,46.4],[84,45.4],[82.4,44]],
          troops:22000, morale:78, supply:50, food:460, note:'和硕特部驻牧，固始汗所自出', src:'《西域图志》卷3：四卫拉特盟主拜巴噶斯。' },

        // --- 建州女真 ---
        { id:'z_jianzhou', pow:'jurchen', nm:'建州', poly:[[124.6,41.6],[126.4,41.2],[127.8,42.4],[126.8,43.2],[125,42.8],[124.2,42.2]],
          troops:22000, morale:90, supply:56, food:420, note:'赫图阿拉所在，努尔哈赤十三副遗甲起兵', src:'《清太祖实录》卷1-6：建州五部。' },
        { id:'z_donge', pow:'jurchen', nm:'董鄂', poly:[[123.8,39.8],[125.4,39.6],[126.2,40.8],[125.2,41.6],[123.8,41]],
          troops:14000, morale:84, supply:58, food:280, note:'董鄂部，栋鄂河上游，八千余口', src:'《清太祖实录》卷3：何和礼率部归附。' },

        // --- 海西女真 ---
        { id:'z_yehe', pow:'haixi', nm:'叶赫', poly:[[124.2,43.2],[126.2,42.8],[127.4,44],[126.2,44.8],[124.4,44.4]],
          troops:18000, morale:86, supply:58, food:380, note:'叶赫东城西城，清佳砮杨吉砮所据', src:'《清太祖实录》卷6-21：万历四十七年叶赫亡。' },
        { id:'z_wula', pow:'haixi', nm:'乌拉', poly:[[126.8,44],[128.6,43.6],[129.6,45],[128.4,45.8],[126.6,45.2]],
          troops:12000, morale:80, supply:56, food:260, note:'乌拉城，布占泰所据', src:'《清太祖实录》卷20：万历四十一年正月灭乌拉。' },

        // --- 野人女真 ---
        { id:'z_ningguta', pow:'yeren', nm:'宁古塔', poly:[[129.4,44.8],[131.6,44.2],[132.6,46],[131,47.2],[129,46.4]],
          troops:9000, morale:70, supply:52, food:220, note:'宁古塔城，后金东北经营之基', src:'《清太宗实录》：天聪五年吴巴海监造宁古塔旧城。' },

        // --- 倭寇·日本 ---
        { id:'z_kyushu', pow:'wokou', nm:'九州', poly:[[129.2,31.2],[130.8,30.4],[132.6,31.2],[133.4,33],[132,34.4],[130,34],[129,32.6]],
          troops:20000, morale:80, supply:70, food:600, note:'日本诸岛，倭寇所自出', src:'《明史》卷322·日本传。' },
        { id:'z_seto', pow:'wokou', nm:'濑户', poly:[[131.8,33.4],[133.6,32.8],[135.6,33.6],[136.2,35.2],[134.4,36],[132.4,35.2],[131.6,34.2]],
          troops:15000, morale:76, supply:65, food:450, note:'濑户内海，舟师巢穴', src:'《明史》卷322：倭自濑户内海出。' },
        { id:'z_ryukyu', pow:'wokou', nm:'琉球', poly:[[126.2,25.6],[127.6,25],[129,25.6],[129.2,27.2],[127.8,28],[126.4,27.4]],
          troops:9000, morale:72, supply:60, food:250, note:'琉球小邦，介在倭与南洋之间', src:'《明史》卷323·琉球。' },

        // --- 安南 ---
        { id:'z_shenglong', pow:'annam', nm:'升龙', poly:[[104.6,20.4],[106.8,20],[108.2,21.6],[107.2,23],[105.2,22.4],[104.4,21.4]],
          troops:26000, morale:78, supply:76, food:720, note:'交州都会，黎莫二姓所争', src:'《明史》卷321·安南传。' },
        { id:'z_qinghua', pow:'annam', nm:'清化', poly:[[104.8,17.8],[106.6,17.4],[108,18.8],[106.8,20.2],[105,19.6]],
          troops:18000, morale:74, supply:72, food:520, note:'后黎所都，黎维潭请罪处', src:'《明史》卷321：万历二十五年黎维潭入关谒见。' },

        // --- 西南土司 ---
        { id:'z_bozhou', pow:'tusi', nm:'播州', poly:[[106,26.4],[108,25.8],[109.4,27.2],[108.6,28.4],[106.8,28.2],[105.8,27.2]],
          troops:20000, morale:76, supply:60, food:420, note:'播州杨氏，海龙囤万山重叠', src:'《明史》卷312·播州宣慰司：万历二十八年播州之役。' },
        { id:'z_luchuan', pow:'tusi', nm:'麓川', poly:[[96.8,23.4],[98.6,22.8],[100.2,24],[100.4,26],[98.6,26.8],[97,25.2]],
          troops:16000, morale:78, supply:58, food:360, note:'麓川思氏，斩馘五万余', src:'《明史》卷314·麓川传：正统六年王骥讨思任法。' },
        { id:'z_wusa', pow:'tusi', nm:'乌撒', poly:[[103,25.8],[105.4,25.4],[106.6,26.8],[105.4,28],[103.4,27.4]],
          troops:12000, morale:74, supply:56, food:300, note:'乌撒土司，奢安之乱同党', src:'《明史》卷311·乌撒。' },
        { id:'z_lijiang', pow:'tusi', nm:'丽江', poly:[[99.2,25.8],[101.4,25.4],[102.4,27],[101.2,28],[99.4,27]],
          troops:10000, morale:72, supply:60, food:320, note:'木氏守石门关，屏滇南', src:'《明史》卷314·丽江传。' },

        // --- 吐蕃 ---
        { id:'z_wusizang', pow:'tibet', nm:'乌思藏', poly:[[88.6,27.6],[91.8,27],[94.2,28.6],[93.6,31],[91,31.8],[88.8,30.4]],
          troops:24000, morale:76, supply:55, food:420, note:'拉萨所在，大宝法王所领', src:'《明史》卷331·乌斯藏。' },
        { id:'z_duogan', pow:'tibet', nm:'朵甘', poly:[[98,32.4],[101.6,31.8],[103.6,34],[102,35.8],[99.4,35],[97.6,33.6]],
          troops:16000, morale:72, supply:50, food:320, note:'朵甘都司，明军曾拓地数千里', src:'《明史》卷126·沐英传：平朵甘纳儿七站。' },
        { id:'z_elishi', pow:'tibet', nm:'俄力思', poly:[[78.8,30.8],[81.6,30.2],[83.4,32],[82,33.6],[79.6,33],[78.4,31.8]],
          troops:9000, morale:70, supply:46, food:200, note:'阿里一带，元力思军民元帅府', src:'《明史》卷331：俄力思军民元帅府。' },

        // --- 西域 ---
        { id:'z_tulufan', pow:'turpan', nm:'土鲁番', poly:[[87.8,41.6],[90.6,41],[92,42.6],[90.4,44],[88,43.4]],
          troops:26000, morale:80, supply:56, food:520, note:'土鲁番城，速檀满所据，三围肃州', src:'《明史》卷329：嘉靖十二年贼退至瓜州。' },
        { id:'z_hami', pow:'hami', nm:'哈密', poly:[[92.4,41.6],[95.4,41],[97,42.8],[95.4,44.4],[93,44]],
          troops:18000, morale:74, supply:54, food:380, note:'西域要冲，岁贡马数千', src:'《明史》卷329·哈密卫。' },
        { id:'z_bieshi', pow:'sixi', nm:'别失八里', poly:[[84.8,40.6],[87.6,39.8],[89.4,41.8],[87.8,43.6],[85.4,42.8]],
          troops:14000, morale:72, supply:50, food:300, note:'焉耆龟兹，西域南北枢纽', src:'《明史》卷332·别失八里。' },

        // --- 青海 ---
        { id:'z_quxian', pow:'qinghai', nm:'曲先', poly:[[96.2,35.2],[99.4,34.6],[100.8,36.8],[99,38.2],[96.8,37.4]],
          troops:15000, morale:72, supply:48, food:280, note:'曲先卫，正德中为蒙古所破', src:'《明史》卷330·曲先卫。' }
    ];

    // ====== 守城加成（按府）======
    // 明代府城皆有城墙，城坚则守方得势
    function cityDefense(provId) {
        var base = { beizhili:1.35, nanzhili:1.20, shanxi:1.15, shaanxi:1.10,
                     shandong:1.10, henan:1.05, huzhou:1.10, liaodong:1.20,
                     gansu:1.25, ningxia:1.20, fujian:1.15, guangdong:1.15,
                     zhejiang:1.10, jiangxi:1.05, guangxi:1.05, yunnan:1.00,
                     guizhou:0.95, sichuan:1.20, huguang:1.10, hainan:0.90 };
        return base[provId] || 1.0;
    }

    // ====== 地形读取 ======
    function terrainOf(provId) {
        return TERRAIN[PROV_TERRAIN[provId] || 'plain'];
    }
    function terrainKey(provId) { return PROV_TERRAIN[provId] || 'plain'; }

    // ====== 与既有外交系统（GameState.nations）联动 ======
    var POW_TO_NATION = {
        mongol: '鞑靼', tatar: '瓦剌', jurchen: '建州',
        wokou: '日本', annam: '安南', tusi: '土司', tibet: '乌斯藏',
        haixi: '叶赫', yeren: '女真', turpan: '土鲁番',
        hami: '哈密', sixi: '撒马儿罕', qinghai: '西番'
    };
    function syncNation(pow, hostilityDelta, strengthDelta) {
        try {
            if (!GameState || !GameState.nations) return;
            var nm = POW_TO_NATION[pow];
            if (!nm) return;
            GameState.nations.forEach(function (n) {
                if (n.name === nm) {
                    n.hostility = Math.max(0, Math.min(100, num(n.hostility, 50) + hostilityDelta));
                    n.strength = Math.max(0, Math.min(100, num(n.strength, 50) + strengthDelta));
                }
            });
        } catch (e) {}
    }

    // 遣使议和：花钱买太平
    function makePeace(zoneId) {
        try {
            var w = wr();
            var z = null;
            w.zones.forEach(function (x) { if (x.id === zoneId) z = x; });
            if (!z) return { ok:false, msg:'无此国' };
            var s = GameState.stats;
            var cost = 1200;
            if (num(s.treasury, 0) < cost) return { ok:false, msg:'国库不足，聘金无出' };
            s.treasury -= cost;
            // 敌国降气焰
            z.aggression = Math.max(5, num(z.aggression, 40) - 35);
            z.morale = clamp(num(z.morale, 70) - 8);
            z.cooldown = 3;
            syncNation(z.pow, -18, -5);
            s.prestige = clamp(num(s.prestige, 50) - 2);   // 议和损威望
            if (typeof pushNews === 'function') {
                pushNews('外交', '遣使与' + ENEMY_POWERS[z.pow].nm + '议和，岁赐千金，暂息兵戈。', 'normal');
            }
            return { ok:true, zone: z };
        } catch (e) { return { ok:false, msg:'议和不成' }; }
    }

    // ====== 状态 ======
    function initWar() {
        return {
            zones: ENEMY_ZONES.map(function (z) {
                // 由多边形重心算经纬度（用于测距与取最近驻军）
                var cLon = 0, cLat = 0;
                z.poly.forEach(function (p) { cLon += p[0]; cLat += p[1]; });
                cLon /= z.poly.length; cLat /= z.poly.length;
                return {
                    id: z.id, pow: z.pow, nm: z.nm,
                    poly: z.poly, note: z.note || '边外之地',
                    lon: cLon, lat: cLat,
                    troops: z.troops, morale: z.morale, supply: z.supply, food: z.food,
                    atk: 1.0, def: 1.0,        // 势力方自身攻守（可被战事改变）
                    occupied: false,           // 是否已被我朝攻取
                    cooldown: 0,
                    lastBattle: null,
                    aggression: 28 + Math.floor(Math.random() * 28)
                };
            }),
            rebels: [],          // 叛军
            battles: [],         // 战报
            suppressions: 0,     // 平叛次数
            sieges: 0
        };
    }
    function wr() {
        if (typeof GameState === 'undefined' || !GameState) return initWar();
        if (!GameState.warSim) GameState.warSim = initWar();
        var w = GameState.warSim;
        if (!Array.isArray(w.zones)) w.zones = initWar().zones;
        if (!Array.isArray(w.rebels)) w.rebels = [];
        if (!Array.isArray(w.battles)) w.battles = [];
        syncNations();
        return w;
    }

    // 把新增敌国补进外交名册（既有 16 国之外的）
    function syncNations() {
        try {
            if (!GameState.nations) return;
            var have = {};
            GameState.nations.forEach(function (n) { have[n.name] = true; });
            var defs = [
                { name: '叶赫', type: '敌国', hostility: 62, strength: 45, tribute: 0, diplomats: 0, traits: ['海西','骑战','世仇'] },
                { name: '女真', type: '敌国', hostility: 58, strength: 48, tribute: 0, diplomats: 0, traits: ['渔猎','东海','貂皮'] },
                { name: '土鲁番', type: '敌国', hostility: 60, strength: 50, tribute: 0, diplomats: 1, traits: ['西域','反复','攻城'] },
                { name: '哈密', type: '属国', hostility: 25, strength: 30, tribute: 1, diplomats: 2, traits: ['羁縻','朝贡','要冲'] },
                { name: '撒马儿罕', type: '邻国', hostility: 30, strength: 55, tribute: 0, diplomats: 2, traits: ['西域','商旅','狮子'] },
                { name: '西番', type: '属国', hostility: 30, strength: 32, tribute: 1, diplomats: 1, traits: ['茶马','羁縻','青海'] }
            ];
            defs.forEach(function (d) {
                if (!have[d.name]) GameState.nations.push(JSON.parse(JSON.stringify(d)));
            });
        } catch (e) {}
    }

    // ====== 战斗公式（核心）======
    /**
     * 攻守对比：
     *   攻方战力 = 兵 × 士气/100 × 补给/100 × 将领 × 兵种系数 × (1 + 火器×0.08)
     *   守方战力 = 兵 × 士气/100 × 补给/100 × 地形.def × 城防
     *   胜率 = 攻 / (攻 + 守) ，带 ±12% 随机扰动
     *   伤亡：胜方 8%~20%，败方 30%~60%
     */
    function battle(atk, def, opt) {
        opt = opt || {};
        var a = Math.max(1, num(atk.troops, 1));
        var d = Math.max(1, num(def.troops, 1));

        // 攻方战力
        var aMorale = clamp(num(atk.morale, 60), 10, 100) / 100;
        var aSupply = clamp(num(atk.supply, 60), 10, 100) / 100;
        var aGen = opt.general || 1.0;          // 将领系数
        var aArm = opt.arms || 1.0;            // 兵种系数
        var aFire = 1 + (num(opt.firearms, 0)) * 0.08;  // 火器加成
        var aTer = opt.terrainAtk || 1.0;      // 攻方所处地形
        var aPow = a * aMorale * aSupply * aGen * aArm * aFire * aTer;

        // 守方战力
        var dMorale = clamp(num(def.morale, 60), 10, 100) / 100;
        var dSupply = clamp(num(def.supply, 60), 10, 100) / 100;
        var dTer = opt.terrainDef || 1.0;      // 守方地形防御
        var dCity = opt.city || 1.0;           // 城防
        var dPow = d * dMorale * dSupply * dTer * dCity;

        // 胜率
        var ratio = aPow / (aPow + dPow);
        var chance = Math.max(0.05, Math.min(0.95, ratio + (Math.random() - 0.5) * 0.24));
        var atkWins = Math.random() < chance;

        // 伤亡
        var aLossRate = atkWins ? (0.08 + Math.random() * 0.12) : (0.30 + Math.random() * 0.30);
        var dLossRate = atkWins ? (0.30 + Math.random() * 0.30) : (0.08 + Math.random() * 0.14);
        var aLoss = Math.round(a * aLossRate);
        var dLoss = Math.round(d * dLossRate);

        return {
            atkWins: atkWins,
            chance: chance,
            atkPower: Math.round(aPow),
            defPower: Math.round(dPow),
            atkLoss: aLoss,
            defLoss: dLoss,
            atkLeft: Math.max(0, a - aLoss),
            defLeft: Math.max(0, d - dLoss),
            terrain: opt.terrainNm || '平原',
            terrainDef: opt.terrainDef || 1,
            city: opt.city || 1,
            atkName: opt.atkName || '官军',
            defName: opt.defName || '守军',
            atkSupply: num(atk.supply, 60),
            defSupply: num(def.supply, 60)
        };
    }
    function clamp(v){ return Math.max(0, Math.min(100, Math.round(Number(v)||0))); }
    function num(v, fb){ var n=(typeof v==='number')?v:parseFloat(v); return (!isFinite(n))?fb:n; }

    // ====== 玩家攻取敌方据点 ======
    function attackZone(zoneId, troops) {
        try {
            var w = wr();
            var z = null;
            for (var i = 0; i < w.zones.length; i++) if (w.zones[i].id === zoneId) z = w.zones[i];
            if (!z) return { ok:false, msg:'无此据点' };
            if (z.occupied) return { ok:false, msg:z.nm+'已为我朝所取' };
            if (z.cooldown > 0) return { ok:false, msg:z.nm+'新败，喘息未已' };

            var s = GameState.stats;
            if (num(s.treasury,0) < 300) return { ok:false, msg:'国库不足，军饷无出' };

            // 找最近己方驻军点作为出发地（须在用兵半径内）
            var from = nearestFriendly(z);
            if (!from) return { ok:false, msg:'附近无可用之师' };
            var dist = Math.abs((from.lon||0) - z.lon) + Math.abs((from.lat||0) - z.lat);
            var reach = 16;   // 半径（约 1600 里）
            if (dist > reach) {
                return { ok:false, msg: from.nm + '距' + z.nm + '过远（'+Math.round(dist*100)+'里），须先移师' };
            }
            if (from.troops < troops) return { ok:false, msg: from.nm + '兵不足 ' + troops + '（现有 '+num(from.troops,0)+'）' };

            var atk = { troops: troops, morale: clamp(55 + (num(s.mandate,50) - 50) * 0.6), supply: 85 };
            var def = { troops: z.troops, morale: z.morale, supply: z.supply };

            // 地形：据点所在省份
            var ter = zoneTerrain(z);
            // v8.3：守方防御含本地营造（烽燧/关隘/卫所）
            var defFac = (typeof BUILD !== 'undefined') ? BUILD.defFactor(zoneProvOf(z)) : ter.def;
            var res = battle(atk, def, {
                terrainAtk: 1.0,
                terrainDef: defFac,
                terrainNm: ter.nm,
                city: 1.15,           // 敌国据点亦有城栅
                firearms: num(s.milOps && s.milOps.firearms, 0),
                general: 1.0,
                atkName: from.nm + '军',
                defName: ENEMY_POWERS[z.pow].nm + '·' + z.nm
            });

            // 结算：出征部队离开驻军，胜则凯旋，败则溃散
            var zBefore = num(z.troops, 0);          // 战前敌兵（占领判定基准）
            from.troops = Math.max(0, num(from.troops,0) - troops);
            z.troops = res.defLeft;
            z.morale = clamp(z.morale - (res.atkWins ? 25 : 5));
            z.supply = clamp(z.supply - 10);
            s.treasury -= 300;
            s.militaryFood = Math.max(0, num(s.militaryFood,0) - Math.round(troops*0.5));

            // 占领判定：敌丧其半，或残军不足我军六分之一
            var conquered = res.atkWins && (res.defLeft < zBefore * 0.5 || res.defLeft < res.atkLeft * 0.166);
            if (conquered) {
                // 攻取
                z.occupied = true;
                z.troops = res.defLeft;
                from.troops += res.atkLeft;          // 凯旋
                z.garrison = res.atkLeft;            // 留戍之兵
                z.supply = clamp(z.supply + 20);
                z.cooldown = 0;
                syncNation(z.pow, -25, -15);           // 敌国势挫，外交态势同步
                s.treasury += 500;
                s.prestige = clamp(num(s.prestige,50) + 6);
                s.mandate = clamp(num(s.mandate,50) + 4);
                if (typeof pushNews === 'function') {
                    pushNews('战报', res.atkName + '攻破' + ENEMY_POWERS[z.pow].nm + '·' + z.nm + '，遂置羁縻州县，纳其地。', 'normal');
                }
            } else {
                from.troops += Math.round(res.atkLeft * 0.3);   // 溃散者归队
                if (typeof pushNews === 'function') {
                    pushNews('战报', res.atkWins
                        ? (res.atkName + '战于' + z.nm + '，敌溃，我军伤亡' + res.atkLoss + '人。')
                        : (res.atkName + '攻' + z.nm + '不克，败绩。军亡' + res.atkLoss + '人。'), 'critical');
                }
            }

            w.battles.unshift({
                atk: res.atkName, def: res.defName,
                win: res.atkWins, aLoss: res.atkLoss, dLoss: res.defLoss,
                terrain: res.terrain, chance: Math.round(res.chance*100),
                t: (GameState.currentYear||0)
            });
            if (w.battles.length > 20) w.battles.pop();

            return { ok:true, result: res, zone: z };
        } catch (e) { return { ok:false, msg:'战事不成' }; }
    }

    // 据点所关联的明境省份（取其建设加成）
    function zoneProvOf(z) {
        var map = {
            z_menghe:'shanxi', z_chahar:'beizhili', z_duoyan:'beizhili',
            z_guihua:'beizhili', z_keerqin:'liaodong', z_naiman:'liaodong',
            z_ordos:'shaanxi',
            z_wala:'gansu', z_yiji:'gansu',
            z_jianzhou:'liaodong', z_donge:'liaodong',
            z_yehe:'liaodong', z_wula:'liaodong', z_ningguta:'liaodong',
            z_kyushu:'fujian', z_seto:'fujian', z_ryukyu:'fujian',
            z_shenglong:'guangdong', z_qinghua:'guangxi',
            z_bozhou:'guizhou', z_luchuan:'yunnan', z_wusa:'yunnan', z_lijiang:'yunnan',
            z_wusizang:'sichuan', z_duogan:'sichuan', z_elishi:'sichuan',
            z_tulufan:'gansu', z_hami:'gansu', z_bieshi:'gansu',
            z_quxian:'shaanxi'
        };
        return map[z.id] || 'beizhili';
    }

    function zoneTerrain(z) {
        // 据点大致归属的省份（用于取地形）
        var map = {
            z_menghe:'shanxi', z_hetao:'shaanxi', z_ordos:'shaanxi',
            z_wala:'gansu', z_hami:'gansu',
            z_jianzhou:'liaodong', z_liaoshen:'liaodong',
            z_kyushu:'fujian', z_seto:'fujian', z_ryukyu:'fujian',
            z_giao:'guangdong', z_luchuan:'yunnan', z_bozhou:'guizhou',
            z_lasa:'sichuan'
        };
        return terrainOf(map[z.id] || 'plain');
    }

    // 是否贴近明境（12 度以内方可劫掠）
    function nearMingBorder(z) {
        try {
            var provs = (typeof ATLAS_LIST !== 'undefined') ? ATLAS_LIST : [];
            for (var i = 0; i < provs.length; i++) {
                var d = Math.abs(provs[i].lon - z.lon) + Math.abs(provs[i].lat - z.lat);
                if (d < 12) return true;
            }
            return false;
        } catch (e) { return true; }
    }

    // 敌国最近的明境省份（用于入侵落点）
    function nearestBorderProv(z) {
        try {
            var provs = (typeof ATLAS_LIST !== 'undefined') ? ATLAS_LIST : [];
            if (!provs.length) return null;
            var best = null, bd = 1e9;
            provs.forEach(function (p) {
                var d = Math.abs(p.lon - z.lon) + Math.abs(p.lat - z.lat);
                if (d < bd) { bd = d; best = p; }
            });
            return best ? best.id : null;
        } catch (e) { return null; }
    }
    function provNmOf(id) {
        try {
            var provs = (typeof ATLAS_LIST !== 'undefined') ? ATLAS_LIST : [];
            var p = provs.filter(function (x) { return x.id === id; })[0];
            return p ? p.nm : '';
        } catch (e) { return ''; }
    }

    function nearestFriendly(z) {
        try {
            if (typeof OVL === 'undefined') return null;
            var best = null, bd = 1e9;
            OVL.nodes.forEach(function (n) {
                var d = Math.abs(n.lon - z.lon) + Math.abs(n.lat - z.lat);
                if (d < bd) { bd = d; best = n; }
            });
            return best;
        } catch (e) { return null; }
    }

    // ====== 敌国 AI：每季动作 ======
    function enemyTurn() {
        try {
            var w = wr();
            var s = GameState.stats;
            var events = [];
            var invasionDone = false;   // 每季至多一次入侵（其余仅劫掠/内乱）
            var raidDone = false;       // 每季至多一次劫掠
            var wcd = w.invasionCd || 0;   // 全局入侵冷却（季）
            if (wcd > 0) { wcd--; invasionDone = true; }
            w.invasionCd = wcd;

            w.zones.forEach(function (z) {
                if (z.occupied) return;
                if (z.cooldown > 0) { z.cooldown--; return; }

                var roll = Math.random() * 100;

                // 劫掠边境：仅限地理上贴近明境者（远塞无从掠我）
                if (roll < z.aggression * 0.30 && nearMingBorder(z) && !raidDone) {
                    var loss = Math.round(s.food * (0.010 + Math.random() * 0.014));
                    s.food = Math.max(0, num(s.food,0) - loss);
                    s.stability = clamp(num(s.stability,50) - 1);
                    syncNation(z.pow, 5, 3);
                    events.push({ t:'劫掠', txt: ENEMY_POWERS[z.pow].nm + '·' + z.nm + '掠我边，掠粮 ' + loss + '石。' });
                    raidDone = true;
                }
                // 入侵：不是直接扣数值，而是打到边境省，生成"敌寇入边"地图事件
                // 玩家必须在三季内处置，否则该省沦陷（这才是"敌国会打下来"）
                else if (roll < z.aggression * 0.75 && !invasionDone) {
                    var provId = nearestBorderProv(z);
                    if (provId) {
                        // 敌国兵力推进一部分（前锋已至）
                        var vanguard = Math.round(z.troops * (0.16 + Math.random() * 0.12));
                        z.troops = Math.max(1000, z.troops - Math.round(vanguard * 0.3));
                        if (typeof OVL !== 'undefined' && OVL.addInvasion) {
                            OVL.addInvasion(z.id, z.nm, ENEMY_POWERS[z.pow].nm, vanguard, provId);
                        }
                        events.push({ t:'入侵', txt: ENEMY_POWERS[z.pow].nm + '·' + z.nm + '兴兵犯边，前锋已至' + (provNmOf(provId) || '边境') + '。' });
                        invasionDone = true;
                        w.invasionCd = 2;      // 全局冷却：两季内不再有第二路入侵
                    }
                }
                // 内乱（自己弱）
                else if (roll > 92) {
                    z.morale = clamp(z.morale - 15);
                    z.troops = Math.round(z.troops * 0.88);
                    events.push({ t:'内乱', txt: ENEMY_POWERS[z.pow].nm + '部众离心，' + z.nm + '势弱。' });
                }
            });

            return events;
        } catch (e) { return []; }
    }

    // ====== 叛乱系统 ======
    // 怨望高 → 生民变；叛军会扩张；平叛走战斗公式
    var REBEL_NAMES = ['张献忠','李自成','罗汝才','马元利','王嘉胤','高迎祥','刘国能','曹文诏','白彦章','黄巢'];

    function checkRebels() {
        try {
            var s = GameState.stats;
            var w = wr();
            var out = [];

            // 各省怨望触发
            if (typeof pvEnsure === 'function') { try { pvEnsure(); } catch (e) {} }
            var root = GameState.province;
            var box = (root && root.prov) ? root.prov : (root || {});
            var provList = (typeof ATLAS_LIST !== 'undefined') ? ATLAS_LIST : [];

            // 同时叛乱上限 4 路（再多则民不聊生，天下大乱）
            var MAX_REBEL = 4;
            if (w.rebels.length >= MAX_REBEL) return out;

            provList.forEach(function (p) {
                if (w.rebels.some(function (r) { return r.prov === p.id; })) return;
                var pv = box[p.id];
                if (!pv) return;
                var dis = num(pv.disaffect, 20);
                if (dis < 55) return;
                var chance = (dis - 55) / 45;    // 0~1
                if (Math.random() > chance * 0.5) return;

                // v8.3：叛乱类型分化（流寇/民变/边军哗变/白莲教/通倭内应）
                var kind = (typeof REBEL !== 'undefined') ? REBEL.decideKind(p, box[p.id], dis) : 'minbian';
                var kd = (typeof REBEL !== 'undefined' && REBEL.KINDS[kind]) ? REBEL.KINDS[kind] : { spread: 0.3, power: 1.0, moraleBase: 55, nm: '民变' };
                var troops = Math.round((500 + dis * 60 + Math.random() * 3000) * kd.power);
                var leader = (typeof REBEL !== 'undefined') ? REBEL.pickLeader(kind) : REBEL_NAMES[Math.floor(Math.random() * REBEL_NAMES.length)];
                w.rebels.push({
                    id: 'r' + Date.now() + Math.floor(Math.random()*1000),
                    prov: p.id, provNm: p.nm,
                    kind: kind, kindNm: kd.nm,
                    leader: leader,
                    troops: troops,
                    morale: clamp(kd.moraleBase + dis / 3),
                    supply: 60,
                    def: 1.0,
                    atk: kd.power,
                    age: 0,
                    betrayed: false, ally: null
                });
                s.stability = clamp(num(s.stability,50) - 2);
                out.push({ t:'民变', txt: p.nm + '民变，' + leader + '聚众' + troops + '人，据城自守。' });
            });

            // 叛军扩张（每季向邻省蔓延）
            for (var i = w.rebels.length - 1; i >= 0; i--) {
                var r = w.rebels[i];
                r.age++;
                r.troops = Math.round(r.troops * (0.97 + Math.random() * 0.04));
                r.supply = clamp(r.supply - 4);
                var kd2 = (typeof REBEL !== 'undefined' && REBEL.KINDS[r.kind]) ? REBEL.KINDS[r.kind] : { spread: 0.3 };
                if (r.age >= 2 && Math.random() < kd2.spread) {
                    // 向邻省扩张（择"怨望高、易取"之省）
                    var target = (typeof REBEL !== 'undefined') ? REBEL.pickNeighborTarget(r) : neighborOf(r.prov);
                    if (target && !w.rebels.some(function (x) { return x.prov === target.id; })) {
                        w.rebels.push({
                            id: 'r' + Date.now() + Math.floor(Math.random()*1000),
                            prov: target.id, provNm: target.nm,
                            kind: r.kind, kindNm: r.kindNm,
                            leader: r.leader,
                            troops: Math.round(r.troops * 0.6),
                            morale: clamp(r.morale - 5),
                            supply: 50, def: 1.0, atk: num(r.atk, 1.0), age: 0,
                            betrayed: false, ally: null
                        });
                        r.troops = Math.round(r.troops * 0.55);
                        out.push({ t:'蔓延', txt: r.leader + '分兵陷' + target.nm + '，烽火连绵。' });
                    }
                }
                if (r.troops < 200) {
                    w.rebels.splice(i, 1);
                    out.push({ t:'平定', txt: r.leader + '势穷自尽于' + r.provNm + '。' });
                }
            }
            return out;
        } catch (e) { return []; }
    }

    // 邻省表（按布政使司相邻关系）
    var NEIGHBOR = {
        beizhili:['shanxi','shandong','liaodong','nanzhili','henan'],
        nanzhili:['beizhili','shandong','huguang','zhejiang','jiangxi','henan'],
        shandong:['beizhili','nanzhili','henan'],
        shanxi:['beizhili','henan','shaanxi'],
        shaanxi:['shanxi','henan','huguang','sichuan','gansu','ningxia'],
        henan:['beizhili','shanxi','shaanxi','nanzhili','huguang','shandong'],
        huguang:['henan','shaanxi','nanzhili','jiangxi','guizhou','guangxi','sichuan'],
        jiangxi:['nanzhili','huguang','zhejiang','fujian','guangdong','guangxi'],
        zhejiang:['nanzhili','jiangxi','fujian'],
        fujian:['zhejiang','jiangxi','guangdong'],
        guangdong:['fujian','jiangxi','guangxi','huguang'],
        guangxi:['guangdong','huguang','guizhou','yunnan'],
        guizhou:['yunnan','sichuan','huguang','guangxi'],
        yunnan:['guizhou','guangxi','sichuan'],
        sichuan:['shaanxi','gansu','ningxia','hubei','guizhou','yunnan'],
        liaodong:['beizhili'],
        gansu:['sichuan','shaanxi','ningxia'],
        ningxia:['gansu','shaanxi'],
        hainan:['guangdong']
    };
    function neighborOf(provId) {
        try {
            var list = (typeof ATLAS_LIST !== 'undefined') ? ATLAS_LIST : [];
            var ns = NEIGHBOR[provId] || [];
            for (var i = 0; i < ns.length; i++) {
                for (var j = 0; j < list.length; j++) if (list[j].id === ns[i]) return list[j];
            }
        } catch (e) {}
        return null;
    }

    // ====== 平叛 ======
    function suppressRebel(rebelId, troops) {
        try {
            var w = wr();
            var r = null;
            for (var i = 0; i < w.rebels.length; i++) if (w.rebels[i].id === rebelId) r = w.rebels[i];
            if (!r) return { ok:false, msg:'此辈已平' };
            var s = GameState.stats;
            if (num(s.treasury,0) < 400) return { ok:false, msg:'国库不足，饷无所出' };

            var ter = terrainOf(r.prov);
            // v8.3：平叛亦受本地营造保护
            var defFac3 = (typeof BUILD !== 'undefined') ? BUILD.defFactor(r.prov) : ter.def;
            var res = battle(
                { troops: troops, morale: clamp(num(s.mandate,50) + 10), supply: 80 },
                { troops: r.troops, morale: r.morale, supply: r.supply },
                { terrainDef: defFac3, terrainNm: ter.nm, city: cityDefense(r.prov),
                  atkName: '官军', defName: r.leader + '军' }
            );

            s.treasury -= 400;
            s.militaryFood = Math.max(0, num(s.militaryFood,0) - Math.round(troops*0.4));
            w.suppressions++;

            if (res.atkWins) {
                r.troops = res.defLeft;
                r.morale = clamp(r.morale - 20);
                if (res.defLeft < 300 || Math.random() < 0.5) {
                    // 平定
                    w.rebels = w.rebels.filter(function (x) { return x.id !== rebelId; });
                    var pv = (GameState.province && GameState.province.prov) ? GameState.province.prov[r.prov] : null;
                    if (pv) pv.disaffect = clamp(num(pv.disaffect,20) - 18);
                    s.stability = clamp(num(s.stability,50) + 6);
                    s.prestige = clamp(num(s.prestige,50) + 3);
                    if (typeof pushNews === 'function') pushNews('战报', '官军平定' + r.provNm + '之乱，' + r.leader + '授首。稳定 +6。', 'normal');
                } else {
                    if (typeof pushNews === 'function') pushNews('战报', '官军破' + r.leader + '众于' + r.provNm + '，余众未靖。', 'normal');
                }
            } else {
                r.morale = clamp(r.morale + 5);
                if (typeof pushNews === 'function') pushNews('战报', '官军攻' + r.provNm + '不利，' + r.leader + '势益张。', 'critical');
            }

            w.battles.unshift({
                atk: '官军', def: r.leader + '军', win: res.atkWins,
                aLoss: res.atkLoss, dLoss: res.defLoss, terrain: res.terrain,
                chance: Math.round(res.chance*100), t: (GameState.currentYear||0)
            });
            if (w.battles.length > 20) w.battles.pop();

            return { ok:true, result: res, rebel: r };
        } catch (e) { return { ok:false, msg:'平叛不成' }; }
    }

    // ====== 导出 ======
    var WAR = {
        TERRAIN: TERRAIN,
        PROV_TERRAIN: PROV_TERRAIN,
        ENEMY_POWERS: ENEMY_POWERS,
        ENEMY_ZONES: ENEMY_ZONES,
        NEIGHBOR: NEIGHBOR,
        state: wr,
        battle: battle,
        attackZone: attackZone,
        suppressRebel: suppressRebel,
        terrainOf: terrainOf,
        terrainKey: terrainKey,
        cityDefense: cityDefense,
        zoneTerrain: zoneTerrain,
        neighborOf: neighborOf,
        zoneProvOf: zoneProvOf,
        syncNation: syncNation,
        makePeace: makePeace,
        POW_TO_NATION: POW_TO_NATION,
        init: initWar
    };
    window.WAR = WAR;

    // ====== 每季总钩子 ======
    WAR.seasonTick = function () {
        try {
            var out = [];
            // 未处置的入侵逐季推进，第三季沦陷
            var fallen = [];
            try { if (typeof OVL !== 'undefined' && OVL.invasionTick) fallen = OVL.invasionTick() || []; } catch (e) {}
            var e1 = enemyTurn();
            e1.forEach(function (x) { out.push(x); });
            var e2 = checkRebels();
            e2.forEach(function (x) { out.push(x); });

            // v8.3：叛军投敌（通敌为内应）+ 劫掠商路
            try { if (typeof REBEL !== 'undefined') { REBEL.betrayCheck(); REBEL.raidTrade(); } } catch (e) {}

            // 休养生息：每季稳定 +1（战事代价为额外扣减，非抵消）
            GameState.stats.stability = clamp(num(GameState.stats.stability, 50) + 1);
            if (out.length) {
                if (typeof pushNews === 'function') {
                    pushNews('邸报', out.length + ' 事：' + out.map(function(x){return x.txt;}).join(' '), 'critical');
                }
            }
            return out;
        } catch (e) { return []; }
    };


    console.log('✓ v8.2 战争内核已装载（7 敌国 · 15 据点 · 8 地形 · 攻防公式 · 叛乱蔓延）');
})();