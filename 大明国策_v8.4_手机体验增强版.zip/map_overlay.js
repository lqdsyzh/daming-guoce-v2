// ============================================
// 《大明国策》v8.1 地图态势层
// 军务（驻军/行军路线/战场）· 商路 · 驿路漕运 · 地图事件
// 目标：地图是"活的"，不是静态图
// ============================================

(function () {
    'use strict';
    if (window._v81OverlayInstalled) return;
    window._v81OverlayInstalled = true;

    // ====== 卫所与重镇（驻军点）======
    var GARRISON_NODES = [
        { id:'jing',     nm:'京师三大营', lon:116.4, lat:39.9, troops:150000, kind:'京营' },
        { id:'guyuan',   nm:'固原镇',     lon:106.2, lat:36.0, troops:60000,  kind:'边军' },
        { id:'ningxia',  nm:'宁夏镇',     lon:106.3, lat:38.4, troops:50000,  kind:'边军' },
        { id:'yansui',   nm:'延绥镇',     lon:109.7, lat:38.3, troops:70000,  kind:'边军' },
        { id:'gansu',    nm:'甘肃镇',     lon:98.3,  lat:39.7, troops:40000,  kind:'边军' },
        { id:'datong',   nm:'大同镇',     lon:113.3, lat:40.1, troops:55000,  kind:'边军' },
        { id:'xuanfu',   nm:'宣府镇',     lon:115.0, lat:40.7, troops:45000,  kind:'边军' },
        { id:'jizhou',   nm:'蓟州镇',     lon:117.0, lat:40.1, troops:90000,  kind:'边军' },
        { id:'liaodong', nm:'辽东都司',   lon:122.3, lat:41.0, troops:80000,  kind:'边军' },
        { id:'xian',     nm:'西安西安卫', lon:108.9, lat:34.3, troops:30000,  kind:'内地' },
        { id:'nanjing',  nm:'南京守备',   lon:118.8, lat:32.1, troops:45000,  kind:'京营' },
        { id:'chengdu',  nm:'成都卫',     lon:104.1, lat:30.7, troops:25000,  kind:'内地' },
        { id:'hangzhou',  nm:'杭州卫',     lon:120.2, lat:30.3, troops:22000,  kind:'内地' },
        { id:'guangzhou',nm:'广州卫',     lon:113.3, lat:23.1, troops:28000,  kind:'水陆' },
        { id:'fuzhou',   nm:'福建卫',     lon:119.3, lat:26.1, troops:18000,  kind:'水陆' },
        { id:'taiyuan',  nm:'太原镇',     lon:112.5, lat:37.8, troops:40000,  kind:'内地' },
        { id:'kaifeng',  nm:'开封卫',     lon:114.3, lat:34.8, troops:20000,  kind:'内地' },
        { id:'wuhan',    nm:'武昌卫',     lon:114.3, lat:30.6, troops:26000,  kind:'内地' },
        { id:'xian2',    nm:'西安卫备',   lon:109.0, lat:34.4, troops:16000,  kind:'内地' },
        { id:'dalian',   nm:'定辽卫',     lon:121.6, lat:38.9, troops:35000,  kind:'边军' }
    ];

    // ====== 驿路（京城辐射，明代驿递）======
    var POST_ROUTES = [
        { nm:'官道·京师至辽东', pts:[[116.4,39.9],[117.0,40.1],[119.0,39.9],[121.6,38.9]] },
        { nm:'官道·京师至大同', pts:[[116.4,39.9],[115.0,40.7],[113.3,40.1]] },
        { nm:'官道·京师至宣府', pts:[[116.4,39.9],[115.0,40.7]] },
        { nm:'官道·京师至山西', pts:[[116.4,39.9],[114.3,36.5],[112.5,37.8]] },
        { nm:'官道·京师至西安', pts:[[116.4,39.9],[114.3,34.8],[111.0,34.7],[108.9,34.3]] },
        { nm:'官道·京师至南京', pts:[[116.4,39.9],[117.5,35.5],[118.8,32.1]] },
        { nm:'官道·南京至杭州', pts:[[118.8,32.1],[120.2,30.3]] },
        { nm:'官道·南京至广州', pts:[[118.8,32.1],[116.5,29.0],[113.3,23.1]] },
        { nm:'官道·西安至成都', pts:[[108.9,34.3],[105.0,31.5],[104.1,30.7]] },
        { nm:'官道·太原至西安', pts:[[112.5,37.8],[110.5,35.0],[108.9,34.3]] },
        { nm:'官道·延绥至宁夏', pts:[[109.7,38.3],[107.0,38.0],[106.3,38.4]] },
        { nm:'官道·延绥至大同', pts:[[109.7,38.3],[111.5,39.2],[113.3,40.1]] },
        { nm:'官道·甘肃至延绥', pts:[[98.3,39.7],[101.5,38.5],[104.0,37.8],[106.3,38.4],[109.7,38.3]] },
        { nm:'官道·武昌至成都', pts:[[114.3,30.6],[110.0,29.5],[104.1,30.7]] },
        { nm:'官道·武昌至福州', pts:[[114.3,30.6],[115.5,27.5],[119.3,26.1]] }
    ];

    // ====== 商路（四大商帮 + 边境榷场）======
    var TRADE_ROUTES = [
        { nm:'晋商·太原至江南', pts:[[112.5,37.8],[114.3,34.8],[118.8,32.1],[120.2,30.3]], cargo:'布帛铁器' },
        { nm:'晋商·大同马市',   pts:[[112.5,37.8],[113.3,40.1],[114.5,41.2]], cargo:'马匹皮货' },
        { nm:'徽商·徽州至苏杭', pts:[[118.0,29.6],[118.8,32.1],[120.2,30.3]], cargo:'茶漆纸墨' },
        { nm:'闽商·泉州至广州', pts:[[118.6,24.9],[117.0,23.5],[113.3,23.1]], cargo:'海货香料' },
        { nm:'粤商·广州至闽浙', pts:[[113.3,23.1],[117.0,23.5],[119.3,26.1],[120.2,30.3]], cargo:'象牙珠宝' },
        { nm:'龙马互市·延绥',   pts:[[109.7,38.3],[110.8,39.6]], cargo:'茶马互易' },
        { nm:'茶马互市·洮岷',   pts:[[103.8,36.1],[101.5,38.5]], cargo:'茶马互易' },
        { nm:'漕运·运河沿线',   pts:[[116.4,39.9],[116.4,36.5],[117.5,34.0],[118.8,32.1],[120.2,30.3],[121.5,30.9]], cargo:'漕粮' },
        { nm:'蜀道·剑门驿道',   pts:[[104.1,30.7],[106.0,32.5],[108.9,34.3]], cargo:'蜀锦盐巴' },
        { nm:'海上丝路·泉州',   pts:[[118.6,24.9],[121.5,30.9],[118.8,32.1]], cargo:'外舶奇货' }
    ];

    // ====== 地图事件（跟随地点发生，可处理）======
    var MAP_EVENTS = [
        // —— 兵事（16）——
        { id:'e_fire',    nm:'烽燧',     icon:'烽', kind:'war',   desc:'边镇烽火起，虏骑入犯。', seas:[0,1,2,3], grps:['border'], w:1.2 },
        { id:'e_bandit',  nm:'流寇',     icon:'寇', kind:'war',   desc:'流民聚而为盗，剽掠州县。', seas:[1,2,3], grps:['border','plain','poor'], w:1.0 },
        { id:'e_rebel',   nm:'民变',     icon:'变', kind:'war',   desc:'百姓聚众抗赋，杀官劫狱。', seas:[0,1,2,3], grps:['poor'], w:1.1 },
        { id:'e_riot',    nm:'兵哗',     icon:'哗', kind:'war',   desc:'边军缺饷，鼓噪索饷。', seas:[0,2], grps:['border'], w:0.9 },
        { id:'e_merit',   nm:'军功',     icon:'功', kind:'war',   desc:'边将斩获，捷报到京。', seas:[0,1,2,3], grps:['border'], w:1.0 },
        { id:'e_desert',  nm:'逃军',     icon:'逃', kind:'war',   desc:'戍卒苦役逃归，沿途劫掠。', seas:[0,1,2,3], grps:['border'], w:0.8 },
        { id:'e_ambush',  nm:'伏击',     icon:'伏', kind:'war',   desc:'商旅遇伏于山径，货尽人亡。', seas:[1,2], grps:['border','hill'], w:0.9 },
        { id:'e_siege',   nm:'围城',     icon:'围', kind:'war',   desc:'贼众蚁附城下，羽檄飞驰。', seas:[0,1,2,3], grps:['poor','plain'], w:0.9 },
        { id:'e_wei',     nm:'佥寇',     icon:'佥', kind:'war',   desc:'有司买嘱军士为倭奴，编伍成军。', seas:[0,1,2,3], grps:['coast'], w:0.7 },
        { id:'e_militia', nm:'乡兵',     icon:'乡', kind:'war',   desc:'民兵自备器械，保卫乡里。', seas:[0,1,2,3], grps:['poor','plain'], w:0.8 },
        { id:'e_hanjian', nm:'汉奸',     icon:'奸', kind:'war',   desc:'边民为虏向导，泄露我军虚实。', seas:[0,1,2,3], grps:['border'], w:0.8 },
        { id:'e_qiuzhu',  nm:'乞降',     icon:'降', kind:'war',   desc:'小股残寇乞降，求编入军籍。', seas:[0,1,2,3], grps:['border'], w:0.7 },
        { id:'e_lieji',   nm:'猎场',     icon:'猎', kind:'war',   desc:'诸卫协同出塞，大猎于边外。', seas:[0,3], grps:['border'], w:0.7 },
        { id:'e_tu寇',    nm:'突寇',     icon:'突', kind:'war',   desc:'寇骑昼夜驰突，官军追之不及。', seas:[2,3], grps:['border'], w:1.0 },
        { id:'e_yanhai',  nm:'沿海警',   icon:'海', kind:'war',   desc:'海上有舟，焚掠村落而去。', seas:[0,1,2,3], grps:['coast'], w:1.0 },
        { id:'e_zuobing', nm:'溃兵',     icon:'溃', kind:'war',   desc:'败兵散归，沿途劫掠州县。', seas:[0,1,2,3], grps:['poor','border'], w:0.8 },

        // —— 灾异（18）——
        { id:'e_plague',  nm:'疫疠',     icon:'疫', kind:'disaster', desc:'大疫，十室九空。', seas:[1,2,3], grps:[], w:1.0 },
        { id:'e_locust',  nm:'蝗蝻',     icon:'蝗', kind:'disaster', desc:'飞蝗蔽天，稼穑殆尽。', seas:[1,2], grps:['plain'], w:1.1 },
        { id:'e_flood',   nm:'河决',     icon:'洪', kind:'disaster', desc:'黄河决口，淹没民田。', seas:[1,2], grps:['plain','river'], w:1.0 },
        { id:'e_drought', nm:'赤旱',     icon:'旱', kind:'disaster', desc:'井泉皆竭，禾苗枯死。', seas:[1,2,3], grps:['plain'], w:1.0 },
        { id:'e_famine',  nm:'饥馑',     icon:'饥', kind:'disaster', desc:'人相食，户口凋敝。', seas:[2,3], grps:['poor'], w:1.2 },
        { id:'e_immig',   nm:'流民',     icon:'流', kind:'disaster', desc:'流民入境，争夺田土。', seas:[2,3], grps:['plain','poor'], w:1.0 },
        { id:'e_hail',    nm:'雹灾',     icon:'雹', kind:'disaster', desc:'大冰雹自天而下，击坏庐舍。', seas:[0,1], grps:[], w:0.7 },
        { id:'e_wind',    nm:'风灾',     icon:'风', kind:'disaster', desc:'飓风大作，舟覆屋倾。', seas:[1,2,3], grps:['coast'], w:0.8 },
        { id:'e_snow',    nm:'雪灾',     icon:'雪', kind:'disaster', desc:'大雪没膝，牛羊冻毙。', seas:[3], grps:['border','plain'], w:0.8 },
        { id:'e_earth',   nm:'地震',     icon:'震', kind:'disaster', desc:'地动山摇，压毁城池。', seas:[0,1,2,3], grps:[], w:0.6 },
        { id:'e_worm',    nm:'螟蝥',     icon:'螟', kind:'disaster', desc:'螟蝥蚀苗，禾稼立尽。', seas:[1,2], grps:['plain'], w:0.7 },
        { id:'e_salt',    nm:'盐荒',     icon:'盐', kind:'disaster', desc:'灶户逃散，盐课无出。', seas:[0,1,2,3], grps:['coast'], w:0.7 },
        { id:'e_iron',    nm:'铁课',     icon:'铁', kind:'disaster', desc:'山场禁采，匠户星散。', seas:[0,1,2,3], grps:[], w:0.6 },
        { id:'e_wood',    nm:'木折',     icon:'木', kind:'disaster', desc:'大风折木，舟材不足。', seas:[1,2,3], grps:[], w:0.6 },
        { id:'e_boar',    nm:'虎患',     icon:'虎', kind:'disaster', desc:'虎狼入村，伤人畜无数。', seas:[0,1,2,3], grps:['hill','mount'], w:0.6 },
        { id:'e_witch',   nm:'妖言',     icon:'妖', kind:'disaster', desc:'妖言惑众，指斥官长。', seas:[0,1,2,3], grps:['poor'], w:0.7 },
        { id:'e_orphan',  nm:'弃婴',     icon:'弃', kind:'disaster', desc:'荒年妇孺露宿，弃婴塞道。', seas:[2,3], grps:['poor'], w:0.6 },
        { id:'e_rodent',  nm:'鼠患',     icon:'鼠', kind:'disaster', desc:'鼠患纵横，仓廪为墟。', seas:[2,3], grps:[], w:0.5 },

        // —— 商贸（10）——
        { id:'e_trade',   nm:'商变',     icon:'商', kind:'trade',  desc:'商路梗阻，税入大减。', seas:[0,1,2,3], grps:[], w:1.0 },
        { id:'e_boom',    nm:'商盛',     icon:'盈', kind:'trade',  desc:'百货骈填，关税大增。', seas:[0,1,2,3], grps:['rich','coast'], w:1.0 },
        { id:'e_silver',  nm:'银贵',     icon:'银', kind:'trade',  desc:'白银输入既少，谷价腾踊。', seas:[0,1,2,3], grps:[], w:0.9 },
        { id:'e_jin',     nm:'禁榷',     icon:'禁', kind:'trade',  desc:'海禁申严，番商不至。', seas:[0,1,2,3], grps:['coast'], w:0.8 },
        { id:'e_tea',     nm:'茶滞',     icon:'茶', kind:'trade',  desc:'边茶积压，茶马不成。', seas:[0,1,2,3], grps:['border'], w:0.8 },
        { id:'e_horse',   nm:'马乏',     icon:'马', kind:'trade',  desc:'马政废弛，战马不足。', seas:[0,1,2,3], grps:['border'], w:0.8 },
        { id:'e_grain',   nm:'谷贵',     icon:'谷', kind:'trade',  desc:'商贩闭籴，谷价腾踊。', seas:[2,3], grps:['plain','poor'], w:1.0 },
        { id:'e_bribes',  nm:'抽丰',     icon:'抽', kind:'trade',  desc:'关吏苛抽，商贾裹足。', seas:[0,1,2,3], grps:[], w:0.8 },
        { id:'e_lucky',   nm:'市舶',     icon:'舶', kind:'trade',  desc:'番舶来朝，市舶司开验。', seas:[1,2,3], grps:['coast'], w:0.8 },
        { id:'e_famine_p',nm:'粜不足',   icon:'粜', kind:'trade',  desc:'常平仓虚，平粜无粮可发。', seas:[1,2,3], grps:['poor'], w:0.9 },

        // —— 国政（10）——
        { id:'e_censor',  nm:'大狱',     icon:'狱', kind:'politics', desc:'缇骑四出，士大夫人人自危。', seas:[0,1,2,3], grps:[], w:0.9 },
        { id:'e_donate',  nm:'捐纳',     icon:'捐', kind:'politics', desc:'开例卖官，国本虚耗。', seas:[0,1,2,3], grps:[], w:0.8 },
        { id:'e_yanhu',   nm:'延壅',     icon:'壅', kind:'politics', desc:'章奏留中不报，上下壅塞。', seas:[0,1,2,3], grps:[], w:0.8 },
        { id:'e_impeach', nm:'弹章',     icon:'弹', kind:'politics', desc:'言官交劾，党争益烈。', seas:[0,1,2,3], grps:[], w:0.9 },
        { id:'e_royal',   nm:'宗藩',     icon:'宗', kind:'politics', desc:'亲王请赋，部院难从。', seas:[0,1,2,3], grps:['rich'], w:0.7 },
        { id:'e_famine_g',nm:'国恤',     icon:'恤', kind:'politics', desc:'灾伤奏闻，请发帑赈济。', seas:[1,2,3], grps:['poor'], w:0.9 },
        { id:'e_li',      nm:'吏缺',     icon:'缺', kind:'politics', desc:'有司久缺，政事为之不举。', seas:[0,1,2,3], grps:['poor'], w:0.8 },
        { id:'e_taichi',  nm:'太仓',     icon:'仓', kind:'politics', desc:'太仓告竭，度支窘迫。', seas:[2,3], grps:[], w:0.9 },
        { id:'e_exam',    nm:'科场',     icon:'科', kind:'politics', desc:'主司帘前公询，关节潜通。', seas:[0,3], grps:[], w:0.7 },
        { id:'e_relief',  nm:'蠲免',     icon:'蠲', kind:'politics', desc:'灾伤之后，奏请蠲免赋税。', seas:[2,3], grps:['poor'], w:0.8 }
    ];

    // ====== 状态 ======
    function initOverlay() {
        return {
            layers: { mil: true, trade: true, post: true, event: true },
            armies: [],       // 行军中的部队
            mapEvents: [],   // 地图上的事件标记
            marches: [],      // 历史行军记录
            tradeIncome: 0,
            lastEventTick: -1
        };
    }
    function ov() {
        if (typeof GameState === 'undefined' || !GameState) return initOverlay();
        if (!GameState.mapOverlay) GameState.mapOverlay = initOverlay();
        var o = GameState.mapOverlay;
        if (!o.layers) o.layers = { mil: true, trade: false, post: false, event: true };
        if (!Array.isArray(o.armies)) o.armies = [];
        if (!Array.isArray(o.mapEvents)) o.mapEvents = [];
        if (!Array.isArray(o.marches)) o.marches = [];
        return o;
    }

    // ====== 派兵行军 ======
    function dispatchArmy(fromId, toId, troops, name) {
        try {
            var o = ov();
            var from = byNode(fromId), to = byNode(toId);
            if (!from || !to) return null;
            if (troops > from.troops) {
                if (typeof pushNews === 'function') pushNews('兵部', from.nm + '现存兵不足 ' + troops + '。', 'critical');
                return null;
            }
            from.troops -= troops;
            
            var dist = distKm(from.lon, from.lat, to.lon, to.lat);
            var months = Math.max(1, Math.round(dist / 800));   // 每月行 800 里
            var cost = Math.round(troops * months * 1.2);       // 粮饷

            var army = {
                id: 'a' + Date.now(),
                name: name || (from.nm + '军'),
                from: fromId, to: toId,
                troops: troops,
                monthsLeft: months,
                totalMonths: months,
                progress: 0,
                cost: cost,
                at: { lon: from.lon, lat: from.lat }
            };
            o.armies.push(army);
            o.marches.push({ id: army.id, nm: army.name, from: from.nm, to: to.nm, t: (GameState.currentYear||0) });
            
            if (typeof pushNews === 'function') {
                pushNews('兵部', army.name + '发兵' + troops + '人赴' + to.nm + '，行军' + months + '月，耗费粮饷' + cost + '石。', 'normal');
            }
            if (typeof saveGame === 'function') { try { saveGame(); } catch (e) {} }
            if (typeof atlRenderNow === 'function') atlRenderNow();
            return army;
        } catch (e) { return null; }
    }

    function byNode(id) {
        for (var i = 0; i < GARRISON_NODES.length; i++) if (GARRISON_NODES[i].id === id) return GARRISON_NODES[i];
        return null;
    }

    function distKm(lon1, lat1, lon2, lat2) {
        var R = 6371, dLat = (lat2 - lat1) * Math.PI / 180, dLon = (lon2 - lon1) * Math.PI / 180;
        var a = Math.sin(dLat/2)*Math.sin(dLat/2) + Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLon/2)*Math.sin(dLon/2);
        var km = 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return km / 0.5;   // 明代 1 里 = 0.5 公里
    }

    // 推进行军（每季调用）
    function advanceArmies() {
        try {
            var o = ov();
            if (!o.armies.length) return;
            var arrived = [];
            for (var i = o.armies.length - 1; i >= 0; i--) {
                var a = o.armies[i];
                var f = byNode(a.from), t = byNode(a.to);
                if (!f || !t) { o.armies.splice(i, 1); continue; }
                a.monthsLeft--;
                a.progress = 1 - (a.monthsLeft / Math.max(1, a.totalMonths));
                a.at = { lon: f.lon + (t.lon - f.lon) * a.progress, lat: f.lat + (t.lat - f.lat) * a.progress };
                if (a.monthsLeft <= 0) {
                    arrived.push(a);
                    o.armies.splice(i, 1);
                }
            }
            for (var j = 0; j < arrived.length; j++) {
                var ar = arrived[j];
                var to = byNode(ar.to);
                if (to) to.troops += ar.troops;
                if (typeof pushNews === 'function') {
                    pushNews('战报', ar.name + '已至' + to.nm + '，兵' + ar.troops + '人。', 'normal');
                }
            }
            if (arrived.length && typeof atlRenderNow === 'function') atlRenderNow();
        } catch (e) {}
    }

    // ====== 地图事件生成（每季）======
    function generateMapEvent() {
        try {
            var o = ov();
            var tick = (GameState.currentYear||0)*4 + (GameState.currentSeason||0);
            if (o.lastEventTick === undefined) o.lastEventTick = -1;
            if (tick - o.lastEventTick < 1) return;
            o.lastEventTick = tick;
            if (Math.random() > 0.55) return;   // 45% 概率
            
            // 随机省份
            var provs = (typeof ATLAS_LIST !== 'undefined') ? ATLAS_LIST : [];
            if (!provs.length) return;
            var p = provs[Math.floor(Math.random() * provs.length)];
            
            // v8.3 事件分派：季节 + 地域 + 权重（加权随机，非等概率）
            var season = GameState.currentSeason || 0;
            var pool = MAP_EVENTS.filter(function (e) {
                if (e.seas && e.seas.length && e.seas.indexOf(season) < 0) return false;
                if (e.grps && e.grps.length && e.grps.indexOf(p.grp) < 0) return false;
                return true;
            });
            if (!pool.length) pool = MAP_EVENTS.slice();
            // 加权随机
            var totalW = 0;
            pool.forEach(function (e) { totalW += (e.w || 1); });
            var rr = Math.random() * totalW, acc = 0, ev = pool[pool.length - 1];
            for (var pi2 = 0; pi2 < pool.length; pi2++) {
                acc += (pool[pi2].w || 1);
                if (rr <= acc) { ev = pool[pi2]; break; }
            }
            o.mapEvents.push({
                uid: 'me' + Date.now(),
                tpl: ev.id, nm: ev.nm, icon: ev.icon, kind: ev.kind,
                desc: ev.desc,
                prov: p.id, provNm: p.nm,
                lon: p.lon, lat: p.lat,
                age: 0, handled: false
            });
            
            if (typeof pushNews === 'function') {
                pushNews('邸报', p.nm + '有' + ev.nm + '：' + ev.desc, 'critical');
            }
            if (typeof atlRenderNow === 'function') atlRenderNow();
        } catch (e) {}
    }

    // 处理地图事件
    function resolveMapEvent(uid, choice) {
        try {
            var o = ov();
            for (var i = 0; i < o.mapEvents.length; i++) {
                var e = o.mapEvents[i];
                if (e.uid !== uid) continue;
                
                var res = '';
                if (choice === 'relief') {
                    var cost = 800;
                    if (GameState.stats.treasury < cost) {
                        if (typeof pushNews === 'function') pushNews('内库', '国库不足，不能赈济。', 'critical');
                        return;
                    }
                    GameState.stats.treasury -= cost;
                    GameState.stats.stability = clamp(GameState.stats.stability + 5);
                    GameState.stats.publicOpinion = clamp((GameState.stats.publicOpinion||50) + 4);
                    res = '发帑' + cost + '两往' + e.provNm + '，事遂平。';
                } else if (choice === 'troops') {
                    var cost2 = 1500;
                    if (GameState.stats.treasury < cost2) {
                        if (typeof pushNews === 'function') pushNews('内库', '国库不足，不能兴兵。', 'critical');
                        return;
                    }
                    GameState.stats.treasury -= cost2;
                    GameState.stats.militaryPower = (GameState.stats.militaryPower||0) + 300;
                    GameState.stats.stability = clamp(GameState.stats.stability + 3);
                    res = '发兵三千往' + e.provNm + '，事定。';
                } else if (choice === 'ignore') {
                    GameState.stats.stability = clamp(GameState.stats.stability - 6);
                    GameState.stats.publicOpinion = clamp((GameState.stats.publicOpinion||50) - 6);
                    res = '置之不问，' + e.provNm + '之患益深。';
                } else if (choice === 'query') {
                    res = '遣官驰驿往' + e.provNm + '查勘，俟实情以闻。';
                }
                
                e.handled = true;
                e.result = res;
                if (typeof pushNews === 'function') pushNews('圣裁', res, 'normal');
                if (typeof saveGame === 'function') { try { saveGame(); } catch (e) {} }
                if (typeof atlRenderNow === 'function') atlRenderNow();
                break;
            }
        } catch (e) {}
    }
    function clamp(v) { return Math.max(0, Math.min(100, Math.round(Number(v)||0))); }

    // ====== 贸易收益（每季）======
    function tradeTick() {
        try {
            var o = ov();
            if (!o.layers.trade) return;
            var income = 0;
            for (var i = 0; i < TRADE_ROUTES.length; i++) {
                var r = TRADE_ROUTES[i];
                var base = Math.round(r.cargo.length * 40 * (0.6 + (GameState.stats.commerce||30)/80));
                income += base;
            }
            o.tradeIncome = income;
            GameState.stats.treasury += income;
            GameState.stats.commerce = clamp((GameState.stats.commerce||30) + 0.4);
            if (typeof pushNews === 'function') {
                pushNews('商课', '诸路商税共入 ' + income + '两。', 'normal');
            }
        } catch (e) {}
    }

    // ====== 敌国入侵 → 地图事件（可点选处置）======
    // 敌国不直接扣数值，而是打到边境省，生成"敌寇入边"事件
    // 事件可拖到第 3 季，届时若未处置则该省沦陷（这才是"会打下来"）
    function addInvasion(zoneId, zoneNm, powNm, enemyTroops, provId) {
        try {
            var o = ov();
            var provs = (typeof ATLAS_LIST !== 'undefined') ? ATLAS_LIST : [];
            var p = provs.filter(function (x) { return x.id === provId; })[0];
            if (!p) {
                // 未指定省份：按经纬度就近取
                var w = (typeof WAR !== 'undefined') ? WAR.state() : null;
                var z = w ? w.zones.filter(function (x) { return x.id === zoneId; })[0] : null;
                if (!z) return;
                var best = null, bd = 1e9;
                provs.forEach(function (x) {
                    var d = Math.abs(x.lon - z.lon) + Math.abs(x.lat - z.lat);
                    if (d < bd) { bd = d; best = x; }
                });
                p = best;
            }
            if (!p) return;

            o.mapEvents.push({
                uid: 'inv' + Date.now() + Math.floor(Math.random() * 999),
                tpl: 'e_invasion', nm: '敌寇入边', icon: '寇', kind: 'invasion',
                desc: powNm + '·' + zoneNm + '兴兵来犯，前锋已至' + p.nm + '。',
                prov: p.id, provNm: p.nm,
                lon: p.lon, lat: p.lat,
                zoneId: zoneId,
                enemyTroops: enemyTroops,
                age: 0, handled: false
            });
            if (typeof pushNews === 'function') {
                pushNews('邸报', powNm + '·' + zoneNm + '来犯' + p.nm + '，边将告急！', 'critical');
            }
            if (typeof atlRenderNow === 'function') atlRenderNow();
        } catch (e) {}
    }

    // 未处置的入侵逐季推进：第三季若仍不决，则沦陷
    function invasionTick() {
        try {
            var o = ov();
            var fallen = [];
            for (var i = o.mapEvents.length - 1; i >= 0; i--) {
                var e = o.mapEvents[i];
                if (e.kind !== 'invasion' || e.handled) continue;
                e.age++;
                if (e.age >= 3) {
                    // 沦陷：驻军损失、省份怨望暴涨、物资被掠
                    var prov = (GameState.province && GameState.province.prov) ? GameState.province.prov[e.prov] : null;
                    if (prov) prov.disaffect = clamp(num(prov.disaffect, 20) + 30);
                    var lost = Math.round(num(e.enemyTroops, 5000) * 0.18);
                    // v8.2 校准：沦陷损失封顶（原本一次沦陷可吞掉全部存粮）
                    GameState.stats.food = Math.max(0, num(GameState.stats.food, 0) - Math.min(600, Math.round(num(e.enemyTroops,5000) * 0.06)));
                    GameState.stats.treasury = Math.max(0, num(GameState.stats.treasury, 0) - Math.min(400, Math.round(num(e.enemyTroops,5000) * 0.03)));
                    GameState.stats.stability = clamp(num(GameState.stats.stability, 50) - 2);
                    // 找该省最近驻军，损兵
                    var near = null, bd = 1e9;
                    GARRISON_NODES.forEach(function (n) {
                        var d = Math.abs(n.lon - e.lon) + Math.abs(n.lat - e.lat);
                        if (d < bd) { bd = d; near = n; }
                    });
                    if (near) near.troops = Math.max(0, num(near.troops, 0) - lost);
                    fallen.push({ prov: e.provNm, loss: lost });
                    o.mapEvents.splice(i, 1);
                }
            }
            if (fallen.length && typeof pushNews === 'function') {
                pushNews('战报', '失守：' + fallen.map(function(f){ return f.prov + '（军亡'+f.loss+'）'; }).join('、') + '！烽燧已陷。', 'critical');
            }
            return fallen;
        } catch (e) { return []; }
    }

    // ====== 渲染辅助（供 atlas.js 调用）======
    window.OVL = {
        nodes: GARRISON_NODES,
        postRoutes: POST_ROUTES,
        tradeRoutes: TRADE_ROUTES,
        eventTpl: MAP_EVENTS,
        state: ov,
        dispatch: dispatchArmy,
        advance: advanceArmies,
        genEvent: generateMapEvent,
        resolve: resolveMapEvent,
        tradeTick: tradeTick,
        byNode: byNode,
        addInvasion: addInvasion,
        invasionTick: invasionTick
    };

    // ====== 图层开关 ======
    OVL.toggleLayer = function (k) {
        try {
            var o = ov();
            o.layers[k] = !o.layers[k];
            if (typeof saveGame === 'function') { try { saveGame(); } catch (e) {} }
            if (typeof atlRenderNow === 'function') atlRenderNow();
        } catch (e) {}
    };

    // ====== 每季钩子 ======
    OVL.seasonTick = function () {
        try {
            advanceArmies();
            generateMapEvent();
            tradeTick();
        } catch (e) {}
    };

    console.log('✓ v8.1 地图态势层已装载（军务·商路·驿路·地图事件）');
})();
