# 大明国策 v8.4 手机体验增强版

## 本次更新
- 修正主页面版本标识为 v8.4。
- 补齐 PWA 所需的 192×192 与 512×512 应用图标。
- PWA 显示模式调整为 standalone，适合从桌面图标启动。
- Service Worker 缓存项目内 HTML、CSS、JavaScript、JSON 与图像资源。
- 离线时仅对页面导航回退到首页，避免把 HTML 错误返回给脚本或样式请求。
- 清理旧缓存时仅删除本游戏专属前缀的缓存，不触碰同源其他应用缓存。
- 增加手机安全区、输入框字号与键盘焦点可见性优化。
- 为原本空白的 military_tech_ext.js 添加兼容占位说明，未擅自编造游戏机制。

## 说明
- 保留原有游戏系统与数据文件；未删除 china_geo.js / china_geo.json，避免破坏未知运行依赖。
- 需要通过 HTTPS 网站或 localhost 运行，Service Worker/PWA 不能在普通 file:// 方式下完整工作。
- 本次完成静态资源与 JavaScript 语法检查；当前环境未能启动真实浏览器进行完整交互测试，建议部署后在 Android Chrome 实机验证。
