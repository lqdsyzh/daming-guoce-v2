// ============================================
// 《大明国策》v8.3 存档版本迁移
// 老存档不可弃：逐版本补齐缺失字段，并留备份
// 版本沿革：
//   v1  初始（v6.4 界面收敛前）
//   v2  首页聚合 / 数值净化
//   v3  v8.1 地图态势层（行军·商路·驿路·地图事件）
//   v4  v8.2 战争内核（敌国·叛乱·战报）
//   v5  v8.3 名将库 / 舆图建设 / 战略战术对接
// ============================================

(function () {
    'use strict';
    if (window._v83Migrate) return;
    window._v83Migrate = true;

    var SAVE_VERSION = 5;

    // ====== 补齐：确保某对象有某字段，否则用工厂生成 ======
    function ensure(obj, key, factory) {
        try {
            if (!obj) return null;
            if (obj[key] === undefined || obj[key] === null) {
                obj[key] = typeof factory === 'function' ? factory() : factory;
            }
            return obj[key];
        } catch (e) { return null; }
    }

    // ====== 主迁移 ======
    function migrate(save) {
        var notes = [];
        try {
            if (!save || typeof save !== 'object') return { ok: false, notes: ['存档格式不可辨'] };

            var from = save.saveVersion || 1;
            if (from >= SAVE_VERSION) return { ok: true, notes: [], version: from };

            // --- v2：首页聚合状态 ---
            if (from < 2) {
                ensure(save, 'homeState', function () { return { active: {}, opened: {}, _loaded: {} }; });
                notes.push('补首页聚合状态');
            }

            // --- v3：地图态势层 ---
            if (from < 3) {
                if (!save.mapOverlay) {
                    save.mapOverlay = (typeof OVL !== 'undefined' && OVL.state) ? OVL.state()
                        : { armies: [], mapEvents: [], tradeIncome: 0, layers: { mil: true, trade: true, post: true, event: true }, lastEventTick: -1 };
                }
                notes.push('补地图态势层（行军/商路/驿路/地图事件）');
            }

            // --- v4：战争内核 ---
            if (from < 4) {
                if (!save.warSim) {
                    save.warSim = (typeof WAR !== 'undefined' && WAR.init) ? WAR.init()
                        : { zones: [], rebels: [], battles: [], suppressions: 0, sieges: 0 };
                }
                notes.push('补战争内核（敌国据点/叛乱/战报）');
            }

            // --- v5：名将库 / 舆图建设 / 外交联动 ---
            if (from < 5) {
                if (!save.mapBuild) {
                    save.mapBuild = (typeof BUILD !== 'undefined' && BUILD.init) ? BUILD.init()
                        : { sites: [], pending: [] };
                }
                // 战争内核补字段（内联，不改旧档结构）
                var w = save.warSim;
                if (w) {
                    if (!Array.isArray(w.rebels)) w.rebels = [];
                    if (!Array.isArray(w.battles)) w.battles = [];
                    if (typeof w.invasionCd !== 'number') w.invasionCd = 0;
                    w.rebels.forEach(function (r) {
                        if (typeof r.kind !== 'string') r.kind = 'minbian';
                        if (typeof r.kindNm !== 'string') r.kindNm = '民变';
                        if (typeof r.betrayed !== 'boolean') r.betrayed = false;
                        if (typeof r.ally !== 'string') r.ally = null;
                    });
                }
                notes.push('补名将库配套与舆图建设');
            }

            save.saveVersion = SAVE_VERSION;
            return { ok: true, notes: notes, version: SAVE_VERSION };
        } catch (e) {
            return { ok: false, notes: ['迁移出错：' + (e && e.message)] };
        }
    }

    // ====== 带备份的存档（写新档前先留一份旧档） ======
    function safeSave(saveData, key) {
        try {
            var old = localStorage.getItem(key);
            if (old) {
                try { localStorage.setItem(key + '_bak', old); } catch (e) {}
            }
            localStorage.setItem(key, JSON.stringify(saveData));
            return true;
        } catch (e) { return false; }
    }

    window.MIGRATE = {
        VERSION: SAVE_VERSION,
        migrate: migrate,
        safeSave: safeSave
    };

    console.log('✓ v8.3 存档迁移已装载（当前版本 v' + SAVE_VERSION + '）');
})();
