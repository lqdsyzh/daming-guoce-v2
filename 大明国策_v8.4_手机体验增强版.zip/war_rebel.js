// ============================================
// 《大明国策》v8.3 叛乱深化
// 类型分化 · 投敌 · 招安 · 劫掠商路 · 蔓延择向
// 史据：《明史》卷309·李自成传 / 卷328·流贼列传 / 卷332·李岩传 /
//       卷251·徐有贞（白莲教徐鸿儒）/ 卷299·李化龙传（播州杨应龙）
// 铁律：叛乱有因、有类、有首、有巢穴，会蔓延、会投敌、亦可招抚
// ============================================

(function () {
    'use strict';
    if (window._v83Rebel) return;
    window._v83Rebel = true;

    // ====== 叛乱类型 ======
    // spread 蔓延率 / raid 劫掠率 / power 战力系数 / morale 士气基 / src 出处
    var REBEL_KINDS = {
        liukou: {
            nm: '流寇', banner: '寇',
            spread: 0.55, raid: 0.75, power: 0.82, moraleBase: 42,
            desc: '流民聚而为盗，剽掠州县，无攻城之具而善夜行。',
            src: '《明史》卷328·流贼传：流贼皆失业之民，趋利如鹜，剽掠无虚日。'
        },
        minbian: {
            nm: '民变', banner: '变',
            spread: 0.28, raid: 0.35, power: 0.95, moraleBase: 58,
            desc: '百姓聚众抗赋，杀官劫狱，起于怨望，得了义名便不肯散。',
            src: '《明史》卷309·李自成传：饥旱相仍，税赋愈重，百姓乃相聚为乱。'
        },
        biabian: {
            nm: '边军哗变', banner: '哗',
            spread: 0.32, raid: 0.55, power: 1.28, moraleBase: 64,
            desc: '边军缺饷，鼓噪索饷，器械犀利而号令已乱。',
            src: '《明史》卷95·兵志：边军欠饷，哗噪散伍，为患甚于虏。'
        },
        bailian: {
            nm: '白莲教', banner: '莲',
            spread: 0.22, raid: 0.28, power: 0.88, moraleBase: 70,
            desc: '以符水疗病，阴聚党羽，以妖术惑众，事泄则一夕而空。',
            src: '《明史》卷251·徐有贞传：白莲教徐鸿儒以符水禁咒聚众于 Shandong 蓟州。'
        },
        neijian: {
            nm: '通倭内应', banner: '倭',
            spread: 0.40, raid: 0.60, power: 1.05, moraleBase: 60,
            desc: '通倭之徒，内应于城，导寇开门，其势最速。',
            src: '《明史》卷325·日本传：闽浙大倭，多由内应导之，宁波、温州尤甚。'
        }
    };

    // ====== 类型判定（依省情与全局形势） ======
    function decideKind(prov, pv, dis) {
        try {
            // 边地 + 军情不稳 → 边军哗变
            if (prov && prov.grp === 'border' && Math.random() < 0.34) return 'biabian';
            // 沿海 + 倭患 → 通倭内应
            if (prov && (prov.grp === 'coast') && Math.random() < 0.30) return 'neijian';
            // 怨望极高 + 白莲教盛行 → 白莲教
            if (dis > 78 && Math.random() < 0.26) return 'bailian';
            // 灾荒流民 → 流寇
            if (Math.random() < 0.42) return 'liukou';
            return 'minbian';
        } catch (e) { return 'minbian'; }
    }

    // ====== 首领名（按类型） ======
    var LEADERS = {
        liukou: ['张献忠', '李自成', '罗汝才', '马元利', '王嘉胤', '刘国能', '高迎祥', '李岩', '艾能善', '白彦章', '曹文诏', '王自国'],
        minbian: ['叶宗春', '许乃普', '陈文龙', '黄册吏', '梁汝球', '邓茂七', '叶明爱', '徐九万'],
        biabian: ['王守仁旧部', '罗明先', '杨洪基', '周尚文部曲', '刘綎旧部', '边民哗卒'],
        bailian: ['徐鸿儒', '王好汉', '张彦', '李福', '张寡妇', '王钺'],
        neijian: ['陈东部', '许文', '李文烨', '张大海', '倭酋内应']
    };

    // ====== 首领按类型取名 ======
    function pickLeader(kind) {
        try {
            var pool = LEADERS[kind] || LEADERS.liukou;
            return pool[Math.floor(Math.random() * pool.length)];
        } catch (e) { return '某'; }
    }

    // ====== 招安 ======
    // 成功率 = 官府威望 + 官军威慑 − 叛军战力 与 士卒离散度 的加权
    function amnesty(rebelId) {
        try {
            if (typeof WAR === 'undefined') return { ok: false, msg: '无此乱' };
            var w = WAR.state();
            var r = null;
            w.rebels.forEach(function (x) { if (x.id === rebelId) r = x; });
            if (!r) return { ok: false, msg: '此辈已平' };
            var st = GameState.stats;
            var cost = 1500 + Math.round(num(r.troops, 0) * 0.12);
            if (num(st.treasury, 0) < cost) return { ok: false, msg: '国库不足，抚恤无出（需 ' + cost + ' 两）' };

            var kind = REBEL_KINDS[r.kind] || REBEL_KINDS.liukou;
            // 招抚成功率：威望与军威压之，叛军势弱则易抚
            var prestige = num(st.prestige, 50);
            var mil = num(GameState.factions ? GameState.factions.military : 50, 50);
            var weak = 1 - Math.min(0.75, num(r.troops, 0) / 60000);
            var chance = (prestige * 0.4 + mil * 0.3 + weak * 40) / 100;
            chance = Math.max(0.05, Math.min(0.92, chance));

            st.treasury -= cost;
            if (Math.random() < chance) {
                // 抚成
                w.rebels = w.rebels.filter(function (x) { return x.id !== rebelId; });
                var pv = (GameState.province && GameState.province.prov) ? GameState.province.prov[r.prov] : null;
                if (pv) pv.disaffect = Math.max(0, num(pv.disaffect, 20) - 30);
                st.stability = Math.min(100, num(st.stability, 50) + 5);
                st.prestige = Math.min(100, num(st.prestige, 50) + 2);
                if (typeof pushNews === 'function') {
                    pushNews('招抚', '遣使抚谕' + r.provNm + '之' + kind.nm + '，散其党羽，胁从归农。费帑 ' + cost + ' 两。', 'normal');
                }
                return { ok: true, success: true, cost: cost, chance: chance };
            } else {
                // 抚而复叛
                r.morale = Math.min(95, num(r.morale, 60) + 6);
                r.troops = Math.round(num(r.troops, 0) * 1.04);
                if (typeof pushNews === 'function') {
                    pushNews('招抚', '遣使抚' + r.provNm + '之乱，不听，反而鼓其噪。费帑 ' + cost + ' 两。', 'critical');
                }
                return { ok: true, success: false, cost: cost, chance: chance };
            }
        } catch (e) { return { ok: false, msg: '招抚不成' }; }
    }

    // ====== 叛军投敌（最狠的一层） ======
    // 叛军势大且与某敌国接壤 → 该敌国获得"内应"加持
    function betrayCheck() {
        try {
            if (typeof WAR === 'undefined') return [];
            var w = WAR.state();
            var out = [];
            w.rebels.forEach(function (r) {
                if (r.betrayed) return;
                if (num(r.troops, 0) < 15000) return;
                if (num(r.morale, 60) < 55) return;
                if (Math.random() > 0.18) return;
                // 找最近的未服敌国
                var prov = null;
                if (typeof ATLAS_LIST !== 'undefined') ATLAS_LIST.forEach(function (x) { if (x.id === r.prov) prov = x; });
                if (!prov) return;
                var best = null, bd = 1e9;
                w.zones.forEach(function (z) {
                    if (z.occupied) return;
                    var d = Math.abs(z.lon - prov.lon) + Math.abs(z.lat - prov.lat);
                    if (d < bd) { bd = d; best = z; }
                });
                if (!best || bd > 12) return;
                r.betrayed = true;
                r.ally = best.pow;
                best.supply = Math.min(100, num(best.supply, 50) + 18);
                best.morale = Math.min(100, num(best.morale, 60) + 12);
                best.atk = num(best.atk, 1) + 0.15;
                try { WAR.syncNation(best.pow, 6, 6); } catch (e) {}
                if (typeof pushNews === 'function') {
                    pushNews('边情', r.leader + '既陷' + r.provNm + '，复通' + WAR.ENEMY_POWERS[best.pow].nm
                        + '为内应，虏得向导，其势益张。', 'critical');
                }
                out.push({ rebel: r, zone: best });
            });
            return out;
        } catch (e) { return []; }
    }

    // ====== 叛军劫掠商路（压低贸易收入） ======
    function raidTrade() {
        try {
            if (typeof WAR === 'undefined' || typeof OVL === 'undefined') return [];
            var w = WAR.state();
            var out = [];
            w.rebels.forEach(function (r) {
                var prov = null;
                if (typeof ATLAS_LIST !== 'undefined') ATLAS_LIST.forEach(function (x) { if (x.id === r.prov) prov = x; });
                if (!prov) return;
                var hit = null;
                if (OVL.tradeRoutes) {
                    OVL.tradeRoutes.forEach(function (t) {
                        if (!hit && t.pts) {
                            // 路线经过该省附近即视为被扰
                            t.pts.forEach(function (p) {
                                if (!hit && Math.abs(p[0] - prov.lon) < 2.5 && Math.abs(p[1] - prov.lat) < 2.5) hit = t;
                            });
                        }
                    });
                }
                if (!hit) return;
                var kind = REBEL_KINDS[r.kind] || REBEL_KINDS.liukou;
                if (Math.random() > kind.raid * 0.35) return;
                // 商路封锁：本季该项收入打折
                try { OVL.blockedRoutes = OVL.blockedRoutes || {}; } catch (e) {}
                if (typeof OVL !== 'undefined') {
                    OVL.blockedRoutes = OVL.blockedRoutes || {};
                    OVL.blockedRoutes[hit.nm] = 2;   // 封锁 2 季
                }
                if (typeof pushNews === 'function') {
                    pushNews('商路', r.leader + '焚掠' + hit.nm + '商道，榷税断绝者二月。', 'critical');
                }
                out.push({ rebel: r, route: hit });
            });
            return out;
        } catch (e) { return []; }
    }

    // ====== 蔓延择向（不再随机，向"富庶/空虚"方向蔓延） ======
    function pickNeighborTarget(r) {
        try {
            var provs = (typeof ATLAS_LIST !== 'undefined') ? ATLAS_LIST : [];
            var ns = (typeof WAR !== 'undefined') ? (WAR.NEIGHBOR[r.prov] || []) : [];
            var box = (GameState.province && GameState.province.prov) ? GameState.province.prov : {};
            var best = null, bestScore = -1;
            ns.forEach(function (id) {
                var p = null;
                provs.forEach(function (x) { if (x.id === id) p = x; });
                if (!p) return;
                var pv = box[id] || {};
                // 怨望高、空虚、易取者得分高
                var score = num(pv.disaffect, 20) * 0.6 + (100 - num(pv.arms, 40)) * 0.4;
                score += Math.random() * 15;
                if (score > bestScore) { bestScore = score; best = p; }
            });
            return best;
        } catch (e) { return null; }
    }

    window.REBEL = {
        KINDS: REBEL_KINDS,
        LEADERS: LEADERS,
        decideKind: decideKind,
        pickLeader: pickLeader,
        amnesty: amnesty,
        betrayCheck: betrayCheck,
        raidTrade: raidTrade,
        pickNeighborTarget: pickNeighborTarget
    };

    console.log('✓ v8.3 叛乱深化已装载（5 类叛乱 · 投敌 · 招安 · 劫路）');
})();
