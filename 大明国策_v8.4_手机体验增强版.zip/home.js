// ============================================
// 《大明国策》v7.0 界面收敛
// 全部功能收进首页，不跳页。
// 六大区块 · 手风琴折叠 · 区块内横切
// 铁律：不碰 edict 永久 DOM（edict-zone / edict-paper / edict-history-zone）
// ============================================

// ---- 六大区块定义（tabs 顺序即区块内横切顺序） ----
var HOME_BLOCKS = [
    {
        id: 'econ', title: '国用财政', icon: '财',
        desc: '田赋盐课 · 市易行情 · 漕运水利 · 营建匠作',
        open: true,
        tabs: [
            { tab: 'economy',     label: '国计' },
            { tab: 'finance',     label: '赋税' },
            { tab: 'markets',     label: '市易' },
            { tab: 'transport',   label: '漕运' },
            { tab: 'construction',label: '营建' }
        ]
    },
    {
        id: 'war', title: '军政兵备', icon: '兵',
        desc: '九边战守 · 军制科技 · 舆图省治 · 廷议干政',
        open: true,
        tabs: [
            { tab: 'military', label: '兵备' },
            { tab: 'map',      label: '舆图' },
            { tab: 'govern',   label: '新政' },
            { tab: 'court',    label: '朝议' },
            { tab: 'audit',    label: '审计' }
        ]
    },
    {
        id: 'court', title: '朝堂人事', icon: '朝',
        desc: '铨选任免 · 弹劾下狱 · 厂卫缉访 · 权谋倾轧 · 宦官内廷',
        open: true,
        tabs: [
            { tab: 'personnel', label: '铨选' },
            { tab: 'impeach',   label: '弹劾' },
            { tab: 'censor',    label: '宪台' },
            { tab: 'secret',    label: '厂卫' },
            { tab: 'intrigue',  label: '权谋' }
        ]
    },
    {
        id: 'inner', title: '宫廷内闱', icon: '宫',
        desc: '后妃恩眷 · 皇嗣储位 · 宫闱省视 · 教子训诫',
        open: false,
        tabs: [
            { tab: 'harem',   label: '后宫' },
            { tab: 'prince',  label: '皇嗣' },
            { tab: 'emperor', label: '圣躬' }
        ]
    },
    {
        id: 'people', title: '民生教化', icon: '民',
        desc: '灾异赈济 · 科举取士 · 营造技艺 · 岁末总评',
        open: false,
        tabs: [
            { tab: 'famine', label: '灾荒' },
            { tab: 'keju',   label: '科举' },
            { tab: 'tech',   label: '技艺' },
            { tab: 'yingzao',label: '营造' },
            { tab: 'yearend',label: '岁末' },
            { tab: 'decade', label: '纪年' }
        ]
    },
    {
        id: 'realm', title: '天下邦国', icon: '邦',
        desc: '藩贡宗室 · 四邻外交 · 王朝使命 · 存亡史评',
        open: false,
        tabs: [
            { tab: 'zongfan',  label: '宗藩' },
            { tab: 'tribute',  label: '朝贡' },
            { tab: 'diplomacy',label: '四邻' },
            { tab: 'mission',  label: '使命' },
            { tab: 'prison',   label: '囹圄' },
            { tab: 'share',    label: '存档' },
            { tab: 'compare',  label: '比较' }
        ]
    }
];

// 当前展开状态与区块内当前 tab
var _homeState = { open: {}, active: {} };

function homeInitState() {
    try {
        if (typeof GameState === 'undefined' || !GameState || !GameState.homeState) {
            if (typeof GameState !== 'undefined' && GameState) GameState.homeState = { open: {}, active: {} };
        }
        var st = (typeof GameState !== 'undefined' && GameState.homeState) ? GameState.homeState : _homeState;
        if (!st.open) st.open = {};
        if (!st.active) st.active = {};
        for (var i = 0; i < HOME_BLOCKS.length; i++) {
            var b = HOME_BLOCKS[i];
            if (st.open[b.id] === undefined) st.open[b.id] = b.open;
            if (!st.active[b.id]) st.active[b.id] = b.tabs[0].tab;
        }
    } catch (e) {}
}

// 取某 tab 的 HTML（复用 modules.js 的 renderPanel 逻辑，不写 DOM）
function homeTabHtml(tab) {
    try {
        var el = document.createElement('div');
        var saved = document.getElementById('center-panel');
        if (!saved) return '';
        // 直接调 renderPanel 会覆写 center-panel，这里改为临时劫持
        var fn = window.renderPanel;
        if (typeof fn !== 'function') return '';
        var result = homeSafeRenderPanel(tab, el);
        return result;
    } catch (e) {
        return '';
    }
}

// 极简：把 renderPanel 的 switch 复制一份做纯渲染
// 注意：部分旧 render 函数自己写 DOM 不返回字符串（如 renderHuBuDetail），
// 这里改为"临时替换 center-panel，调用后取回 innerHTML"
function homeSafeRenderPanel(tab, sink) {
    try {
        var panel = document.getElementById('center-panel');
        var oldHtml = panel ? panel.innerHTML : '';
        var html = '';
        switch (tab) {
            case 'overview':    html = (typeof renderOverview === 'function') ? renderOverview() : ''; break;
            case 'govern':      html = (typeof renderGovernTab === 'function') ? renderGovernTab() : ''; break;
            case 'politics':    html = renderPolitics(); break;
            case 'economy':     html = renderEconomy(); break;
            case 'personnel':   html = renderPersonnel(); break;
            case 'impeach':     html = renderImpeach(); break;
            case 'construction':html = renderConstruction(); break;
            case 'diplomacy':   html = renderDiplomacy() + (typeof renderDiploInteractTab === 'function' ? renderDiploInteractTab() : ''); break;
            case 'finance':     html = (typeof renderHuBuDetail === 'function') ? renderHuBuDetail() : ''; break;
            case 'military':    html = renderMilitaryOps() + (typeof renderMilitaryOpsExt === 'function' ? renderMilitaryOpsExt() : '') + (typeof renderWarDefTab === 'function' ? renderWarDefTab() : '') + (typeof renderMilTechTab === 'function' ? renderMilTechTab() : ''); break;
            case 'transport':   html = renderWaterSystem(); break;
            case 'prison':      html = renderSecretService(); break;
            case 'harem':       html = renderPalaceStaff() + (typeof renderHaremInteractTab === 'function' ? renderHaremInteractTab() : '') + (typeof renderHaremPrinceTab === 'function' ? renderHaremPrinceTab() : ''); break;
            case 'court':       html = renderCourtTab(); break;
            case 'keju':        html = renderKejuTab() + (typeof renderKejuDeepTab === 'function' ? renderKejuDeepTab() : ''); break;
            case 'yingzao':     html = renderYingzaoTab(); break;
            case 'tech':        html = renderSolarRituals() + (typeof renderLizhiTab === 'function' ? renderLizhiTab() : '') + (typeof renderAutoTab === 'function' ? renderAutoTab() : ''); break;
            case 'decade':      html = renderDecade(); break;
            case 'yearend':     html = (typeof renderYearendTab === 'function') ? renderYearendTab() : ''; break;
            case 'map':         html = (typeof window.renderAtlasTab === 'function') ? window.renderAtlasTab() : (typeof renderMapTab === 'function' ? renderMapTab() : ''); break;
            case 'audit':       html = (typeof window.AUDIT !== 'undefined' && AUDIT.render) ? AUDIT.render() : ''; break;
            case 'markets':     html = (typeof renderMarketV5 === 'function') ? renderMarketV5() : renderMarketPrices(); break;
            case 'censor':      html = renderCensor(); break;
            case 'secret':      html = (typeof renderCangweiTab === 'function') ? renderCangweiTab() : renderSecretService(); break;
            case 'intrigue':    html = (typeof renderIntrigueTab === 'function') ? renderIntrigueTab() : ''; break;
            case 'prince':      html = renderPrinces(); break;
            case 'selection':   html = renderSelection(); break;
            case 'tribute':     html = renderTribute(); break;
            case 'zongfan':     html = (typeof renderZongfanTab === 'function') ? renderZongfanTab() : ''; break;
            case 'famine':      html = renderFamineWarning() + (typeof renderZaiyiTab === 'function' ? renderZaiyiTab() : ''); break;
            case 'emperor':     html = renderEmperorTraits() + (typeof renderLizhiTab === 'function' ? renderLizhiTab() : '') + (typeof renderAutoTab === 'function' ? renderAutoTab() : ''); break;
            case 'share':       html = renderShare(); break;
            case 'compare':     html = renderCompare(); break;
            case 'mission':     html = (typeof renderMissionTab === 'function') ? renderMissionTab() : ''; break;
        }
        // 兜底：若函数自己写了 DOM（返回 undefined），从 center-panel 取回
        if (html === undefined || html === null || html === '') {
            if (panel && panel.innerHTML !== oldHtml) html = panel.innerHTML;
        }
        // 复原 center-panel，避免污染隐藏位
        if (panel) panel.innerHTML = oldHtml;
        return html || '<div class="home-block-err">此卷暂缺</div>';
    } catch (e) {
        return '<div class="home-block-err">此卷暂缺</div>';
    }
}

// 首页总渲染
function renderHome() {
    try {
        homeInitState();
        var st = GameState.homeState;

        var html = '<div class="home-wrap" id="home-wrap">';

        // 顶部总览
        html += '<div class="home-hero" id="home-hero"></div>';

        // 御前速览（今日待办 + 快捷施政）
        if (typeof window.v71Render === 'function') {
            html += window.v71Render();
        }

        // 六大区块
        for (var i = 0; i < HOME_BLOCKS.length; i++) {
            var b = HOME_BLOCKS[i];
            var isOpen = !!st.open[b.id];
            var activeTab = st.active[b.id] || b.tabs[0].tab;

            html += '<div class="home-block' + (isOpen ? ' open' : '') + '" id="hb-' + b.id + '">';

            // 区块头（可折叠）
            html += '<div class="home-block-head" onclick="homeToggle(\'' + b.id + '\')">'
                  + '<span class="hb-icon">' + b.icon + '</span>'
                  + '<span class="hb-title">' + b.title + '</span>'
                  + '<span class="hb-desc">' + b.desc + '</span>'
                  + '<span class="hb-arrow">' + (isOpen ? '▾' : '▸') + '</span>'
                  + '</div>';

            if (isOpen) {
                // 区块内横切按钮
                html += '<div class="home-block-tabs">';
                for (var t = 0; t < b.tabs.length; t++) {
                    var tb = b.tabs[t];
                    html += '<span class="hbt' + (tb.tab === activeTab ? ' active' : '') + '" onclick="homeSwitchTab(event,\'' + b.id + '\',\'' + tb.tab + '\')">' + tb.label + '</span>';
                }
                html += '</div>';

                // 区块内容（懒渲染：点开才生成，避免首屏 33 个 render 一起跑）
                html += '<div class="home-block-body" id="hbb-' + b.id + '" data-tab="' + activeTab + '">';
                if (st.active[b.id] === activeTab && st._loaded && st._loaded[b.id + ':' + activeTab]) {
                    html += st._loaded[b.id + ':' + activeTab];
                } else {
                    html += '<div class="home-block-lazy">展卷中…</div>';
                }
                html += '</div>';
            }

            html += '</div>';
        }

        html += '</div>';
        return html;
    } catch (e) {
        return '<div class="home-block-err">首页渲染异常</div>';
    }
}

// 折叠/展开
function homeToggle(blockId) {
    try {
        homeInitState();
        GameState.homeState.open[blockId] = !GameState.homeState.open[blockId];
        homeRefresh();
        if (typeof saveGame === 'function') { try { saveGame(); } catch (e) {} }
    } catch (e) {}
}

// 区块内切换
function homeSwitchTab(ev, blockId, tab) {
    try {
        if (ev && ev.stopPropagation) ev.stopPropagation();
        homeInitState();
        GameState.homeState.active[blockId] = tab;
        homeRefresh();
    } catch (e) {}
}

// 刷新首页（保留滚动位置）
function homeRefresh() {
    try {
        var panel = document.getElementById('home-panel') || document.getElementById('center-panel');
        if (!panel) return;
        var mount = document.getElementById('home-mount');
        if (!mount) {
            mount = document.createElement('div');
            mount.id = 'home-mount';
            panel.innerHTML = '';
            panel.appendChild(mount);
        }
        var sc = window.pageYOffset || document.documentElement.scrollTop || 0;
        mount.innerHTML = renderHome();
        homeFillHero();
        homeFillBlocks();
        try { window.scrollTo(0, sc); } catch (e) {}
        try { document.body.dataset.tab = 'home'; } catch (e) {}
    } catch (e) {}
}

// 填总览卡
function homeFillHero() {
    try {
        var el = document.getElementById('home-hero');
        if (!el) return;
        var ov = (typeof renderOverview === 'function') ? renderOverview() : '';
        el.innerHTML = ov;
    } catch (e) {}
}

// 填充所有展开区块的懒内容
function homeFillBlocks() {
    try {
        homeInitState();
        if (!GameState.homeState._loaded) GameState.homeState._loaded = {};
        for (var i = 0; i < HOME_BLOCKS.length; i++) {
            var b = HOME_BLOCKS[i];
            if (!GameState.homeState.open[b.id]) continue;
            var activeTab = GameState.homeState.active[b.id];
            var key = b.id + ':' + activeTab;
            var box = document.getElementById('hbb-' + b.id);
            if (!box) continue;
            if (GameState.homeState._loaded[key]) {
                box.innerHTML = GameState.homeState._loaded[key];
            } else {
                var h = homeSafeRenderPanel(activeTab, null);
                GameState.homeState._loaded[key] = h;
                box.innerHTML = h;
            }
        }
    } catch (e) {}
}

// 供外部调用：确保首页已填充（tick 后调用）
function homeEnsureFilled() {
    try {
        var wrap = document.getElementById('home-wrap');
        if (!wrap) return;
        homeFillHero();
        homeFillBlocks();
    } catch (e) {}
}

console.log('✓ v7.0 界面收敛 · 首页聚合加载完成（6大区块 33功能）');
