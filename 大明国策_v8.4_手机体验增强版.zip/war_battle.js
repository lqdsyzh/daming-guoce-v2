// ============================================
// 《大明国策》v8.3 战争连接层
// 战略层（舆图敌国据点 / 叛军） ↔ 战术层（battlefield.js 回合制战场）
// 史据：《明史》卷95·兵志九边 / 卷238·李成梁传 / 卷271·满桂传 /
//       卷309·李自成传 / 卷328·列传（流贼） / 卷332·列传（李岩）
// 铁律：出兵必费饷粮，战胜必有代价，败绩必损士卒
// ============================================

(function () {
    'use strict';
    if (window._v83WarBridge) return;
    window._v83WarBridge = true;

    // ====== 敌国势力 → 战场兵种 ======
    var POW_KIND = {
        mongol: 'mongol', tatar: 'oirat', jurchen: 'jurchen',
        wokou: 'wokou', annam: 'annam', tusi: 'tusi', tibet: 'tibetan',
        haixi: 'jurchen', yeren: 'jurchen', turpan: 'annam',
        hami: 'oirat', sixi: 'annam', qinghai: 'mongol'
    };
    // 敌国 → 战场难度系数（依其控弦之众）
    var POW_DIFF = {
        mongol: 1.28, tatar: 1.10, jurchen: 1.12,
        wokou: 1.0, annam: 0.95, tusi: 0.9, tibet: 0.9,
        haixi: 1.05, yeren: 0.85, turpan: 1.0,
        hami: 0.9, sixi: 0.85, qinghai: 0.9
    };

    // ====== 兵员抽取：从最近驻军点抽兵 ======
    function nearestGarrison(lon, lat, excludeId) {
        try {
            if (typeof OVL === 'undefined') return null;
            var best = null, bd = 1e9;
            OVL.nodes.forEach(function (n) {
                if (excludeId && n.id === excludeId) return;
                var d = Math.abs(n.lon - lon) + Math.abs(n.lat - lat);
                if (d < bd) { bd = d; best = n; }
            });
            return best;
        } catch (e) { return null; }
    }

    // ====== 粮饷估算 ======
    function warCost(troops, months) {
        // 太仓银：每万兵每月 120 两；军粮：每万兵每月 300 石
        var silver = Math.round(troops / 10000 * 120 * Math.max(1, months));
        var food = Math.round(troops / 10000 * 300 * Math.max(1, months));
        return { silver: silver, food: food };
    }

    // ====== 敌国据点开战 ======
    // 返回 {ok, msg} ；成功则已进入回合制战场
    function openZoneBattle(zoneId, troops, gen) {
        try {
            if (typeof WAR === 'undefined' || typeof bfStart === 'undefined') return { ok: false, msg: '战具未备' };
            var w = WAR.state();
            var z = null;
            w.zones.forEach(function (x) { if (x.id === zoneId) z = x; });
            if (!z) return { ok: false, msg: '无此据点' };
            if (z.occupied) return { ok: false, msg: z.nm + '已为我朝所取' };

            var from = nearestGarrison(z.lon, z.lat);
            if (!from) return { ok: false, msg: '附近无可用之师' };
            var dist = Math.abs(from.lon - z.lon) + Math.abs(from.lat - z.lat);
            if (dist > 16) return { ok: false, msg: from.nm + '距' + z.nm + '过远，须先移师' };
            if (from.troops < troops) return { ok: false, msg: from.nm + '兵不足 ' + troops + '（现有 ' + num(from.troops, 0) + '）' };

            var months = Math.max(1, Math.round(dist * 0.8));   // 距离越远，转输越久
            var cost = warCost(troops, months);
            var st = GameState.stats;
            if (num(st.treasury, 0) < cost.silver) return { ok: false, msg: '太仓银不足，需 ' + cost.silver + ' 两' };
            if (num(st.militaryFood, 0) < cost.food) return { ok: false, msg: '军粮不足，需 ' + cost.food + ' 石' };

            // 出征：抽兵 + 支饷
            from.troops -= troops;
            st.treasury -= cost.silver;
            st.militaryFood = Math.max(0, num(st.militaryFood, 0) - cost.food);

            var kind = POW_KIND[z.pow] || 'beilu';
            // v8.3：名将对敌加成（戚继光对倭、袁崇焕对后金、孙传庭对流寇…）
            var gBonus = 1;
            if (gen && typeof GENERALS !== 'undefined') {
                var zProv2 = (typeof WAR !== 'undefined' && WAR.zoneProvOf) ? WAR.zoneProvOf(z) : 'beizhili';
                var tKey2 = (typeof WAR !== 'undefined') ? WAR.terrainKey(zProv2) : 'plain';
                gBonus = GENERALS.bonusFor(gen, z.pow, tKey2);
                gen = Object.assign({}, gen, { battleBonus: gBonus });
            }
            // v8.3：守方有营造则敌军更难（难度略降）
            var zProv = (typeof WAR !== 'undefined' && WAR.zoneProvOf) ? WAR.zoneProvOf(z) : null;
            var bMod = (typeof BUILD !== 'undefined' && zProv) ? BUILD.provMods(zProv) : { defMul: 0 };
            var diffAdj = (POW_DIFF[z.pow] || 1.0) * (1 - Math.min(0.3, bMod.defMul * 0.5));
            var r = bfStart({
                mode: 'foe',
                regionKey: z.id,
                regionName: z.nm,
                targetId: z.id,
                kind: kind,
                difficulty: diffAdj,
                enemyMorale: num(z.morale, 60),
                troops: Math.max(5, Math.round(troops / 8)),   // 战场用"队"为单位
                gen: gen || null,
                silver: cost.silver,
                food: cost.food
            });
            if (!r || !r.ok) {
                // 战场开不起来 → 退还
                from.troops += troops;
                st.treasury += cost.silver;
                st.militaryFood += cost.food;
                return { ok: false, msg: (r && r.msg) || '战事不成' };
            }
            // 记录出征上下文（供战后结算）
            WAR._pending = { mode: 'foe', zoneId: z.id, fromId: from.id, troops: troops, cost: cost };
            try { bfOpen(); } catch (e) {}
            return { ok: true };
        } catch (e) { return { ok: false, msg: '战事不成' }; }
    }

    // ====== 平叛开战 ======
    function openRebelBattle(rebelId, troops, gen) {
        try {
            if (typeof WAR === 'undefined' || typeof bfStart === 'undefined') return { ok: false, msg: '战具未备' };
            var w = WAR.state();
            var r = null;
            w.rebels.forEach(function (x) { if (x.id === rebelId) r = x; });
            if (!r) return { ok: false, msg: '此辈已平' };

            var prov = null;
            if (typeof ATLAS_LIST !== 'undefined') {
                ATLAS_LIST.forEach(function (x) { if (x.id === r.prov) prov = x; });
            }
            var lon = prov ? prov.lon : 116, lat = prov ? prov.lat : 39;
            var from = nearestGarrison(lon, lat);
            if (!from) return { ok: false, msg: '附近无可用之师' };
            if (from.troops < troops) return { ok: false, msg: from.nm + '兵不足 ' + troops };

            var dist = Math.abs(from.lon - lon) + Math.abs(from.lat - lat);
            var months = Math.max(1, Math.round(dist * 0.6) + 1);
            var cost = warCost(troops, months);
            var st = GameState.stats;
            if (num(st.treasury, 0) < cost.silver) return { ok: false, msg: '太仓银不足，需 ' + cost.silver + ' 两' };
            if (num(st.militaryFood, 0) < cost.food) return { ok: false, msg: '军粮不足，需 ' + cost.food + ' 石' };

            from.troops -= troops;
            st.treasury -= cost.silver;
            st.militaryFood = Math.max(0, num(st.militaryFood, 0) - cost.food);

            var gBonus2 = 1;
            if (gen && typeof GENERALS !== 'undefined') {
                var tKey3 = (typeof WAR !== 'undefined') ? WAR.terrainKey(r.prov) : 'plain';
                gBonus2 = GENERALS.bonusFor(gen, 'panjun', tKey3);
                gen = Object.assign({}, gen, { battleBonus: gBonus2 });
            }
            var res = bfStart({
                mode: 'rebel',
                regionKey: r.prov,
                regionName: r.provNm,
                targetId: r.id,
                kind: 'panjun',
                difficulty: 0.95,
                enemyMorale: num(r.morale, 60),
                troops: Math.max(5, Math.round(troops / 8)),
                gen: gen || null,
                silver: cost.silver,
                food: cost.food
            });
            if (!res || !res.ok) {
                from.troops += troops;
                st.treasury += cost.silver;
                st.militaryFood += cost.food;
                return { ok: false, msg: (res && res.msg) || '战事不成' };
            }
            WAR._pending = { mode: 'rebel', rebelId: r.id, fromId: from.id, troops: troops, cost: cost };
            try { bfOpen(); } catch (e) {}
            return { ok: true };
        } catch (e) { return { ok: false, msg: '平叛不成' }; }
    }

    // ====== 战后回调：战略层结算 ======
    function onBattleResult(info) {
        try {
            var w = WAR.state();
            var st = GameState.stats;
            var pending = WAR._pending || {};
            var from = null;
            if (pending.fromId && typeof OVL !== 'undefined') {
                OVL.nodes.forEach(function (n) { if (n.id === pending.fromId) from = n; });
            }
            var lost = Math.round(pending.troops * (info.win ? 0.22 : 0.55));
            // 凯旋者归队
            var back = Math.max(0, pending.troops - lost);
            if (from) from.troops += back;

            if (info.mode === 'foe') {
                var z = null;
                w.zones.forEach(function (x) { if (x.id === info.target) z = x; });
                if (z) {
                    if (info.result === '大捷' || info.result === '惨胜') {
                        z.occupied = true;
                        z.garrison = Math.max(500, Math.round(back * 0.4));
                        z.troops = 0;
                        z.supply = Math.max(30, num(z.supply, 50));
                        z.cooldown = 0;
                        z.morale = Math.max(10, num(z.morale, 50) - 30);
                        WAR.syncNation(z.pow, -22, -12);
                        st.treasury += 600;
                        if (typeof pushNews === 'function') {
                            pushNews('战报', '官军克' + z.nm + '，置羁縻州县，纳其地，获牛马若干。', 'normal');
                        }
                    } else if (info.result === '败退' || info.result === '帅殁') {
                        z.cooldown = 2;
                        z.morale = Math.max(20, num(z.morale, 50) + 8);
                        WAR.syncNation(z.pow, 8, 5);
                        if (typeof pushNews === 'function') {
                            pushNews('战报', '攻' + z.nm + '不克，我师大败，弃甲辎重塞途。', 'critical');
                        }
                    } else {
                        z.morale = Math.max(10, num(z.morale, 50) - 8);
                        if (typeof pushNews === 'function') {
                            pushNews('战报', '战于' + z.nm + '，相持未决，虏势稍挫。', 'normal');
                        }
                    }
                }
            } else if (info.mode === 'rebel') {
                var rb = null;
                w.rebels.forEach(function (x) { if (x.id === info.target) rb = x; });
                if (rb) {
                    if (info.result === '大捷' || info.result === '惨胜') {
                        rb.troops = Math.round(num(rb.troops, 0) * 0.35);
                        rb.morale = Math.max(10, num(rb.morale, 60) - 20);
                        if (rb.troops < 600 || info.result === '大捷') {
                            w.rebels = w.rebels.filter(function (x) { return x.id !== rb.id; });
                            var pv = (GameState.province && GameState.province.prov) ? GameState.province.prov[rb.prov] : null;
                            if (pv) pv.disaffect = Math.max(0, num(pv.disaffect, 20) - 22);
                            if (typeof pushNews === 'function') {
                                pushNews('战报', '平' + rb.provNm + '之乱，' + rb.leader + '授首或遁去，乱势稍定。', 'normal');
                            }
                        } else {
                            if (typeof pushNews === 'function') {
                                pushNews('战报', '破' + rb.leader + '众于' + rb.provNm + '，余众奔散。', 'normal');
                            }
                        }
                    } else {
                        rb.morale = Math.min(95, num(rb.morale, 60) + 8);
                        rb.troops = Math.round(num(rb.troops, 0) * 1.05);
                        if (typeof pushNews === 'function') {
                            pushNews('战报', '平叛不利，' + rb.leader + '势益张。', 'critical');
                        }
                    }
                }
            }
            WAR._pending = null;
            if (typeof atlRenderNow === 'function') atlRenderNow();
        } catch (e) {}
    }

    // ====== 供 UI 调用 ======
    window.WARB = {
        openZoneBattle: openZoneBattle,
        openRebelBattle: openRebelBattle,
        nearestGarrison: nearestGarrison,
        warCost: warCost,
        POW_KIND: POW_KIND,
        POW_DIFF: POW_DIFF,
        onBattleResult: onBattleResult
    };
    // 挂到 WAR 上（battlefield.js 回调用）
    try { if (typeof WAR !== 'undefined') { WAR.onBattleResult = onBattleResult; WAR.WARB = window.WARB; } } catch (e) {}

    console.log('✓ v8.3 战略↔战术连接层已装载');
})();
