// ============================================
// 《大明国策》v7.0 界面收敛 · 桥接层
// 拦截 renderPanel / 菜单点击 / 各类下钻跳转
// 一律不跳页：转成"首页内定位 + 展开对应区块 + 切到对应字卷"
// 铁律：不碰 edict 永久 DOM
// ============================================

(function () {
    'use strict';
    if (window._v7BridgeInstalled) return;
    window._v7BridgeInstalled = true;

    // ---- tab → 区块映射（由 home.js 的 HOME_BLOCKS 反查，此处兜底） ----
    var FALLBACK = {
        economy: ['econ', 0], finance: ['econ', 1], markets: ['econ', 2],
        transport: ['econ', 3], construction: ['econ', 4],
        military: ['war', 0], map: ['war', 1], govern: ['war', 2], court: ['war', 3],
        personnel: ['court', 0], impeach: ['court', 1], censor: ['court', 2],
        secret: ['court', 3], intrigue: ['court', 4],
        harem: ['inner', 0], prince: ['inner', 1], emperor: ['inner', 2],
        famine: ['people', 0], keju: ['people', 1], tech: ['people', 2],
        yingzao: ['people', 3], yearend: ['people', 4], decade: ['people', 5],
        zongfan: ['realm', 0], tribute: ['realm', 1], diplomacy: ['realm', 2],
        mission: ['realm', 3], prison: ['realm', 4], share: ['realm', 5], compare: ['realm', 6],
        politics: ['war', 2], overview: [null, -1], selection: ['court', 0]
    };

    function locateTab(tab) {
        try {
            if (typeof HOME_BLOCKS === 'undefined' || !HOME_BLOCKS) return FALLBACK[tab] || null;
            for (var i = 0; i < HOME_BLOCKS.length; i++) {
                var b = HOME_BLOCKS[i];
                for (var t = 0; t < b.tabs.length; t++) {
                    if (b.tabs[t].tab === tab) return [b.id, t];
                }
            }
        } catch (e) {}
        return FALLBACK[tab] || null;
    }

    // 把某 tab 拉到首页对应区块并展开
    function homeGotoTab(tab) {
        try {
            if (tab === 'overview' || tab === 'home') { scrollHomeTop(); return; }
            var loc = locateTab(tab);
            if (!loc) return;
            if (typeof GameState !== 'undefined' && GameState) {
                if (!GameState.homeState) GameState.homeState = { open: {}, active: {} };
                if (!GameState.homeState.open) GameState.homeState.open = {};
                if (!GameState.homeState.active) GameState.homeState.active = {};
                if (loc[0]) {
                    GameState.homeState.open[loc[0]] = true;
                    var blk = null;
                    for (var i = 0; i < HOME_BLOCKS.length; i++) if (HOME_BLOCKS[i].id === loc[0]) blk = HOME_BLOCKS[i];
                    if (blk && blk.tabs[loc[1]]) GameState.homeState.active[loc[0]] = blk.tabs[loc[1]].tab;
                }
            }
            if (typeof homeRefresh === 'function') homeRefresh();
            // 同步左侧导航高亮
            syncBlockNav(loc[0]);
            // 滚动到该区块（页面本身是滚动容器）
            setTimeout(function () {
                var el = document.getElementById('hb-' + loc[0]);
                if (!el) return;
                var y = el.getBoundingClientRect().top + (window.pageYOffset || document.documentElement.scrollTop) - 70;
                try { window.scrollTo({ top: y, behavior: 'smooth' }); } catch (e) { window.scrollTo(0, y); }
            }, 80);
        } catch (e) {}
    }

    function syncBlockNav(blockId) {
        try {
            var tabs = document.querySelectorAll('#menu-tabs .menu-tab');
            for (var i = 0; i < tabs.length; i++) {
                tabs[i].classList.toggle('active', tabs[i].getAttribute('data-block') === blockId);
            }
        } catch (e) {}
    }

    function scrollHomeTop() {
        try {
            var p = document.getElementById('center-panel');
            if (p) p.scrollTop = 0;
            syncBlockNav(null);
        } catch (e) {}
    }

    // 左侧导航：定位到区块（展开并滚过去）
    window.homeGotoBlock = function (blockId) {
        try {
            if (typeof GameState !== 'undefined' && GameState) {
                if (!GameState.homeState) GameState.homeState = { open: {}, active: {} };
                if (!GameState.homeState.open) GameState.homeState.open = {};
                GameState.homeState.open[blockId] = true;
            }
            if (typeof homeRefresh === 'function') homeRefresh();
            syncBlockNav(blockId);
            // 页面本身是滚动容器（home-panel 无固定高），用 window 滚
            setTimeout(function () {
                var el = document.getElementById('hb-' + blockId);
                if (!el) return;
                var y = el.getBoundingClientRect().top + (window.pageYOffset || document.documentElement.scrollTop) - 70;
                try { window.scrollTo({ top: y, behavior: 'smooth' }); } catch (e) { window.scrollTo(0, y); }
            }, 80);
        } catch (e) {}
    };

    // ---- 拦截 renderPanel：不再切页，转为首页下钻 ----
    var _origRenderPanel = window.renderPanel;
    window.renderPanel = function (tab) {
        try {
            // 首页已挂载：任何 tab 请求都转成"首页内定位"，绝不覆写 center-panel
            if (window._v7HomeMounted && !window._v7AllowRawRender) {
                if (tab && tab !== 'home') homeGotoTab(tab);
                else scrollHomeTop();
                return undefined;            }
            // 尚未挂载：先原样渲染一次（保证初始化不崩），随后立刻收进首页
            var r = _origRenderPanel ? _origRenderPanel.apply(this, arguments) : undefined;
            if (!window._v7HomeMounted) {
                mountHome();
                if (tab && tab !== 'home') homeGotoTab(tab);
            }
            return r;
        } catch (e) {
            return _origRenderPanel ? _origRenderPanel.apply(this, arguments) : undefined;
        }
    };

    // ---- 拦截 overviewGoto（下钻也回首页） ----
    var _origOverviewGoto = window.overviewGoto;
    window.overviewGoto = function (tab) {
        try {
            if (typeof homeGotoTab === 'function') { homeGotoTab(tab); return; }
        } catch (e) {}
        if (_origOverviewGoto) { try { return _origOverviewGoto.apply(this, arguments); } catch (e) {} }
    };

    // ---- 拦截菜单点击 ----
    function hookMenuClicks() {
        try {
            var menu = document.getElementById('menu-tabs');
            if (!menu) return;
            menu.addEventListener('click', function (ev) {
                var el = ev.target;
                while (el && el !== menu && !el.classList.contains('menu-tab')) el = el.parentNode;
                if (!el || el === menu || !el.classList.contains('menu-tab')) return;
                var blk = el.getAttribute('data-block');
                var tab = el.getAttribute('data-tab');
                if (blk) { ev.preventDefault(); homeGotoBlock(blk); }
                else if (tab) { ev.preventDefault(); homeGotoTab(tab); }
            }, true);
        } catch (e) {}
    }

    // ---- 守护：旧逻辑若把 home-panel 内容冲掉，自动补回 ----
    function watchPanel() {
        try {
            var panel = document.getElementById('home-panel');
            if (!panel || panel.__v7Watched) return;
            panel.__v7Watched = true;
            var mo = new MutationObserver(function () {
                if (!window._v7HomeMounted) return;
                if (document.getElementById('home-mount')) return;
                mountHome();
            });
            mo.observe(panel, { childList: true });
        } catch (e) {}
    }

    // ---- 挂载首页 ----
    function ensureMountPoint() {
        try {
            var panel = document.getElementById('home-panel');
            if (!panel) return null;
            var mount = document.getElementById('home-mount');
            if (!mount) {
                mount = document.createElement('div');
                mount.id = 'home-mount';
                panel.innerHTML = '';
                panel.appendChild(mount);
            }
            return mount;
        } catch (e) { return null; }
    }

    function mountHome() {
        try {
            var mount = ensureMountPoint();
            if (!mount) return;
            if (typeof renderHome !== 'function') return;
            mount.innerHTML = renderHome();
            if (typeof homeFillHero === 'function') homeFillHero();
            if (typeof homeFillBlocks === 'function') homeFillBlocks();
            try { document.body.dataset.tab = 'home'; } catch (e) {}
            window._v7HomeMounted = true;
            watchPanel();
        } catch (e) {}
    }
    window.mountHome = mountHome;
    window.homeEnsureMounted = function () { if (!window._v7HomeMounted) mountHome(); else { try { homeRefresh(); } catch (e) {} } };

    // ---- 补丁：把 updateUI / tick 后的重绘也导向首页 ----
    var _origUpdateUI = window.updateUI;
    window.updateUI = function () {
        var r;
        try { if (_origUpdateUI) r = _origUpdateUI.apply(this, arguments); } catch (e) {}
        try {
            if (window._v7HomeMounted && typeof homeRefresh === 'function') {
                homeRefresh();
            } else {
                mountHome();
            }
        } catch (e) {}
        return r;
    };

    // ---- 启动 ----
    function boot() {
        try {
            hookMenuClicks();
            mountHome();
        } catch (e) {}
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        setTimeout(boot, 0);
    }

    // 剧本选定后也要挂
    var _iv = setInterval(function () {
        try {
            if (typeof GameState !== 'undefined' && GameState && GameState.script && !window._v7HomeMounted) {
                mountHome();
                clearInterval(_iv);
            }
            if (window._v7HomeMounted) clearInterval(_iv);
        } catch (e) { clearInterval(_iv); }
    }, 300);
    setTimeout(function () { try { clearInterval(_iv); } catch (e) {} }, 20000);

    console.log('✓ v7.0 收敛桥接层已装载（不跳页 · 首页聚合）');
})();
