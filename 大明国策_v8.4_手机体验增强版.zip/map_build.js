// ============================================
// 《大明国策》v8.3 舆图建设
// 烽燧 · 关隘 · 卫所 · 市镇 · 屯田 · 教场
// 史据：《明史》卷95·兵志（筑城置卫设驿） / 卷188·阚乡传（湖广诸边） /
//       《明史》卷132·刘基传（城守） / 《大明会典》·兵部·城堡
// 铁律：建有费、占田、需时；建后地形防御系数真的变
// ============================================

(function () {
    'use strict';
    if (window._v83Build) return;
    window._v83Build = true;

    // ====== 建设类型 ======
    // defMul 地形防御加成 / atkMul 出击加成 / up 维护每季 / income 每季产出（银/粮）
    var BUILD_TYPES = {
        beacon: {
            nm: '烽燧', banner: '烽', icon: '烽',
            cost: 800, buildTurns: 1, up: 40, defMul: 0.18, atkMul: 0.04,
            grain: 0, silver: 0, landCost: 0,
            desc: '昼则烟，夜则火。十里一墩，五里一台，有警则举烽。',
            src: '《明史》卷95·兵志：沿边筑墩台，昼则烟、夜则火，有警举之。',
            effect: '警报速达，敌军来袭可提前一季得知'
        },
        pass: {
            nm: '关隘', banner: '关', icon: '关',
            cost: 2400, buildTurns: 2, up: 90, defMul: 0.32, atkMul: 0.02,
            grain: 0, silver: 0, landCost: 0,
            desc: '凿山为堑，因险设关，一夫当关，万夫莫开。',
            src: '《明史》卷95·兵志：太行、雁门诸关，皆倚山为险，置兵设守。',
            effect: '此省守方战力大幅提升'
        },
        garrison: {
            nm: '卫所', banner: '卫', icon: '卫',
            cost: 1600, buildTurns: 2, up: 70, defMul: 0.15, atkMul: 0.10,
            grain: 0, silver: 0, landCost: 0, troops: 3000,
            desc: '卫指挥使司，置兵五千余，籍民为军，父子相世。',
            src: '《明史》卷95·兵志：卫所之制，卫辖千户所，兵皆世籍。',
            effect: '常驻守军三千，我方战力与守势并增'
        },
        market: {
            nm: '市镇', banner: '市', icon: '市',
            cost: 1200, buildTurns: 1, up: 50, defMul: 0.05, atkMul: 0.02,
            grain: 120, silver: 260, landCost: 0,
            desc: '设场招商，列肆通商，通有无而征其税。',
            src: '《明史》卷75·食货志：天下场镇，置场官，验货抽税。',
            effect: '每季入银与粮，商路更畅'
        },
        tuntian: {
            nm: '屯田', banner: '屯', icon: '屯',
            cost: 900, buildTurns: 1, up: 30, defMul: 0.04, atkMul: 0.02,
            grain: 520, silver: 60, landCost: 1,
            desc: '募民实边，且耕且守，输粟于官，省转输之费。',
            src: '《明史》卷95·兵志：边地皆设屯田，岁入粟以饷军。',
            effect: '每季入粮，兵食自足'
        },
        drill: {
            nm: '教场', banner: '场', icon: '场',
            cost: 1100, buildTurns: 1, up: 45, defMul: 0.02, atkMul: 0.16,
            grain: 0, silver: 0, landCost: 0,
            desc: '建营立栅，习阵练兵，暇日较射挽弓。',
            src: '《明史》卷95·兵志：各镇皆有教场，令官军按月较艺。',
            effect: '此省出击战力提升'
        }
    };

    // ====== 状态 ======
    function initBuild() {
        return { sites: [], pending: [] };
    }
    function bs() {
        try {
            if (typeof GameState === 'undefined') return initBuild();
            if (!GameState.mapBuild) GameState.mapBuild = initBuild();
            var b = GameState.mapBuild;
            if (!Array.isArray(b.sites)) b.sites = [];
            if (!Array.isArray(b.pending)) b.pending = [];
            return b;
        } catch (e) { return initBuild(); }
    }

    // ====== 查询：某省的各项加成 ======
    function provMods(provId) {
        var out = { defMul: 0, atkMul: 0, grain: 0, silver: 0, troops: 0, list: [] };
        try {
            var b = bs();
            b.sites.forEach(function (s) {
                if (s.prov !== provId) return;
                var t = BUILD_TYPES[s.type];
                if (!t) return;
                out.defMul += t.defMul;
                out.atkMul += t.atkMul;
                out.grain += t.grain;
                out.silver += t.silver;
                out.troops += t.troops || 0;
                out.list.push(s);
            });
        } catch (e) {}
        return out;
    }

    // ====== 防御系数（地形 + 建设） ======
    function defFactor(provId) {
        try {
            var ter = (typeof WAR !== 'undefined') ? WAR.terrainOf(provId) : { def: 1 };
            return ter.def * (1 + provMods(provId).defMul);
        } catch (e) { return 1; }
    }

    // ====== 开工 ======
    function start(provId, typeKey) {
        try {
            var t = BUILD_TYPES[typeKey];
            if (!t) return { ok: false, msg: '无此营造' };
            var st = GameState.stats;
            var b = bs();
            // 同省同type只能有一处
            if (b.sites.some(function (s) { return s.prov === provId && s.type === typeKey; })) {
                return { ok: false, msg: '此地已有' + t.nm + '，无须重造' };
            }
            if (b.pending.some(function (s) { return s.prov === provId && s.type === typeKey; })) {
                return { ok: false, msg: t.nm + '正在兴造之中' };
            }
            if (num(st.treasury, 0) < t.cost) return { ok: false, msg: '国库不足，需 ' + t.cost + ' 两' };
            if (t.landCost) {
                var pv = (GameState.province && GameState.province.prov) ? GameState.province.prov[provId] : null;
                if (pv && num(pv.wealth, 45) < 55) return { ok: false, msg: '此省民力不足，屯田须宽其地' };
            }
            st.treasury -= t.cost;
            b.pending.push({
                id: 'bs' + Date.now() + Math.floor(Math.random() * 999),
                prov: provId, type: typeKey,
                turnsLeft: t.buildTurns
            });
            if (typeof pushNews === 'function') {
                pushNews('营造', '命有司于' + provNm(provId) + '兴' + t.nm + '，费帑 ' + t.cost + '两，限 ' + t.buildTurns + '季竣工。', 'normal');
            }
            return { ok: true };
        } catch (e) { return { ok: false, msg: '营造不成' }; }
    }

    function provNm(id) {
        try {
            var p = null;
            if (typeof ATLAS_LIST !== 'undefined') ATLAS_LIST.forEach(function (x) { if (x.id === id) p = x; });
            return p ? p.nm : id;
        } catch (e) { return id; }
    }

    // ====== 每季推进：竣工 + 维护 + 产出 ======
    function seasonTick() {
        try {
            var b = bs();
            var st = GameState.stats;
            var built = [], income = 0, grain = 0, upCost = 0;

            // 竣工
            for (var i = b.pending.length - 1; i >= 0; i--) {
                var p = b.pending[i];
                p.turnsLeft--;
                if (p.turnsLeft <= 0) {
                    b.pending.splice(i, 1);
                    var t = BUILD_TYPES[p.type];
                    if (!t) continue;
                    b.sites.push({ prov: p.prov, type: p.type, since: GameState.currentYear || 0 });
                    built.push({ prov: p.prov, type: p.type, nm: t.nm });
                    // 卫所落成即增兵
                    if (t.troops && typeof OVL !== 'undefined') {
                        var near = null, bd = 1e9;
                        var prov = null;
                        if (typeof ATLAS_LIST !== 'undefined') ATLAS_LIST.forEach(function (x) { if (x.id === p.prov) prov = x; });
                        OVL.nodes.forEach(function (n) {
                            var d = prov ? (Math.abs(n.lon - prov.lon) + Math.abs(n.lat - prov.lat)) : 1;
                            if (d < bd) { bd = d; near = n; }
                        });
                        if (near) near.troops += t.troops;
                    }
                    if (typeof pushNews === 'function') {
                        pushNews('营造', provNm(p.prov) + t.nm + '竣工。' + t.effect + '。', 'normal');
                    }
                }
            }

            // 维护与产出
            b.sites.forEach(function (s) {
                var t = BUILD_TYPES[s.type];
                if (!t) return;
                upCost += t.up;
                income += t.silver;
                grain += t.grain;
            });
            if (upCost > 0) {
                st.treasury = Math.max(0, num(st.treasury, 0) - upCost);
                st.food = num(st.food, 0) + grain;
                if (income > 0) st.treasury += income;
                if (typeof pushNews === 'function') {
                    pushNews('营造', '诸处营造岁修：费 ' + upCost + ' 两，入银 ' + income + ' 两、入粮 ' + grain + ' 石。');
                }
            }
            return { built: built, up: upCost, silver: income, grain: grain };
        } catch (e) { return null; }
    }

    window.BUILD = {
        TYPES: BUILD_TYPES,
        state: bs,
        init: initBuild,
        provMods: provMods,
        defFactor: defFactor,
        start: start,
        seasonTick: seasonTick,
        provNm: provNm
    };

    console.log('✓ v8.3 舆图建设系统已装载（6 类营造 · 改地形防御系数）');
})();
