// 大明国策 v8.4 Service Worker：完整静态资源缓存与安全回退
const CACHE = 'daming-guoce-v84';
const APP_CACHE_PREFIX = 'daming-guoce-';
const ASSETS = [
  "./atlas.js",
  "./audit.js",
  "./auto.js",
  "./batch5_bridge.js",
  "./battlefield.js",
  "./cangwei.js",
  "./court_session.js",
  "./daming_talk.js",
  "./data/achievements.js",
  "./data/achievements_ext.js",
  "./data/advice.js",
  "./data/advice_ext.js",
  "./data/china_geo.js",
  "./data/china_geo.json",
  "./data/compare.js",
  "./data/events_ext.js",
  "./data/extras2.js",
  "./data/extras_ui.js",
  "./data/historian.js",
  "./data/memorials.js",
  "./data/memorials_ext.js",
  "./data/memorials_v31.js",
  "./data/script.js",
  "./data/share.js",
  "./data/systems.js",
  "./data/systems2.js",
  "./data/v31_extra.js",
  "./diplomacy_interact.js",
  "./economy_market.js",
  "./expedition.js",
  "./generals.js",
  "./govern.js",
  "./harem_interact.js",
  "./harem_prince.js",
  "./home.js",
  "./home_bridge.js",
  "./icon-192.png",
  "./icon-512.png",
  "./index.html",
  "./index_standalone.html",
  "./intrigue.js",
  "./junpi.js",
  "./keju.js",
  "./keju_deep.js",
  "./lizhi.js",
  "./mainline.js",
  "./manifest.json",
  "./map.js",
  "./map_build.js",
  "./map_overlay.js",
  "./map_province.js",
  "./military_ops_ext.js",
  "./military_tech_ext.js",
  "./military_war_def.js",
  "./missions.js",
  "./mobileui.js",
  "./modules.js",
  "./num_guard.js",
  "./overview.js",
  "./quick.js",
  "./save_migrate.js",
  "./script.js",
  "./sfx.js",
  "./style.css",
  "./v5d_ui.js",
  "./war_battle.js",
  "./war_battle_ui.js",
  "./war_rebel.js",
  "./war_sim.js",
  "./yearend.js",
  "./yingzao.js",
  "./zaiyi.js",
  "./zongfan.js"
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(
    keys.filter(key => key.startsWith(APP_CACHE_PREFIX) && key !== CACHE).map(key => caches.delete(key))
  )).then(() => self.clients.claim()));
});

self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return;
  event.respondWith((async () => {
    const cached = await caches.match(req);
    if (cached) return cached;
    try {
      const response = await fetch(req);
      if (response && response.ok) {
        const copy = response.clone();
        caches.open(CACHE).then(cache => cache.put(req, copy)).catch(() => {});
      }
      return response;
    } catch (error) {
      if (req.mode === 'navigate') return (await caches.match('./index.html')) || Response.error();
      return Response.error();
    }
  })());
});
