// ============================================
// 《大明国策》v8.0 舆图 · 真实边界版
// 数据源：国家地理信息公共服务平台 高精度省级边界（DataV.GeoAtlas）
// 明代两京十三布政司 ≈ 现代对应省份，故直接用真实省界投影
// 九边为长城沿线军事重镇（菱标），非行政区
// ============================================

(function () {
    'use strict';
    if (window._v80AtlasInstalled) return;
    window._v80AtlasInstalled = true;

    // ====== 明代布政使司 → 现代省（真实边界来源）======
    var MING = [
        { id:'beizhili', nm:'北直隶', src:['130000','110000','120000'], grp:'capital',
          lon:116.6, lat:39.2,
          alias:'京师所在', note:'漕运中枢，十二陵寝攸关。蝗旱之变首发于此。',
          city:'京师 顺天府', srcRef:'《明史》卷41·地理志' },

        { id:'nanzhili', nm:'南直隶', src:['320000','340000','310000'], grp:'rich',
          lon:118.4, lat:32.2,
          alias:'留都应天', note:'赋税半天下，漕运总督驻节。南京另有一朝之制。',
          city:'应天府', srcRef:'《明史》卷42·地理志' },

        { id:'huguang', nm:'湖广', src:['420000','430000'], grp:'rich',
          lon:112.4, lat:29.8,
          alias:'鱼米之乡', note:'武昌扼要，荆襄流民所出，填湖占田者众。',
          city:'武昌府', srcRef:'《明史》卷42·地理志' },

        { id:'liaodong', nm:'辽东', src:['210000','220000'], grp:'border',
          lon:122.0, lat:41.0,
          alias:'屏蔽京师左臂', note:'奴儿干都司故地。建州女真渐炽，辽沈战事所系。',
          city:'辽东经略司 · 辽阳', srcRef:'《明史》卷41·地理志' },

        { id:'shanxi',   nm:'山西', src:['140000'], grp:'plain', lon:112.4, lat:37.4,
          alias:'晋商盐路', note:'行都司卫所密布，盐铁之利甲天下。',
          city:'太原府', srcRef:'《明史》卷42·地理志' },
        { id:'shaanxi',  nm:'陕西', src:['610000'], grp:'plain', lon:108.8, lat:35.4,
          alias:'三秦沃土', note:'边镇林立，茶马盐利所萃。民风刚劲，最难治。',
          city:'西安府', srcRef:'《明史》卷42·地理志' },
        { id:'gansu',    nm:'甘肃', src:['620000'], grp:'border', lon:101.4, lat:38.4,
          alias:'河西走廊', note:'狭长千余里，饷运十万里。士卒最苦，仓储最虚。',
          city:'陕西总兵 甘肃镇 · 嘉峪关', srcRef:'《明史》卷42·地理志' },
        { id:'ningxia',  nm:'宁夏', src:['640000'], grp:'border', lon:106.2, lat:38.0,
          alias:'贺兰山下', note:'河套之南，控扼朔方。哱拜之乱自此而始。',
          city:'宁夏总兵 镇城', srcRef:'《明史》卷42·地理志' },
        { id:'shandong', nm:'山东', src:['370000'], grp:'plain', lon:118.4, lat:36.2,
          alias:'孔孟之乡', note:'漕渠所经，登莱海防亦系于此。',
          city:'济南府', srcRef:'《明史》卷42·地理志' },
        { id:'henan',    nm:'河南', src:['410000'], grp:'plain', lon:113.4, lat:33.8,
          alias:'中州沃土', note:'河患所系，汴梁故都，四战之地。',
          city:'开封府', srcRef:'《明史》卷42·地理志' },
        { id:'zhejiang', nm:'浙江', src:['330000'], grp:'rich', lon:120.0, lat:30.0,
          alias:'丝盐鱼米', note:'市舶之利甲于东南，倭警时闻，卫所亦虚。',
          city:'杭州府', srcRef:'《明史》卷42·地理志' },
        { id:'jiangxi',  nm:'江西', src:['360000'], grp:'plain', lon:115.6, lat:28.2,
          alias:'瓷都赋税', note:'宁藩所封，书院文盛，赋税最清。',
          city:'南昌府', srcRef:'《明史》卷42·地理志' },
        { id:'fujian',   nm:'福建', src:['350000'], grp:'coast', lon:118.0, lat:26.0,
          alias:'市舶通番', note:'海禁前沿，卫所空虚，倭寇由海上来。',
          city:'福州府', srcRef:'《明史》卷42·地理志' },
        { id:'guangdong',nm:'广东', src:['440000'], grp:'coast', lon:113.4, lat:23.2,
          alias:'番舶互市', note:'珠池银矿所出，琼崖遥制。海寇出没，卫所单薄。',
          city:'广州府', srcRef:'《明史》卷42·地理志' },
        { id:'guangxi',  nm:'广西', src:['450000'], grp:'remote', lon:109.4, lat:23.4,
          alias:'大藤峡旧地', note:'狼兵悍勇，土司杂处。瑶峒之乱屡起。',
          city:'桂林府', srcRef:'《明史》卷42·地理志' },
        { id:'yunnan',   nm:'云南', src:['530000'], grp:'remote', lon:101.4, lat:24.6,
          alias:'银矿土司', note:'麓川旧地，边徼万里。银出其地，而人不知。',
          city:'云南府', srcRef:'《明史》卷42·地理志' },
        { id:'guizhou',  nm:'贵州', src:['520000'], grp:'remote', lon:106.4, lat:26.6,
          alias:'苗疆', note:'驿道初通，水西播州杂处，奢安之乱起于此。',
          city:'贵阳府', srcRef:'《明史》卷42·地理志' },
        { id:'sichuan',  nm:'四川', src:['510000','500000'], grp:'plain', lon:103.6, lat:30.4,
          alias:'天府之国', note:'蜀道天险，井盐自足。流民入蜀者众。',
          city:'成都府', srcRef:'《明史》卷42·地理志' },
        { id:'hainan',   nm:'海南', src:['460000'], grp:'coast', lon:109.8, lat:19.4,
          alias:'琼州府', note:'琼崖遥制，士人罕至。海瑞即出此。',
          city:'琼州府', srcRef:'《明史》卷42·地理志' }
    ];

    // ====== 九边重镇（军事重镇，非行政区）======
    var GARRISON = [
        { id:'gansu_g',   nm:'甘肃镇', lon:98.3,  lat:39.7, src:'嘉峪关', force:'兵三万余' },
        { id:'ningxia_g', nm:'宁夏镇', lon:106.3, lat:38.4, src:'镇城',   force:'兵二万余' },
        { id:'yansui_g',  nm:'延绥镇', lon:109.7, lat:38.3, src:'榆林城', force:'兵三万余' },
        { id:'guyuan_g',  nm:'固原镇', lon:106.2, lat:36.0, src:'固原城', force:'兵二万余' },
        { id:'shanxi_g',  nm:'山西镇', lon:112.5, lat:37.8, src:'太原镇', force:'兵二万余' },
        { id:'datong_g',  nm:'大同镇', lon:113.3, lat:40.1, src:'大同城', force:'兵三万余' },
        { id:'xuanfu_g',  nm:'宣府镇', lon:115.0, lat:40.7, src:'宣府城', force:'兵二万余' },
        { id:'jizhou_g',  nm:'蓟州镇', lon:117.0, lat:40.1, src:'三屯营', force:'兵五万余' }
    ];

    var GC = {
        border:  { fill:'#6f5b44', stroke:'#3b2e20', name:'九边' },
        capital: { fill:'#8b6a2d', stroke:'#4a3615', name:'京畿' },
        plain:   { fill:'#5c7a4f', stroke:'#33482c', name:'中原' },
        rich:    { fill:'#44764e', stroke:'#20422a', name:'江南' },
        coast:   { fill:'#4e757c', stroke:'#26464d', name:'海疆' },
        remote:  { fill:'#7e6c4b', stroke:'#453923', name:'西南' }
    };

    // ====== 载入真实边界数据 ======
    var GEO = null, PROJ = null;
    function boot() {
        try {
            if (GEO) return true;
            if (typeof CHINA_GEO === 'undefined') return false;
            GEO = CHINA_GEO;
            computeProj();
            return true;
        } catch (e) { return false; }
    }

    // 计算投影范围（只取会用到的省，剔除西藏新疆内蒙等非明代疆域）
    var USE_AD = {};
    for (var i = 0; i < MING.length; i++) {
        for (var j = 0; j < MING[i].src.length; j++) USE_AD[MING[i].src[j]] = 1;
    }
    function computeProj() {
        var minX = 1e9, maxX = -1e9, minY = 1e9, maxY = -1e9;
        GEO.features.forEach(function (f) {
            if (!USE_AD[String(f.properties.adcode)]) return;
            walk(f.geometry.coordinates, function (p) {
                if (p[0] < minX) minX = p[0];
                if (p[0] > maxX) maxX = p[0];
                if (p[1] < minY) minY = p[1];
                if (p[1] > maxY) maxY = p[1];
            });
        });
        // 海南岛/南海诸岛在南方很远，会把主疆域压得很小 —— 单独处理
        var pad = 0.8;
        PROJ = {
            minX: minX - pad, maxX: maxX + pad,
            minY: 18.2, maxY: maxY + pad   // 纬度下限截到 18.2°（海南岛单独画小）
        };
    }
    // 按 adcode 取 feature（数字/字符串都兼容）
    function featOf(adc) {
        adc = String(adc);
        for (var i = 0; i < GEO.features.length; i++) {
            if (String(GEO.features[i].properties.adcode) === adc) return GEO.features[i];
        }
        return null;
    }
    function walk(c, fn) {
        if (typeof c[0] === 'number') { fn(c); return; }
        for (var i = 0; i < c.length; i++) walk(c[i], fn);
    }
    var W = 790, H = 600;
    function sx(lon) { return (lon - PROJ.minX) / (PROJ.maxX - PROJ.minX) * (W - 60) + 30; }
    function sy(lat) { return (PROJ.maxY - lat) / (PROJ.maxY - PROJ.minY) * (H - 56) + 28; }
    // 海南岛用独立小比例尺画在右下（古舆图"附图"惯例）
    var HAINAN_SCALE = 1.35;
    function ihx(lon) { return (W - 150) + (lon - 108.4) * HAINAN_SCALE * 6; }
    function ihy(lat) { return (H - 92) - (lat - 18.0) * HAINAN_SCALE * 6; }

    // ====== 抽稀 + 平滑 ======
    function ringToPath(ring, minDist) {
        // 抽稀：跳过过近的点，控制路径长度
        var pts = [];
        for (var i = 0; i < ring.length; i++) {
            var x = sx(ring[i][0]), y = sy(ring[i][1]);
            if (pts.length === 0) { pts.push([x, y]); continue; }
            var dx = x - pts[pts.length - 1][0], dy = y - pts[pts.length - 1][1];
            if (dx * dx + dy * dy >= minDist * minDist) pts.push([x, y]);
        }
        if (pts.length < 3) return '';
        return smoothOpen(pts, true);
    }
    function smoothOpen(xyArr, closed) {
        var n = xyArr.length;
        var d = 'M' + xyArr[0][0].toFixed(1) + ',' + xyArr[0][1].toFixed(1);
        var last = closed ? n : n - 1;
        for (var i = 0; i < last; i++) {
            var p0 = xyArr[(i - 1 + n) % n], p1 = xyArr[i % n];
            var p2 = xyArr[(i + 1) % n], p3 = xyArr[(i + 2) % n];
            if (!closed) { p0 = xyArr[Math.max(0, i - 1)]; p3 = xyArr[Math.min(n - 1, i + 2)]; }
            var c1x = p1[0] + (p2[0] - p0[0]) / 6 * 0.7;
            var c1y = p1[1] + (p2[1] - p0[1]) / 6 * 0.7;
            var c2x = p2[0] - (p3[0] - p1[0]) / 6 * 0.7;
            var c2y = p2[1] - (p3[1] - p1[1]) / 6 * 0.7;
            d += 'C' + c1x.toFixed(1) + ',' + c1y.toFixed(1) + ' '
                      + c2x.toFixed(1) + ',' + c2y.toFixed(1) + ' '
                      + p2[0].toFixed(1) + ',' + p2[1].toFixed(1);
        }
        return d + (closed ? 'Z' : '');
    }

    // ====== 状态/数值 ======
    function statusOf(k){ try { return (GameState.mapData&&GameState.mapData.status)?(GameState.mapData.status[k]||0):0; } catch(e){ return 0; } }
    function hx(c){ return [parseInt(c.substr(1,2),16),parseInt(c.substr(3,2),16),parseInt(c.substr(5,2),16)]; }
    function mix(a,b,t){ var x=hx(a),y=hx(b);
        return 'rgb('+Math.round(x[0]+(y[0]-x[0])*t)+','+Math.round(x[1]+(y[1]-x[1])*t)+','+Math.round(x[2]+(y[2]-x[2])*t)+')'; }
    function fillOf(p){ var s=statusOf(p.id), b=(GC[p.grp]||GC.plain).fill;
        if (s===2) return mix(b,'#b03a1e',0.60);
        if (s===1) return mix(b,'#c9a238',0.48);
        return b; }
    function strokeOf(p){ var s=statusOf(p.id);
        if (s===2) return '#6d1a0e';
        if (s===1) return '#8a6616';
        return (GC[p.grp]||GC.plain).stroke; }

    function prov(key){
        try {
            if (typeof pvEnsure==='function'){ try{ pvEnsure(); }catch(e){} }
            var r=(typeof GameState==='object'&&GameState.province)?GameState.province:null;
            var box=(r&&r.prov)?r.prov:r;
            return (box&&box[key])||{wealth:45,grain:45,arms:40,people:50,probity:46,disaffect:18};
        } catch(e){ return {wealth:45,grain:45,arms:40,people:50,probity:46,disaffect:18}; }
    }

    // ====== 长距离水系（按经纬）======
    var YR=[[101.0,36.5],[103.0,36.0],[105.0,36.2],[106.5,37.5],[108.0,38.0],[109.5,37.5],
            [110.5,35.3],[111.0,34.7],[112.5,34.9],[114.0,34.9],[115.2,35.2],[116.5,36.2],
            [117.5,37.4],[119.0,37.4]];
    var YZ=[[104.5,28.6],[106.5,29.4],[108.0,30.2],[109.2,30.6],[110.8,31.0],[112.0,30.9],
            [113.5,30.6],[114.5,30.8],[115.6,30.2],[116.6,29.9],[117.8,31.0],
            [119.0,31.3],[120.3,31.0],[121.2,30.6],[122.0,31.2]];
    var CN=[[121.3,30.6],[120.4,31.2],[119.0,32.0],[117.8,32.6],[116.8,33.4],[115.8,34.2],
            [116.3,35.0],[116.9,35.6],[116.5,36.5],[116.5,37.5],[116.5,38.5],
            [116.4,39.4],[116.4,39.9]];
    var WALL=[[98.3,39.7],[100.4,39.2],[102.2,37.9],[104.0,37.7],[105.4,38.4],[106.9,38.3],
              [108.6,38.4],[110.2,38.4],[111.6,38.2],[113.0,39.4],[114.4,40.3],
              [115.8,40.7],[117.2,40.4],[119.0,39.9],[120.3,40.4]];
    function geoLine(ll){ var d=''; for (var i=0;i<ll.length;i++) d+=(i?'L':'M')+sx(ll[i][0]).toFixed(1)+','+sy(ll[i][1]).toFixed(1); return d; }

    // ====== 山峰（按经纬）======
    var MTN = [
        [99.6,37.6],[101.4,36.6],[105.6,38.0],[109.6,38.0],[114.6,39.6],[116.8,40.4],
        [117.8,40.2],[112.2,38.2],[108.0,34.8],[106.8,36.2],[102.4,31.0],[104.0,29.6],
        [114.8,27.8],[117.4,26.4],[119.4,29.4],[120.0,28.8],[105.0,26.8],[106.0,26.4],
        [99.6,26.0],[101.0,24.6],[107.6,24.4],[121.6,42.4],[123.0,41.8]
    ];
    function mtnSym(x,y,s){
        return '<g class="atl-m" transform="translate('+x.toFixed(1)+','+y.toFixed(1)+') scale('+(s||1)+')">'
             + '<path d="M-4.5,2.2 L0,-3.2 L4.5,2.2"></path><path d="M-2.2,4 L2.2,-1.4"></path></g>';
    }

    function waves() {
        var h = '';
        var pts = [[123.0,40.6],[124.6,40.2],[123.6,38.8],[124.6,37.2],[123.4,35.2],
                   [124.2,33.0],[122.8,31.0],[123.4,28.8],[121.6,26.6],[120.6,24.6],
                   [118.6,23.2],[116.4,22.4],[114.4,21.4],[112.0,21.0],[110.0,20.6],
                   [108.8,21.6],[110.8,19.6],[113.2,18.6],[116.2,18.2],[119.2,18.6],
                   [121.6,20.0],[124.0,22.4],[125.0,26.0],[123.6,30.0],[124.6,34.4],
                   [123.8,38.4],[125.4,40.2]];
        for (var i=0;i<pts.length;i++){
            var x=sx(pts[i][0]), y=sy(pts[i][1]);
            h += '<path class="atl-w" d="M'+x.toFixed(1)+','+y.toFixed(1)+' q6,-3 12,0 q6,3 12,0 q6,-3 12,0"></path>';
            h += '<path class="atl-w" d="M'+x.toFixed(1)+','+(y+6).toFixed(1)+' q6,-3 12,0 q6,3 12,0 q6,-3 12,0"></path>';
        }
        return h;
    }

    // ====== SVG ======
    function svgBody() {
        if (!boot()) return '<div class="atlas-stage"><div style="padding:40px;text-align:center;color:#8b2c1a">地图数据载入中…</div></div>';

        var h = '<svg viewBox="0 0 '+W+' '+H+'" class="atlas-svg" preserveAspectRatio="xMidYMid meet">';
        h += '<defs>'
           + '<radialGradient id="silk" cx="44%" cy="36%" r="76%">'
           +   '<stop offset="0%" stop-color="#fdf7e8"/><stop offset="52%" stop-color="#f4ead3"/>'
           +   '<stop offset="100%" stop-color="#ddcda1"/></radialGradient>'
           + '<pattern id="wv" width="5" height="5" patternUnits="userSpaceOnUse">'
           +   '<line x1="0" y1="0" x2="0" y2="5" stroke="#9a7f42" stroke-width="0.3" opacity="0.08"/>'
           +   '<line x1="0" y1="0" x2="5" y2="0" stroke="#9a7f42" stroke-width="0.3" opacity="0.05"/>'
           + '</pattern>'
           + '<filter id="ds" x="-25%" y="-25%" width="150%" height="150%">'
           +   '<feDropShadow dx="0" dy="2" stdDeviation="2.2" flood-color="#1a1005" flood-opacity="0.42"/></filter>'
           + '<filter id="ds2" x="-40%" y="-40%" width="180%" height="180%">'
           +   '<feDropShadow dx="0" dy="1.5" stdDeviation="1.4" flood-color="#1a1005" flood-opacity="0.5"/></filter>'
           + '</defs>';
        h += '<rect width="'+W+'" height="'+H+'" fill="url(#silk)"></rect>';
        h += '<rect width="'+W+'" height="'+H+'" fill="url(#wv)"></rect>';

        // 经纬
        h += '<g class="atl-g">';
        var stepX = Math.ceil((PROJ.maxX - PROJ.minX) / 6 / 5) * 5;
        for (var lo = Math.ceil(PROJ.minX / 5) * 5; lo <= PROJ.maxX; lo += 5) {
            h += '<line x1="'+sx(lo).toFixed(1)+'" y1="24" x2="'+sx(lo).toFixed(1)+'" y2="'+(H-24)+'"></line>';
        }
        for (var la = Math.ceil(PROJ.minY / 5) * 5; la <= PROJ.maxY; la += 5) {
            h += '<line x1="24" y1="'+sy(la).toFixed(1)+'" x2="'+(W-24)+'" y2="'+sy(la).toFixed(1)+'"></line>';
        }
        h += '</g>';

        h += '<g class="atl-wv">' + waves() + '</g>';
        h += '<g class="atl-wr"><path d="'+geoLine(YR)+'" class="atl-r"></path>'
           +   '<path d="'+geoLine(YZ)+'" class="atl-r"></path>'
           +   '<path d="'+geoLine(CN)+'" class="atl-r atl-r-c"></path></g>';

        // 海岸线：取东南沿海省份外缘（简化，取相关省的最外圈）
        var COAST_ADC = { '350000':1,'440000':1,'330000':1,'460000':1,'320000':1 };
        h += '<g class="atl-cs">';
        GEO.features.forEach(function (f) {
            if (!COAST_ADC[String(f.properties.adcode)]) return;
            var polys = f.geometry.type === 'Polygon' ? [f.geometry.coordinates] : f.geometry.coordinates;
            polys.forEach(function (poly) {
                var outer = poly[0];
                if (outer.length < 4) return;
                var minDist = 1.6;
                var pts = [];
                for (var i = 0; i < outer.length; i++) {
                    var x = sx(outer[i][0]), y = sy(outer[i][1]);
                    if (pts.length === 0 || (x - pts[pts.length-1][0])*(x - pts[pts.length-1][0]) + (y - pts[pts.length-1][1])*(y - pts[pts.length-1][1]) >= minDist*minDist) pts.push([x,y]);
                }
                if (pts.length > 2) h += '<path d="'+smoothOpen(pts,false)+'" fill="none"></path>';
            });
        });
        h += '</g>';

        // 省份（真实边界）
        h += '<g class="atl-pv">';
        for (var mi = 0; mi < MING.length; mi++) {
            var p = MING[mi];
            var d = '';
            var isHainan = (p.id === 'hainan');
            for (var si = 0; si < p.src.length; si++) {
                var feat = featOf(p.src[si]);
                if (!feat) continue;
                var polys = feat.geometry.type === 'Polygon' ? [feat.geometry.coordinates] : feat.geometry.coordinates;
                for (var pi = 0; pi < polys.length; pi++) {
                    var outer = polys[pi][0];
                    if (outer.length < 3) continue;
                    if (isHainan) {
                        // 海南：独立小图
                        var hp = [];
                        for (var hi = 0; hi < outer.length; hi++) hp.push([ihx(outer[hi][0]), ihy(outer[hi][1])]);
                        d += smoothOpen(hp, true);
                    } else {
                        d += ringToPath(outer, 1.4);
                    }
                }
            }
            if (!d) continue;
            h += '<g class="atl-p" data-id="'+p.id+'" onclick="atlPick(\''+p.id+'\')" '
               + 'onmouseover="atlHover(\''+p.id+'\')" onmouseout="atlOut()">'
               + '<path d="'+d+'" fill="'+fillOf(p)+'" stroke="'+strokeOf(p)+'" fill-rule="evenodd" class="atl-s"></path>'
               + (p.id==='hainan'
                   ? '<text x="'+(ihx(p.lon)).toFixed(1)+'" y="'+(ihy(p.lat)).toFixed(1)+'" class="atl-n" text-anchor="middle">'+p.nm+'</text>'
                   : '<text x="'+sx(p.lon).toFixed(1)+'" y="'+sy(p.lat).toFixed(1)+'" class="atl-n" text-anchor="middle">'+p.nm+'</text>')
               + '</g>';
        }
        h += '</g>';

        // 山峰
        h += '<g class="atl-ms">';
        for (var mi2 = 0; mi2 < MTN.length; mi2++) h += mtnSym(sx(MTN[mi2][0]), sy(MTN[mi2][1]), 0.9);
        h += '</g>';

        // 长城
        h += '<path d="'+geoLine(WALL)+'" class="atl-wl" fill="none"></path>';
        for (var w=0;w<WALL.length;w+=2)
            h += '<circle cx="'+sx(WALL[w][0]).toFixed(1)+'" cy="'+sy(WALL[w][1]).toFixed(1)+'" r="2" class="atl-wn"></circle>';

        // 九边菱标
        h += '<g class="atl-garr">';
        for (var g=0;g<GARRISON.length;g++){
            var ga=GARRISON[g], gx=sx(ga.lon), gy=sy(ga.lat);
            h += '<g class="atl-gg" data-g="'+ga.id+'" onclick="atlGar(\''+ga.id+'\')" '
               + 'onmouseover="atlGarHover(\''+ga.id+'\')" onmouseout="atlOut()">'
               + '<circle cx="'+gx.toFixed(1)+'" cy="'+gy.toFixed(1)+'" r="13" fill="transparent" class="atl-ghit"></circle>'
               + '<path d="M'+gx.toFixed(1)+','+(gy-5.5).toFixed(1)+' L'+(gx+5.5).toFixed(1)+','+gy.toFixed(1)
               + ' L'+gx.toFixed(1)+','+(gy+5.5).toFixed(1)+' L'+(gx-5.5).toFixed(1)+','+gy.toFixed(1)+' Z" class="atl-gd"></path>'
               + '<circle cx="'+gx.toFixed(1)+'" cy="'+gy.toFixed(1)+'" r="1.6" class="atl-gc"></circle>'
               + '<text x="'+(gx+9).toFixed(1)+'" y="'+(gy-7).toFixed(1)+'" class="atl-gt">'+ga.nm+'</text>'
               + '</g>';
        }
        h += '</g>';

        // 敌国据点（14 处）
        if (typeof WAR !== 'undefined') {
            var w = WAR.state();
            h += '<g class="atl-enemy">';
            w.zones.forEach(function (z) {
                var pw = WAR.ENEMY_POWERS[z.pow];
                if (!pw) return;
                // 平滑曲线（势力范围，非硬边色块）
                var ptsXY = z.poly.map(function (p) { return [sx(p[0]), sy(p[1])]; });
                var dPath = smoothOpen(ptsXY, true);
                var pts = z.poly.map(function (p) { return sx(p[0]).toFixed(1) + ',' + sy(p[1]).toFixed(1); });
                var cxs = z.poly.reduce(function (s, p) { return s + sx(p[0]); }, 0) / z.poly.length;
                var cys = z.poly.reduce(function (s, p) { return s + sy(p[1]); }, 0) / z.poly.length;
                // 已取者变己方色（青），示为羁縻州县
                var fill = z.occupied ? '#3e6b52' : pw.color;
                var stroke = z.occupied ? '#264a37' : pw.stroke;
                var mark = z.occupied ? '取' : pw.banner;
                h += '<g class="atl-ez'+(z.occupied?' is-held':'')+'" data-z="'+z.id+'" onclick="atlZone(\''+z.id+'\')" '
                   + 'onmouseover="atlZoneHover(\''+z.id+'\')" onmouseout="atlOut()">'
                   // 敌国区域：填色 + 斜线纹理（古舆图质感）
                   + '<path d="'+dPath+'" class="atl-ezp" fill="'+fill+'" stroke="'+stroke+'"></path>'
                   + '<path d="'+dPath+'" class="atl-eztx" stroke="'+stroke+'" fill="none"></path>'
                   // 域内纹理：依方位布山、草、瀚海
                   + foeTexture(z, pts, stroke)
                   + '<text x="'+cxs.toFixed(1)+'" y="'+(cys+3.5).toFixed(1)+'" class="atl-ezt" text-anchor="middle">'+mark+'</text>'
                   + '<text x="'+cxs.toFixed(1)+'" y="'+(cys+13).toFixed(1)+'" class="atl-eznm" text-anchor="middle">'+z.nm+'</text>'
                   + (z.occupied
                        ? '<text x="'+cxs.toFixed(1)+'" y="'+(cys+21.5).toFixed(1)+'" class="atl-ezg" text-anchor="middle">羁縻</text>'
                        : '')
                   + '</g>';
            });
            h += '</g>';

            // 叛军标记
            h += '<g class="atl-rebel">';
            w.rebels.forEach(function (r) {
                var prov = (typeof ATLAS_LIST !== 'undefined') ? ATLAS_LIST.filter(function(x){return x.id===r.prov;})[0] : null;
                if (!prov) return;
                var rx = sx(prov.lon), ry = sy(prov.lat);
                h += '<g class="atl-rb" data-r="'+r.id+'" onclick="atlRebel(\''+r.id+'\')" '
                   + 'onmouseover="atlRebelHover(\''+r.id+'\')" onmouseout="atlOut()">'
                   + '<circle cx="'+rx.toFixed(1)+'" cy="'+ry.toFixed(1)+'" r="10" class="atl-rbring"></circle>'
                   + '<circle cx="'+rx.toFixed(1)+'" cy="'+ry.toFixed(1)+'" r="7.5" class="atl-rbbg"></circle>'
                   + '<text x="'+rx.toFixed(1)+'" y="'+(ry+3.5).toFixed(1)+'" class="atl-rbt" text-anchor="middle">叛</text>'
                   + '</g>';
            });
            h += '</g>';
        }

        // 京城
        var jx=sx(116.4), jy=sy(39.9);
        h += '<g class="atl-cap" transform="translate('+jx.toFixed(1)+','+jy.toFixed(1)+')">'
           + '<circle r="7" fill="none" stroke="#b02a1e" stroke-width="1.5"></circle>'
           + '<rect x="-3.6" y="-3.6" width="7.2" height="7.2" fill="#b02a1e"></rect>'
           + '<rect x="-1.5" y="-1.5" width="3" height="3" fill="#fdf7e8"></rect>'
           + '<text y="-12.5" class="atl-capl" text-anchor="middle">京师</text></g>';

        // 罗盘
        h += '<g transform="translate('+(W-318)+','+(H-74)+')">'
           + '<circle r="19" fill="rgba(253,247,232,0.6)" stroke="#8b6a2a" stroke-width="1.1"></circle>'
           + '<circle r="13" fill="none" stroke="#8b6a2a" stroke-width="0.7" opacity="0.65"></circle>'
           + '<path d="M0,-13 L3.4,0 L0,13 L-3.4,0 Z" fill="#a8321e"></path>'
           + '<text y="-23" class="atl-nl" text-anchor="middle">北</text></g>';

        // 海南附图框
        h += '<g class="atl-inset">'
           + '<rect x="'+(W-160).toFixed(1)+'" y="'+(H-118).toFixed(1)+'" width="124" height="94" '
           + 'fill="rgba(253,247,232,0.55)" stroke="#8b6a2a" stroke-width="1" stroke-dasharray="4 3"></rect>'
           + '<text x="'+(W-152).toFixed(1)+'" y="'+(H-104).toFixed(1)+'" class="atl-inset-t">海南附图</text>'
           + '</g>';

        // 题签
        h += '<g transform="translate(40,'+(H-58)+')">'
           + '<rect width="150" height="48" rx="2" fill="rgba(253,247,232,0.9)" stroke="#8b2c1a" stroke-width="1.5"></rect>'
           + '<rect x="4" y="4" width="142" height="40" rx="1" fill="none" stroke="#8b2c1a" stroke-width="0.55" opacity="0.55"></rect>'
           + '<text x="75" y="20" class="atl-cart" text-anchor="middle">大明疆域舆图</text>'
           + '<text x="75" y="36" class="atl-cars" text-anchor="middle">两京十三布政司</text></g>';

        // 印
        h += '<g transform="translate(' + (W - 214) + ',' + (H - 106) + ')">'
           + '<rect width="30" height="30" rx="1.5" fill="none" stroke="#a8321e" stroke-width="2.1"></rect>'
           + '<text x="15" y="14" class="atl-st" text-anchor="middle">御</text>'
           + '<text x="15" y="26" class="atl-st" text-anchor="middle">览</text></g>';


        // 驻军点
        var o = (typeof OVL !== 'undefined') ? OVL.state() : null;
        if (o && o.layers.mil) {
            h += '<g class="atl-mil">';
            for (var gi = 0; gi < OVL.nodes.length; gi++) {
                var gn = OVL.nodes[gi];
                var mx = sx(gn.lon), my = sy(gn.lat);
                var big = gn.troops >= 50000;
                h += '<g class="atl-gnode" data-n="'+gn.id+'" onclick="atlNode(\''+gn.id+'\')" onmouseover="atlNodeHover(\''+gn.id+'\')" onmouseout="atlOut()">'
                   + '<circle cx="'+mx.toFixed(1)+'" cy="'+my.toFixed(1)+'" r="12" fill="transparent" class="atl-ghit"></circle>'
                   + '<circle cx="'+mx.toFixed(1)+'" cy="'+my.toFixed(1)+'" r="'+(big?7:5)+'" class="atl-gnd '+(gn.kind==='边军'?'bian':'nei')+'"></circle>'
                   + '<text x="'+mx.toFixed(1)+'" y="'+(my+ (big?20:16)).toFixed(1)+'" class="atl-gtxt" text-anchor="middle">'+gn.nm+'</text>'
                   + '</g>';
            }
            h += '</g>';
        }

        // 行军路线（带箭头，动画）
        if (o && o.layers.mil && o.armies.length) {
            h += '<g class="atl-march">';
            for (var ai = 0; ai < o.armies.length; ai++) {
                var ar = o.armies[ai];
                var fr = nodePos(ar.from), tr = nodePos(ar.to);
                if (!fr || !tr) continue;
                var cx = (fr[0]+tr[0])/2, cy = (fr[1]+tr[1])/2 - 40;
                h += '<path d="M'+fr[0].toFixed(1)+','+fr[1].toFixed(1)+' Q'+cx.toFixed(1)+','+cy.toFixed(1)+' '+tr[0].toFixed(1)+','+tr[1].toFixed(1)+'" class="atl-marchline"></path>';
                // 箭头
                var ax = sx(ar.at.lon), ay = sy(ar.at.lat);
                h += '<g transform="translate('+ax.toFixed(1)+','+ay.toFixed(1)+')">'
                   + '<path d="M-5,-4 L5,0 L-5,4 Z" class="atl-marcharrow"></path></g>';
                h += '<text x="'+ax.toFixed(1)+'" y="'+(ay-12).toFixed(1)+'" class="atl-marchlbl" text-anchor="middle">'+ar.name+' '+num(ar.troops,0)+'</text>';
            }
            h += '</g>';
        }

        // 商路
        if (o && o.layers.trade) {
            h += '<g class="atl-trade">';
            for (var ti = 0; ti < OVL.tradeRoutes.length; ti++) {
                var tr2 = OVL.tradeRoutes[ti];
                h += '<path d="'+geoLine(tr2.pts)+'" class="atl-tradelin" data-t="'+tr2.nm+'" onmouseover="atlTradeHover(\''+tr2.nm+'\',\''+tr2.cargo+'\')" onmouseout="atlOut()"></path>';
            }
            h += '</g>';
        }

        // 驿路
        if (o && o.layers.post) {
            h += '<g class="atl-post">';
            for (var pi = 0; pi < OVL.postRoutes.length; pi++) {
                var pr = OVL.postRoutes[pi];
                h += '<path d="'+geoLine(pr.pts)+'" class="atl-postlin" data-p="'+pr.nm+'" onmouseover="atlPostHover(\''+pr.nm+'\')" onmouseout="atlOut()"></path>';
            }
            h += '</g>';
        }

        // 地图事件
        if (o && o.layers.event) {
            h += '<g class="atl-mev">';
            o.mapEvents.forEach(function (e) {
                if (e.handled) return;
                var ex = sx(e.lon), ey = sy(e.lat);
                h += '<g class="atl-mevnode" data-u="'+e.uid+'" onclick="atlEvent(\''+e.uid+'\')" onmouseover="atlEventHover(\''+e.uid+'\')" onmouseout="atlOut()">'
                   + '<circle cx="'+ex.toFixed(1)+'" cy="'+ey.toFixed(1)+'" r="11" class="atl-mevring"></circle>'
                   + '<circle cx="'+ex.toFixed(1)+'" cy="'+ey.toFixed(1)+'" r="8" class="atl-mevbg '+e.kind+'"></circle>'
                   + '<text x="'+ex.toFixed(1)+'" y="'+(ey+4).toFixed(1)+'" class="atl-mevtxt" text-anchor="middle">'+e.icon+'</text>'
                   + '</g>';
            });
            h += '</g>';
        }


        return h + '</svg>';
    }

    // ====== 视图 ======
    function render() {
        try {
            if (!GameState.mapData || !GameState.mapData.status) {
                GameState.mapData = (typeof initMapState==='function')
                    ? initMapState(GameState.script?GameState.script.id:'chenghua')
                    : { status:{}, lastPatrol:{}, lastTag:null };
            }
            GameState.mapData.status = GameState.mapData.status || {};
            for (var i=0;i<MING.length;i++)
                if (typeof GameState.mapData.status[MING[i].id] !== 'number') GameState.mapData.status[MING[i].id] = 0;
        } catch(e){}

        var view = window._atlasView || 'map';
        var h = '<div class="atlas-wrap">';
        h += '<div class="atlas-head">'
           + '<span class="atlas-title">大明两京十三布政司舆图</span>'
           + '<span class="atlas-sub">真实省界投影 · 九边为军事重镇</span>'
           + '<span class="atlas-views">'
           +   '<span class="atlas-v'+(view==='map'?' on':'')+'" onclick="atlView(\'map\')">舆图</span>'
           +   '<span class="atlas-v'+(view==='rank'?' on':'')+'" onclick="atlView(\'rank\')">省情榜</span>'
           +   '<span class="atlas-v'+(view==='stat'?' on':'')+'" onclick="atlView(\'stat\')">六维总览</span>'
           + '</span></div>';
        h += (view==='map')?mapView():(view==='rank')?rankView():statView();
        return h + '</div>';
    }

    function mapView() {
        var o = (typeof OVL !== 'undefined') ? OVL.state() : null;
        var L = o ? o.layers : { mil:true, trade:false, post:false, event:true };

        var h = '<div class="atlas-stage">' + svgBody() + '</div>';
        h += '<div class="atlas-zoombar">'
           + '<button class="atl-zb" onclick="atlZoom(0.25)" title="放大">＋</button>'
           + '<button class="atl-zb" onclick="atlZoom(-0.25)" title="缩小">－</button>'
           + '<button class="atl-zb" onclick="atlZoomFit()" title="全览">全</button>'
           + '<span class="atl-zv" id="atl-zv">100%</span>'
           + '<span class="atl-zhint">滚轮缩放 · 拖拽平移</span>'
           + '</div>';

        // 图层开关
        h += '<div class="atlas-layers">'
           + '<span class="al-tt">图层</span>'
           + '<span class="al-lay' + (L.mil?' on':'') + '" onclick="OVL.toggleLayer(\'mil\')">军务</span>'
           + '<span class="al-lay' + (L.trade?' on':'') + '" onclick="OVL.toggleLayer(\'trade\')">商路</span>'
           + '<span class="al-lay' + (L.post?' on':'') + '" onclick="OVL.toggleLayer(\'post\')">驿路</span>'
           + '<span class="al-lay' + (L.event?' on':'') + '" onclick="OVL.toggleLayer(\'event\')">邸报</span>'
           + (o && o.armies.length ? '<span class="al-info">行军 ' + o.armies.length + ' 路</span>' : '')
           + (o && o.mapEvents.length ? '<span class="al-info warn">待处 ' + o.mapEvents.filter(function(e){return !e.handled;}).length + ' 事</span>' : '')
           + '</div>';

        h += '<div class="atlas-legend">';
        h += '<span class="al-g" style="background:'+GC.border.fill+'">九边</span>';
        var ns=['capital','plain','rich','coast','remote'];
        for (var i=0;i<ns.length;i++) h += '<span class="al-g" style="background:'+GC[ns[i]].fill+'">'+GC[ns[i]].name+'</span>';
        h += '<span class="al-s"></span>'
          +  '<span><i class="atl-d" style="background:#5f6a44"></i>安</span>'
          +  '<span><i class="atl-d" style="background:#8a7a3a"></i>警</span>'
          +  '<span><i class="atl-d" style="background:#9a4a2e"></i>乱</span>'
          +  '<span class="al-s"></span>'
          +  '<span><i class="atl-l"></i>长城</span>'
          +  '<span><i class="atl-l" style="background:#3f6f8f"></i>江河</span>'
          +  '<span><i class="atl-l atl-c"></i>运河</span>'
          +  '<span><i class="atl-dia"></i>九边镇</span>'
          +  '<span><i class="atl-mkr"></i>驻军</span>'
          +  '<span><i class="atl-mkr mil"></i>行军</span>'
          +  '<span><i class="atl-mkr trade"></i>商路</span>'
          +  '<span><i class="atl-mkr post"></i>驿路</span>'
          +  '<span><i class="atl-mkr evt"></i>邸报</span>'
          +  '<span><i class="atl-mkr foe"></i>敌国</span>'
          +  '<span><i class="atl-mkr reb"></i>叛乱</span>'
          + '</div>';
        h += warPanel();
        h += '<div class="atlas-detail" id="atlas-detail"></div>';
        return h;
    }

    // ====== 敌国域内地形纹理（古舆图笔意）======
    function foeTexture(z, pts, stroke) {
        try {
            // 取多边形包围盒
            var xs = [], ys = [];
            z.poly.forEach(function (p) { xs.push(sx(p[0])); ys.push(sy(p[1])); });
            var x0 = Math.min.apply(null, xs), x1 = Math.max.apply(null, xs);
            var y0 = Math.min.apply(null, ys), y1 = Math.max.apply(null, ys);
            var seed = 0;
            for (var i = 0; i < z.id.length; i++) seed += z.id.charCodeAt(i);
            var out = '';
            // 山峰符号（西北多山）
            var mt = (z.pow === 'tatar' || z.pow === 'tibet' || z.pow === 'tusi' || z.pow === 'jurchen') ? 5 : 2;
            for (var m = 0; m < mt; m++) {
                var px = x0 + ((seed * (m + 3) * 37) % 100) / 100 * (x1 - x0) * 0.85 + (x1 - x0) * 0.08;
                var py = y0 + ((seed * (m + 5) * 53) % 100) / 100 * (y1 - y0) * 0.8 + (y1 - y0) * 0.12;
                out += '<path d="M'+px.toFixed(1)+','+(py+4).toFixed(1)+' L'+(px-4.5).toFixed(1)+','+(py+4).toFixed(1)
                     + ' L'+px.toFixed(1)+','+(py-5).toFixed(1)+' L'+(px+4.5).toFixed(1)+','+(py+4).toFixed(1)+' Z" '
                     + 'fill="none" stroke="'+stroke+'" stroke-width="0.9" opacity="0.62"></path>';
            }
            // 草地/瀚海点
            var dots = (z.pow === 'mongol' || z.pow === 'tatar') ? 14 : 5;
            for (var d = 0; d < dots; d++) {
                var dx = x0 + ((seed * (d + 2) * 29) % 100) / 100 * (x1 - x0) * 0.88 + (x1 - x0) * 0.06;
                var dy = y0 + ((seed * (d + 7) * 71) % 100) / 100 * (y1 - y0) * 0.88 + (y1 - y0) * 0.06;
                out += '<circle cx="'+dx.toFixed(1)+'" cy="'+dy.toFixed(1)+'" r="0.9" fill="'+stroke+'" opacity="0.42"></circle>';
            }
            return out;
        } catch (e) { return ''; }
    }

    // ====== v8.2 敌情与战报面板 ======
    function warPanel() {
        try {
            if (typeof WAR === 'undefined') return '';
            var w = WAR.state();
            var foes = w.zones.filter(function(z){ return !z.occupied; });
            var held = w.zones.filter(function(z){ return z.occupied; });
            var h = '<div class="atl-war"><div class="atl-wt">敌国态势 · 战报</div>';

            if (w.rebels.length) {
                h += '<div class="atl-wrow"><span class="atl-wtag">叛</span><span>'
                   + w.rebels.map(function(r){
                       return r.provNm + '·' + r.leader + '(' + num(r.troops,0) + '人)';
                   }).join('　')
                   + '</span></div>';
            }
            if (foes.length) {
                h += '<div class="atl-wrow"><span class="atl-wtag s">敌</span><span>'
                   + foes.slice(0,6).map(function(z){
                       return WAR.ENEMY_POWERS[z.pow].banner + z.nm;
                   }).join('　')
                   + (foes.length>6 ? ' 等'+foes.length+'处' : '')
                   + '</span></div>';
            }
            if (held.length) {
                h += '<div class="atl-wrow"><span class="atl-wtag g">取</span><span>'
                   + held.map(function(z){ return z.nm; }).join('　')
                   + '（已置羁縻）</span></div>';
            }
            if (w.battles.length) {
                var b = w.battles[0];
                h += '<div class="atl-wrow"><span class="atl-wtag '+(b.win?'g':'')+'">'
                   + (b.win?'克':'败') + '</span><span>' + b.atk + '攻' + b.def + '，'
                   + '亡'+num(b.aLoss,0)+'/'+num(b.dLoss,0) + '，' + b.terrain
                   + '（胜算' + num(b.chance,0) + '%）</span></div>';
            }
            if (!w.rebels.length && !foes.length && !held.length && !w.battles.length) {
                h += '<div class="atl-wrow"><span>四境无事。</span></div>';
            }
            h += '</div>';
            return h;
        } catch (e) { return ''; }
    }

    function rankView() {
        var rows = MING.map(function(p){
            var pv=prov(p.id), sc=0;
            for (var k in pv) if (typeof pv[k]==='number') sc+=pv[k];
            var st=statusOf(p.id);
            return {p:p,pv:pv,sc:(st===2)?Math.round(sc*0.7):sc,st:st};
        });
        rows.sort(function(a,b){ return b.sc-a.sc; });
        var h='<div class="atlas-rank">';
        h+='<div class="atlas-rank-head"><span>名</span><span>布政使司</span><span>总况</span>'
          + '<span>富庶</span><span>粮产</span><span>武备</span><span>户口</span><span>吏治</span><span>怨望</span><span>局</span></div>';
        for (var i=0;i<rows.length;i++){
            var r=rows[i];
            h+='<div class="atlas-rank-row'+(r.p.grp==='border'?' is-b':'')+'" onclick="atlPick(\''+r.p.id+'\')">'
              + '<span class="atl-rn">'+(i+1)+'</span><span class="atl-rm">'+r.p.nm+'</span>'
              + '<span class="atl-rs">'+num(r.sc)+'</span>'
              + bar('富',r.pv.wealth)+bar('粮',r.pv.grain)+bar('武',r.pv.arms)
              + bar('户',r.pv.people)+bar('吏',r.pv.probity)+bar('怨',r.pv.disaffect,1)
              + '<span class="atl-rt s'+r.st+'">'+(r.st===2?'乱':r.st===1?'警':'安')+'</span></div>';
        }
        return h+'</div>';
    }
    function bar(l,v,inv){
        var n=num(v,0), w=inv?(100-n):n;
        var c=w>66?'#3d6b4a':w>33?'#a8912f':'#9a4a2e';
        return '<span class="atl-br"><i class="atl-br-l">'+l+'</i>'
             + '<i class="atl-br-t"><i class="atl-br-f" style="width:'+Math.max(0,Math.min(100,w))+'%;background:'+c+'"></i></i>'
             + '<i class="atl-br-n">'+num(v,0)+'</i></span>';
    }

    function statView() {
        var h='<div class="atlas-stat">';
        h+='<div class="atlas-stat-h">六维一览 · 富庶 / 粮产 / 武备 / 户口 / 吏治 / 怨望（怨望已反向，深为善）</div>';
        h+='<div class="atlas-mx">';
        var ks=['wealth','grain','arms','people','probity','disaffect'];
        for (var i=0;i<MING.length;i++){
            var p=MING[i], pv=prov(p.id);
            h+='<div class="atlas-mx-row'+(p.grp==='border'?' is-b':'')+'" onclick="atlPick(\''+p.id+'\')">'
              + '<span class="atl-mn">'+p.nm+'</span>';
            for (var j=0;j<ks.length;j++){
                var n=num(pv[ks[j]],0), v=(ks[j]==='disaffect')?(100-n):n;
                var c=v>66?'#3d6b4a':v>33?'#a8912f':'#9a4a2e';
                h+='<span class="atlas-mx-c" style="background:'+c+';opacity:'+(0.26+v/142).toFixed(2)+'"></span>';
            }
            h+='</div>';
        }
        return h+'</div></div>';
    }

    // ====== 交互 ======
    var GAR2PROV = { gansu_g:'gansu', ningxia_g:'ningxia', yansui_g:'shaanxi', guyuan_g:'shaanxi',
                     shanxi_g:'shanxi', datong_g:'beizhili', xuanfu_g:'beizhili', jizhou_g:'beizhili' };
    function byId(id){ for (var i=0;i<MING.length;i++) if (MING[i].id===id) return MING[i]; return null; }
    function garById(id){ for (var i=0;i<GARRISON.length;i++) if (GARRISON[i].id===id) return GARRISON[i]; return null; }
    function track(e){ try { window.atlMouse={x:e.clientX,y:e.clientY}; } catch(x){} }
    if (typeof document!=='undefined') document.addEventListener('mousemove', track, true);

    function kv(k,v,inv){
        var n=num(v,0), w=inv?(100-n):n;
        var c=w>66?'#8fd0a8':w>33?'#e6c878':'#e89a78';
        return '<span class="atl-kv"><i>'+k+'</i><b style="color:'+c+'">'+n+'</b></span>';
    }
    function tipHost(){
        var t = document.getElementById('atlas-tip');
        if (!t) {
            t = document.createElement('div');
            t.id = 'atlas-tip';
            t.className = 'atlas-tip';
        }
        if (t.parentNode !== document.body) document.body.appendChild(t);
        return t;
    }
    function place(tip){
        try {
            var m = window.atlMouse || { x:200, y:200 };
            var w=344, hh=244, x=m.x+22, y=m.y+16;
            if (x+w>window.innerWidth) x=m.x-w-18;
            if (y+hh>window.innerHeight) y=m.y-hh-14;
            if (x<8) x=8; if (y<8) y=8;
            tip.style.position='fixed'; tip.style.left=x+'px'; tip.style.top=y+'px';
        } catch(e){}
    }

    window.atlHover = function (id) {
        try {
            var tip=tipHost(); if(!tip) return;
            var p=byId(id); if(!p) return;
            var pv=prov(id), st=statusOf(id), g=GC[p.grp]||GC.plain;
            var gr = GARRISON.filter(function(x){ return GAR2PROV[x.id]===id; });
            tip.innerHTML='<div class="atl-th">'+p.nm+'<i style="background:'+g.fill+'">'+g.name+'</i></div>'
              +'<div class="atl-ta">'+(p.alias||'')+' · '+(st===2?'动乱灾荒':st===1?'有警兆':'安定')+'</div>'
              +'<div class="atl-tn">'+(p.note||'')+'</div>'
              +'<div class="atl-tc">'+(p.city||'')+'</div>'
              +'<div class="atl-ts">'+(p.srcRef||'')+'</div>'
              +'<div class="atl-tst">'+kv('富',pv.wealth)+kv('粮',pv.grain)+kv('武',pv.arms)
              +kv('户',pv.people)+kv('吏',pv.probity)+kv('怨',pv.disaffect,1)+'</div>'
              +(gr.length? '<div class="atl-tgr">辖边镇：'+gr.map(function(x){return x.nm;}).join('、')+'</div>':'');
            place(tip); tip.classList.add('on');
        } catch(e){}
    };

    window.atlGarHover = function (id) {
        try {
            var tip=tipHost(); if(!tip) return;
            var ga=garById(id); if(!ga) return;
            tip.innerHTML='<div class="atl-th">'+ga.nm+'<i style="background:#6f5b44">九边重镇</i></div>'
              +'<div class="atl-ta">戍所：'+ga.src+'</div>'
              +'<div class="atl-tn">沿长城设镇，募兵实边。兵强则藩屏固，兵虚则虏骑入。饷自内地转输，最耗帑藏。</div>'
              +'<div class="atl-tc">额兵 '+ga.force+'</div>'
              +'<div class="atl-tgr">此处非行政区，乃军事重镇。点选可增戍设卫。</div>';
            place(tip); tip.classList.add('on');
        } catch(e){}
    };

    window.atlOut = function(){ try{ var t=document.getElementById('atlas-tip'); if(t) t.classList.remove('on'); }catch(e){} };

    window.atlGar = function (gid) {
        var pid = GAR2PROV[gid];
        if (pid) { try { window.atlPick(pid); } catch(e){} }
    };

    var ACTS = {
        patrol:  { nm:'车驾巡边', cd:4, cost:0,
          run:function(){ G.prestige=cl(G.prestige+2); G.stability=cl(G.stability+2); return '车驾临'+this.nm+'，军民相安。威望 +2 稳定 +2'; } },
        relief:  { nm:'赈恤安民', cd:3, cost:1200,
          run:function(){ G.treasury-=1200; G.stability=cl(G.stability+6); G.food=num(G.food,0)+200; stt(this.id,0); return '赈恤'+this.nm+'，散粟振饥。费银 1200两，稳定 +6 粮 +200'; } },
        garrison:{ nm:'增戍设卫', cd:5, cost:2000,
          run:function(){ G.treasury-=2000; G.militaryPower=num(G.militaryPower,0)+400; G.militaryFood=Math.max(0,num(G.militaryFood,0)-200); stt(this.id,0); return '增戍'+this.nm+'，设卫所。费银 2000两，军力 +400 军粮 -200'; } },
        granary: { nm:'常平仓籴', cd:4, cost:0,
          run:function(){ var b=Math.min(1500,Math.max(0,Math.floor(G.treasury*0.15))); G.treasury-=b; G.food=num(G.food,0)+Math.floor(b*1.4); G.agriculture=cl(num(G.agriculture,30)+2); return '常平仓于'+this.nm+'籴粮：出银 '+b+'两，入粮 '+Math.floor(b*1.4)+' 石'; } },
        road:    { nm:'修桥铺路', cd:5, cost:1500,
          run:function(){ G.treasury-=1500; G.commerce=cl(num(G.commerce,30)+3); G.canalEfficiency=cl(num(G.canalEfficiency,20)+2); return '修桥铺路于'+this.nm+'：费银 1500两，商业 +3 漕运 +2'; } },
        school:  { nm:'设府学', cd:6, cost:800,
          run:function(){ G.treasury-=800; G.culture=cl(num(G.culture,30)+4); G.stability=cl(G.stability+2); return '设府学于'+this.nm+'：费银 800两，文化 +4 稳定 +2'; } }
    };
    function stt(id,v){ try{ if(GameState.mapData&&GameState.mapData.status) GameState.mapData.status[id]=v; }catch(e){} }
    var G={};
    function cl(v){ return Math.max(0,Math.min(100,Math.round(num(v,0)))); }

    window.atlPick = function (id) {
        try {
            var box=document.getElementById('atlas-detail'); if(!box) return;
            var p=byId(id); if(!p) return;
            var pv=prov(id), st=statusOf(id), g=GC[p.grp]||GC.plain;
            var gr=GARRISON.filter(function(x){ return GAR2PROV[x.id]===id; });
            box.innerHTML='<div class="atl-dh">'
              + '<span class="atl-dn">'+p.nm+'</span>'
              + '<span class="atl-dg" style="background:'+g.fill+'">'+g.name+'</span>'
              + '<span class="atl-da">'+(p.alias||'')+'</span>'
              + '<span class="atl-dt s'+st+'">'+(st===2?'动乱灾荒':st===1?'有警兆':'安定')+'</span></div>'
              + '<div class="atl-dc">'+(p.city||'')+'　·　'+(p.srcRef||'')+'</div>'
              + '<div class="atl-dn2">'+(p.note||'')+'</div>'
              + '<div class="atl-ds">'+kv('富庶',pv.wealth)+kv('粮产',pv.grain)+kv('武备',pv.arms)
              + kv('户口',pv.people)+kv('吏治',pv.probity)+kv('怨望',pv.disaffect,1)+'</div>'
              + (gr.length? '<div class="atl-dgr">辖九边重镇：'+gr.map(function(x){return x.nm+'（'+x.src+'）';}).join('、')+'</div>':'')
              + '<div class="atl-da"><div class="atl-dat">施政于'+p.nm+'</div><div class="atl-dar">'
              + '<button class="atl-b" onclick="atlAct(\''+id+'\',\'patrol\')">车驾巡边</button>'
              + '<button class="atl-b" onclick="atlAct(\''+id+'\',\'relief\')">赈恤安民</button>'
              + '<button class="atl-b" onclick="atlAct(\''+id+'\',\'garrison\')">增戍设卫</button>'
              + '<button class="atl-b" onclick="atlAct(\''+id+'\',\'granary\')">常平仓籴</button>'
              + '<button class="atl-b" onclick="atlAct(\''+id+'\',\'road\')">修桥铺路</button>'
              + '<button class="atl-b" onclick="atlAct(\''+id+'\',\'school\')">设府学</button>'
              + '</div></div>'
              + buildPanel(id);
            box.classList.add('on');
        } catch(e){}
    };

    // ====== v8.3 营造面板 ======
    function buildPanel(id) {
        try {
            if (typeof BUILD === 'undefined') return '';
            var mods = BUILD.provMods(id);
            var b = BUILD.state();
            var site = b.sites.filter(function (x) { return x.prov === id; });
            var pend = b.pending.filter(function (x) { return x.prov === id; });
            var h = '<div class="atl-da"><div class="atl-dat">营造（'+BUILD.provNm(id)+'）</div><div class="atl-dar">';
            var keys = Object.keys(BUILD.TYPES);
            for (var i = 0; i < keys.length; i++) {
                var t = BUILD.TYPES[keys[i]];
                var has = site.some(function (x) { return x.type === keys[i]; });
                var ing = pend.some(function (x) { return x.type === keys[i]; });
                var dis = (has || ing || num(GameState.stats.treasury, 0) < t.cost) ? ' disabled' : '';
                h += '<button class="atl-b' + (has ? ' atl-b-done' : '') + '"' + dis
                   + ' onclick="atlBuild(\''+id+'\',\''+keys[i]+'\')" title="'+t.desc+'">'
                   + t.nm + '<i>' + t.cost + '两</i></button>';
            }
            h += '</div></div>';
            // 已建成
            if (site.length) {
                h += '<div class="atl-dgr">已建：' + site.map(function (x) {
                    var tt = BUILD.TYPES[x.type];
                    return tt ? (tt.nm + '（守势+' + Math.round(tt.defMul * 100) + '%）') : x.type;
                }).join('、') + '</div>';
            }
            if (pend.length) {
                h += '<div class="atl-dgr" style="color:#a8763a">在造：' + pend.map(function (x) {
                    var tt = BUILD.TYPES[x.type];
                    return (tt ? tt.nm : x.type) + '（尚需 ' + x.turnsLeft + ' 季）';
                }).join('、') + '</div>';
            }
            // 总加成
            if (site.length) {
                h += '<div class="atl-dn2">此地守方战力 ×' + BUILD.defFactor(id).toFixed(2)
                   + '（含营造）'
                   + (mods.grain ? '　每季入粮 ' + mods.grain + ' 石' : '')
                   + (mods.silver ? '　入银 ' + mods.silver + ' 两' : '')
                   + (mods.troops ? '　常驻 ' + mods.troops + ' 人' : '')
                   + '</div>';
            }
            return h;
        } catch (e) { return ''; }
    }

    window.atlBuild = function (id, typeKey) {
        try {
            if (typeof BUILD === 'undefined') return;
            var res = BUILD.start(id, typeKey);
            if (!res.ok) {
                if (typeof pushNews === 'function') pushNews('营造', res.msg || '营造不成', 'critical');
                return;
            }
            if (typeof atlRenderNow === 'function') atlRenderNow();
            window.atlPick(id);
        } catch (e) {}
    };

    function bust(){
        try {
            if (GameState&&GameState.homeState&&GameState.homeState._loaded)
                for (var k in GameState.homeState._loaded)
                    if (Object.prototype.hasOwnProperty.call(GameState.homeState._loaded,k)&&k.indexOf('war:')===0)
                        delete GameState.homeState._loaded[k];
        } catch(e){}
    }

    window.atlAct = function (id,act) {
        try {
            if (typeof sanitizeStats==='function') sanitizeStats();
            var s=GameState.stats;
            G.treasury=num(s.treasury,0); G.food=num(s.food,0); G.militaryFood=num(s.militaryFood,0);
            G.militaryPower=num(s.militaryPower,0); G.stability=num(s.stability,50); G.prestige=num(s.prestige,50);
            G.agriculture=num(s.agriculture,30); G.commerce=num(s.commerce,30);
            G.culture=num(s.culture,30); G.canalEfficiency=num(s.canalEfficiency,20);

            var a=ACTS[act]; if(!a) return;
            var tick=(typeof getMapTick==='function')?getMapTick():1;
            if (!GameState.mapData) GameState.mapData={status:{},lastPatrol:{}};
            if (!GameState.mapData.status) GameState.mapData.status={};
            if (!GameState.mapData._cd) GameState.mapData._cd={};

            var last=GameState.mapData._cd[id+':'+act]||0;
            if (last && tick-last<a.cd) {
                if (typeof pushNews==='function') pushNews('舆图',a.nm+'未逾 '+a.cd+' 章，不可行。','normal');
                return;
            }
            if (a.cost>G.treasury) {
                if (typeof pushNews==='function') pushNews('内库','国库不足（'+G.treasury+' 两），'+a.nm+'未行。','critical');
                return;
            }
            a.id=id; a.nm=byId(id).nm;
            var msg=a.run();

            s.treasury=G.treasury; s.food=G.food; s.militaryFood=G.militaryFood;
            s.militaryPower=G.militaryPower; s.stability=G.stability; s.prestige=G.prestige;
            s.agriculture=G.agriculture; s.commerce=G.commerce; s.culture=G.culture; s.canalEfficiency=G.canalEfficiency;
            GameState.mapData._cd[id+':'+act]=tick;

            if (typeof pushNews==='function') pushNews('舆图',msg,'normal');
            if (typeof v71Float==='function') v71Float(a.nm);
            if (typeof sanitizeStats==='function') sanitizeStats();
            bust();
            if (typeof homeRefresh==='function') homeRefresh();
            if (typeof saveGame==='function'){ try{ saveGame(); }catch(e){} }
            window.atlPick(id);
        } catch(e){}
    };

    window.atlView = function (v){ try{ window._atlasView=v; bust(); if(typeof homeRefresh==='function') homeRefresh(); }catch(e){} };

    // ====== 态势层交互 ======
    function nodePos(id) {
        if (typeof OVL === 'undefined') return null;
        var n = OVL.byNode(id);
        if (!n) return null;
        return [sx(n.lon), sy(n.lat)];
    }
    window.atlRenderNow = function () {
        try {
            bust();
            if (typeof homeRefresh === 'function') homeRefresh();
        
        try { atlBindZoom(); } catch (e) {}
    } catch (e) {}
    };

    // 驻军点：点击 → 派兵面板
    window.atlNode = function (nid) {
        try {
            if (typeof OVL === 'undefined') return;
            var n = OVL.byNode(nid);
            if (!n) return;
            window._atlNodeSel = nid;
            var box = document.getElementById('atlas-detail');
            if (!box) return;
            var others = OVL.nodes.filter(function (x) { return x.id !== nid; });
            box.innerHTML = '<div class="atl-dh">'
              + '<span class="atl-dn">'+n.nm+'</span>'
              + '<span class="atl-dg" style="background:'+(n.kind==='边军'?'#6f5b44':'#8b6a2d')+'">'+n.kind+'</span>'
              + '<span class="atl-da">驻军 ' + num(n.troops,0) + ' 人</span>'
              + '<span class="atl-dt s0">整备</span></div>'
              + '<div class="atl-dn2">此为'+n.nm+'驻军。发兵赴他处，须行军若干月，耗费粮饷。兵至则驻军增加，然原驻减。兵少于五千，不成军。粮饷不足则中途哗变。</div>'
              + '<div class="atl-da"><div class="atl-dat">自此发兵</div>'
              + '<div class="atl-dar">'
              + '<select class="atl-sel" id="atl-dest">'
              + others.map(function (x) { return '<option value="'+x.id+'">'+x.nm+'（'+x.kind+'）</option>'; }).join('')
              + '</select>'
              + '<select class="atl-sel" id="atl-troops">'
              + [10000,20000,30000,50000].map(function (v) { return '<option value="'+v+'">兵 '+v+'</option>'; }).join('')
              + '</select>'
              + '<button class="atl-b" onclick="atlDispatch()">发兵</button>'
              + '</div></div>';
            box.classList.add('on');
        } catch (e) {}
    };

    window.atlDispatch = function () {
        try {
            if (typeof OVL === 'undefined') return;
            var from = window._atlNodeSel;
            var dest = document.getElementById('atl-dest');
            var tr = document.getElementById('atl-troops');
            if (!from || !dest || !tr) return;
            var a = OVL.dispatch(from, dest.value, parseInt(tr.value,10));
            if (a) {
                var box = document.getElementById('atlas-detail');
                if (box) {
                    box.innerHTML = '<div class="atl-dh"><span class="atl-dn">'+a.name+'</span>'
                      + '<span class="atl-dg" style="background:#6f5b44">行军</span>'
                      + '<span class="atl-da">赴' + OVL.byNode(a.to).nm + '</span></div>'
                      + '<div class="atl-dn2">兵 '+num(a.troops,0)+' 人，自'+OVL.byNode(a.from).nm+'起程，行 '+a.totalMonths+' 月，耗费粮饷 '+num(a.cost,0)+' 石。途中可见行军路线移动。</div>';
                    box.classList.add('on');
                }
            }
        } catch (e) {}
    };

    window.atlNodeHover = function (nid) {
        try {
            if (typeof OVL === 'undefined') return;
            var n = OVL.byNode(nid);
            if (!n) return;
            var tip = tipHost(); if (!tip) return;
            tip.innerHTML = '<div class="atl-th">'+n.nm+'<i style="background:#6f5b44">'+n.kind+'</i></div>'
              + '<div class="atl-ta">驻军 '+num(n.troops,0)+' 人</div>'
              + '<div class="atl-tn">点此可发兵赴他处。行军费时费粮，兵至则增戍。</div>';
            place(tip); tip.classList.add('on');
        } catch (e) {}
    };

    window.atlTradeHover = function (nm, cargo) {
        try {
            var tip = tipHost(); if (!tip) return;
            tip.innerHTML = '<div class="atl-th">商路<i style="background:#4a7a52">商贸</i></div>'
              + '<div class="atl-ta">'+nm+'</div>'
              + '<div class="atl-tn">主要货物：'+cargo+'。开图层后每季按市易景气入账。</div>';
            place(tip); tip.classList.add('on');
        } catch (e) {}
    };

    window.atlPostHover = function (nm) {
        try {
            var tip = tipHost(); if (!tip) return;
            tip.innerHTML = '<div class="atl-th">驿路<i style="background:#8b6a2d">驿递</i></div>'
              + '<div class="atl-ta">'+nm+'</div>'
              + '<div class="atl-tn">明代驿递网络。急递文书、军情、漕粮皆循此道。驿马疲敝，则政令不通。</div>';
            place(tip); tip.classList.add('on');
        } catch (e) {}
    };

    window.atlEvent = function (uid) {
        try {
            if (typeof OVL === 'undefined') return;
            var o = OVL.state();
            var e = null;
            o.mapEvents.forEach(function (x) { if (x.uid === uid) e = x; });
            if (!e) return;
            var box = document.getElementById('atlas-detail');
            if (!box) return;

            // 敌寇入边：专属处置（迎战 / 固守 / 弃守）
            if (e.kind === 'invasion') {
                var prov = (GameState.province && GameState.province.prov) ? GameState.province.prov[e.prov] : null;
                var ter = (typeof WAR !== 'undefined') ? WAR.terrainOf(e.prov) : { nm:'平原', def:1.0, desc:'' };
                var city = (typeof WAR !== 'undefined') ? WAR.cityDefense(e.prov) : 1.0;
                var guard = null, gd = 1e9;
                if (typeof OVL !== 'undefined') {
                    OVL.nodes.forEach(function (n) {
                        var d = Math.abs(n.lon - e.lon) + Math.abs(n.lat - e.lat);
                        if (d < gd) { gd = d; guard = n; }
                    });
                }
                box.innerHTML = '<div class="atl-dh">'
                  + '<span class="atl-dn">'+e.provNm+'·敌寇入边</span>'
                  + '<span class="atl-dg" style="background:#8b2c1a">兵燹</span>'
                  + '<span class="atl-da">'+ter.nm+'</span>'
                  + '<span class="atl-dt s2">第 '+(num(e.age,0)+1)+' 季</span></div>'
                  + '<div class="atl-dc">来犯 '+num(e.enemyTroops,0)+' 人'
                  + (guard ? '　守军 '+num(guard.troops,0)+' 人（'+guard.nm+'）' : '')
                  + '</div>'
                  + '<div class="atl-dn2">'+e.desc+'此地方守方战力×'+ter.def.toFixed(2)+'，城防×'+city.toFixed(2)+'。'
                  + '若三季之内不能处置，此城必失——失守则军亡、粮被掠、百姓怨望暴涨。</div>'
                  + '<div class="atl-da"><div class="atl-dat">应敌之策</div><div class="atl-dar">'
                  + '<button class="atl-b" onclick="atlInvasion(\''+e.uid+'\',\'fight\')">出城迎战</button>'
                  + '<button class="atl-b" onclick="atlInvasion(\''+e.uid+'\',\'defend\')">闭关固守（费500两）</button>'
                  + '<button class="atl-b" onclick="atlInvasion(\''+e.uid+'\',\'flee\')">弃守内避</button>'
                  + '</div></div>';
                box.classList.add('on');
                return;
            }

            box.innerHTML = '<div class="atl-dh">'
              + '<span class="atl-dn">'+e.provNm+'·'+e.nm+'</span>'
              + '<span class="atl-dg" style="background:'+(e.kind==='war'?'#8b2c1a':e.kind==='trade'?'#4a7a52':'#8b6a2d')+'">'+({war:'兵事',disaster:'灾异',trade:'商贸',politics:'国政'})[e.kind]+'</span>'
              + '<span class="atl-dt s2">待处</span></div>'
              + '<div class="atl-dn2">'+e.desc+'</div>'
              + '<div class="atl-da"><div class="atl-dat">处置</div><div class="atl-dar">'
              + '<button class="atl-b" onclick="atlResolve(\''+e.uid+'\',\'query\')">遣官查勘</button>'
              + '<button class="atl-b" onclick="atlResolve(\''+e.uid+'\',\'relief\')">发帑赈济（800两）</button>'
              + '<button class="atl-b" onclick="atlResolve(\''+e.uid+'\',\'troops\')">发兵弹压（1500两）</button>'
              + '<button class="atl-b" onclick="atlResolve(\''+e.uid+'\',\'ignore\')">置之不问</button>'
              + '</div></div>';
            box.classList.add('on');
        } catch (e) {}
    };

    window.atlEventHover = function (uid) {
        try {
            if (typeof OVL === 'undefined') return;
            var o = OVL.state();
            var e = null;
            o.mapEvents.forEach(function (x) { if (x.uid === uid) e = x; });
            if (!e) return;
            var tip = tipHost(); if (!tip) return;
            tip.innerHTML = '<div class="atl-th">'+e.provNm+'·'+e.nm+'<i style="background:#8b2c1a">邸报</i></div>'
              + '<div class="atl-tn">'+e.desc+'</div>'
              + '<div class="atl-tgr">点此可处置此案。</div>';
            place(tip); tip.classList.add('on');
        } catch (e) {}
    };

    // ====== 敌寇入边处置 ======
    window.atlInvasion = function (uid, choice) {
        try {
            if (typeof OVL === 'undefined' || typeof WAR === 'undefined') return;
            var o = OVL.state();
            var e = null;
            for (var i = 0; i < o.mapEvents.length; i++) if (o.mapEvents[i].uid === uid) e = o.mapEvents[i];
            if (!e) return;
            var s = GameState.stats;
            var ter = WAR.terrainOf(e.prov);
            var city = WAR.cityDefense(e.prov);
            var guard = null, gd = 1e9;
            OVL.nodes.forEach(function (n) {
                var d = Math.abs(n.lon - e.lon) + Math.abs(n.lat - e.lat);
                if (d < gd) { gd = d; guard = n; }
            });
            var msg = '';
            var won = false;

            if (choice === 'fight') {
                // 出城迎战：用最近驻军迎敌，走攻防公式
                if (!guard || num(guard.troops,0) < 500) { msg = '边地无兵可战。'; }
                else {
                    var res = WAR.battle(
                        { troops: guard.troops, morale: clamp2(num(s.mandate,50) + 10), supply: 80 },
                        { troops: e.enemyTroops, morale: 75, supply: 70 },
                        { terrainDef: ter.def, terrainNm: ter.nm, city: city,
                          atkName: (guard ? guard.nm : '边军') + '军', defName: '入寇之敌' }
                    );
                    guard.troops = Math.max(0, num(guard.troops,0) - res.atkLoss);
                    e.enemyTroops = res.defLeft;
                    won = res.atkWins;
                    try {
                        var w = WAR.state();
                        w.battles.unshift({
                            atk: res.atkName, def: res.defName, win: res.atkWins,
                            aLoss: res.atkLoss, dLoss: res.defLoss, terrain: res.terrain,
                            chance: Math.round(res.chance*100), t: (GameState.currentYear||0)
                        });
                        if (w.battles.length > 20) w.battles.pop();
                    } catch (err) {}
                    msg = '胜算 '+Math.round(res.chance*100)+'%，我军亡 '+res.atkLoss+'，敌亡 '+res.defLoss+'。'
                        + '地形'+res.terrain+'（守方×'+res.terrainDef.toFixed(2)+'，城防×'+res.city.toFixed(2)+'）。';
                    if (won && res.defLeft < e.enemyTroops * 0.5) {
                        e.handled = true;
                        msg += ' 敌众已溃，此寇遂平。';
                        s.stability = clamp2(num(s.stability,50) + 4);
                        s.prestige = clamp2(num(s.prestige,50) + 3);
                        if (typeof pushNews === 'function') pushNews('战报', e.provNm + '之战，我军却敌，斩获甚众。', 'normal');
                    } else {
                        msg += ' 敌势未衰，尚须再战。';
                    }
                }
            } else if (choice === 'defend') {
                // 闭关固守：以城防与地形取胜，但费帑
                if (num(s.treasury,0) < 500) { msg = '国库不足，军需不给。'; }
                else {
                    s.treasury -= 500;
                    var res2 = WAR.battle(
                        { troops: e.enemyTroops, morale: 70, supply: 60 },
                        { troops: guard ? guard.troops : 5000, morale: clamp2(num(s.mandate,50)), supply: 85 },
                        { terrainDef: ter.def * city, terrainNm: ter.nm, city: city,
                          atkName: '入寇之敌', defName: (guard ? guard.nm : '边军') + '军守城' }
                    );
                    won = (res2.atkWins === false);   // 敌军未克，即我守成
                    if (guard) guard.troops = Math.max(0, num(guard.troops,0) - res2.defLoss);
                    try {
                        var w2 = WAR.state();
                        w2.battles.unshift({
                            atk: res2.atkName, def: res2.defName, win: won,
                            aLoss: res2.atkLoss, dLoss: res2.defLoss, terrain: res2.terrain,
                            chance: Math.round(res2.chance*100), t: (GameState.currentYear||0)
                        });
                        if (w2.battles.length > 20) w2.battles.pop();
                    } catch (err) {}
                    e.enemyTroops = res2.atkLeft;
                    msg = '守城之战，敌我亡 '+res2.atkLoss+'/'+res2.defLoss+'。';
                    if (res2.atkWins) {
                        // 敌军攻破
                        msg += ' 城守吃紧，须再谋。';
                    } else {
                        // 我军守住
                        e.handled = true;
                        msg += ' 敌不能克城下，遂退。';
                        s.stability = clamp2(num(s.stability,50) + 2);
                        s.prestige = clamp2(num(s.prestige,50) + 2);
                    }
                }
            } else {
                // 弃守内避：保军保民，失地
                e.handled = true;
                if (guard) guard.troops = Math.max(0, num(guard.troops,0) - Math.round(num(e.enemyTroops,0) * 0.05));
                s.stability = clamp2(num(s.stability,50) - 6);
                var pv = (GameState.province && GameState.province.prov) ? GameState.province.prov[e.prov] : null;
                if (pv) pv.disaffect = clamp2(num(pv.disaffect,20) + 12);
                msg = '弃城而走，百姓震恐。稳定 -6，此地怨望 +12。';
                if (typeof pushNews === 'function') pushNews('战报', e.provNm + '失守，官军退保内关。', 'critical');
            }

            if (e.handled) {
                // 从事件列表移除
                o.mapEvents = o.mapEvents.filter(function (x) { return x.uid !== uid; });
            }
            if (typeof atlRenderNow === 'function') atlRenderNow();
            var box = document.getElementById('atlas-detail');
            if (box) {
                box.innerHTML = '<div class="atl-dh"><span class="atl-dn">'+e.provNm+'·应敌</span>'
                  + '<span class="atl-dt s'+(won?'0':'2')+'">'+(won?'胜':'未决')+'</span></div>'
                  + '<div class="atl-dn2">'+msg+'</div>';
                box.classList.add('on');
            }
        } catch (e) {}
    };
    function clamp2(v) { return Math.max(0, Math.min(100, Math.round(Number(v)||0))); }

    window.atlResolve = function (uid, choice) {
        try {
            if (typeof OVL === 'undefined') return;
            OVL.resolve(uid, choice);
        } catch (e) {}
    };

    // ====== 敌国据点 ======
    window.atlZone = function (zid) {
        try {
            if (typeof WAR === 'undefined') return;
            var w = WAR.state();
            var z = null;
            w.zones.forEach(function (x) { if (x.id === zid) z = x; });
            if (!z) return;
            window._atlZoneSel = zid;
            var pw = WAR.ENEMY_POWERS[z.pow];
            var ter = WAR.zoneTerrain(z);
            var box = document.getElementById('atlas-detail');
            if (!box) return;
            box.innerHTML = '<div class="atl-dh">'
              + '<span class="atl-dn">'+z.nm+'</span>'
              + '<span class="atl-dg" style="background:'+pw.color+'">'+pw.nm+'</span>'
              + '<span class="atl-da">'+ter.nm+'</span>'
              + '<span class="atl-dt s2">未服</span></div>'
              + '<div class="atl-dc">驻兵 '+num(z.troops,0)+' 人　士气 '+num(z.morale,0)+'　补给 '+num(z.supply,0)+'</div>'
              + '<div class="atl-dn2">'+pw.desc+'　'+z.note+'。地形'+ter.nm+'：守方战力×'+ter.def.toFixed(2)+'，'+ter.desc+'。</div>'
              + '<div class="atl-dgr">'+((z.src || '')+'　'+pw.src || '')+'</div>'
              + (z.occupied ? '<div class="atl-dgr">此地已为我朝羁縻，士卒牧守其地。</div>' : '')
              + (z.occupied ? '' :
                 '<div class="atl-da"><div class="atl-dat">兴师攻取</div><div class="atl-dar">'
              + '<select class="atl-sel" id="atl-atk">'
              + [5000,10000,20000,30000,50000].map(function(v){return '<option value="'+v+'">兵 '+v+'</option>';}).join('')
              + '</select>'
              + '<button class="atl-b" onclick="wzbOpenZone(\''+z.id+'\')">进攻</button>'
              + '</div></div>'
              + '<div class="atl-da"><div class="atl-dat">遣使交涉</div><div class="atl-dar">'
              + '<button class="atl-b" onclick="atlPeace()">议和（费1200两）</button>'
              + '<span class="atl-hint">敌意 '+num(foeHostility(z),0)+' · 善战 '+num(foeStrength(z),0)+'</span>'
              + '</div></div>');
            box.classList.add('on');
        } catch (e) {}
    };

    function foeHostility(z) {
        try {
            if (!GameState || !GameState.nations) return 50;
            var nm = (typeof WAR !== 'undefined') ? WAR.POW_TO_NATION[z.pow] : null;
            var h = 50;
            GameState.nations.forEach(function (n) { if (n.name === nm) h = num(n.hostility, 50); });
            return h;
        } catch (e) { return 50; }
    }
    function foeStrength(z) {
        try {
            if (!GameState || !GameState.nations) return 50;
            var nm = (typeof WAR !== 'undefined') ? WAR.POW_TO_NATION[z.pow] : null;
            var v = 50;
            GameState.nations.forEach(function (n) { if (n.name === nm) v = num(n.strength, 50); });
            return v;
        } catch (e) { return 50; }
    }

    window.atlPeace = function () {
        try {
            if (typeof WAR === 'undefined') return;
            var zid = window._atlZoneSel;
            if (!zid) return;
            var res = WAR.makePeace(zid);
            if (typeof atlRenderNow === 'function') atlRenderNow();
            var box = document.getElementById('atlas-detail');
            if (!box) return;
            if (!res.ok) {
                box.innerHTML = '<div class="atl-dh"><span class="atl-dn">议和不成</span><span class="atl-dt s2">拒</span></div>'
                  + '<div class="atl-dn2">'+clean(res.msg, '彼不受命')+'</div>';
            } else {
                box.innerHTML = '<div class="atl-dh"><span class="atl-dn">'+res.zone.nm+'议和</span>'
                  + '<span class="atl-dt s0">成</span></div>'
                  + '<div class="atl-dn2">'+clean('遣使赍金往聘，两家罢兵。敌意减三十五，善战减五。威望稍损。','议和已成')+'</div>';
            }
            box.classList.add('on');
        } catch (e) {}
    };

    window.atlAttackZone = function () {
        try {
            if (typeof WAR === 'undefined') return;
            var zid = window._atlZoneSel;
            var sel = document.getElementById('atl-atk');
            if (!zid || !sel) return;
            var res = WAR.attackZone(zid, parseInt(sel.value, 10));
            var box = document.getElementById('atlas-detail');
            if (!res.ok) {
                if (box) {
                    box.innerHTML = '<div class="atl-dh"><span class="atl-dn">进兵不得</span><span class="atl-dt s2">败</span></div>'
                      + '<div class="atl-dn2">'+clean(res.msg, '军务不成')+'</div>';
                    box.classList.add('on');
                }
                return;
            }
            var r = res.result;
            if (typeof atlRenderNow === 'function') atlRenderNow();
            var box2 = document.getElementById('atlas-detail');
            if (box2) {
                box2.innerHTML = '<div class="atl-dh"><span class="atl-dn">'+res.zone.nm+'之战</span>'
                  + '<span class="atl-dt s'+(r.atkWins?'0':'2')+'">'+(r.atkWins?'克':'败')+'</span></div>'
                  + '<div class="atl-dn2">胜算 '+Math.round(r.chance*100)+'%，我军战力 '+r.atkPower+'，敌军战力 '+r.defPower+'。'
                  + '我军亡 '+r.atkLoss+' 人，敌军亡 '+r.defLoss+' 人。地形：'+r.terrain+'（守方×'+r.terrainDef.toFixed(2)+'，城防×'+r.city.toFixed(2)+'）。'
                  + (r.atkWins ? '敌势已蹙。' : '我军不利，当退。') + '</div>';
                box2.classList.add('on');
            }
        } catch (e) {}
    };

    window.atlZoneHover = function (zid) {
        try {
            if (typeof WAR === 'undefined') return;
            var w = WAR.state();
            var z = null;
            w.zones.forEach(function (x) { if (x.id === zid) z = x; });
            if (!z) return;
            var pw = WAR.ENEMY_POWERS[z.pow];
            var ter = WAR.zoneTerrain(z);
            var tip = tipHost(); if (!tip) return;
            tip.innerHTML = '<div class="atl-th">'+z.nm+'<i style="background:'+pw.color+'">'+pw.nm+'</i></div>'
              + '<div class="atl-ta">驻兵 '+num(z.troops,0)+'　士气 '+num(z.morale,0)+'　补给 '+num(z.supply,0)+'　地形'+ter.nm+'</div>'
              + '<div class="atl-tn">'+z.note+'。'+ter.desc+'，守方战力×'+ter.def.toFixed(2)+'。</div>'
              + '<div class="atl-tn" style="opacity:.72">'+pw.desc+'</div>'
              + '<div class="atl-tgr">点此可兴师攻取。</div>';
            place(tip); tip.classList.add('on');
        } catch (e) {}
    };

    // ====== 叛军 ======
    window.atlRebel = function (rid) {
        try {
            if (typeof WAR === 'undefined') return;
            var w = WAR.state();
            var r = null;
            w.rebels.forEach(function (x) { if (x.id === rid) r = x; });
            if (!r) return;
            window._atlRebelSel = rid;
            var ter = WAR.terrainOf(r.prov);
            var box = document.getElementById('atlas-detail');
            if (!box) return;
            var rk = (typeof REBEL !== 'undefined' && REBEL.KINDS[r.kind]) ? REBEL.KINDS[r.kind] : null;
            box.innerHTML = '<div class="atl-dh">'
              + '<span class="atl-dn">'+r.provNm+'叛乱</span>'
              + '<span class="atl-dg" style="background:#8b2c1a">'+r.leader+'</span>'
              + '<span class="atl-da">'+(rk ? rk.nm : '民变')+'</span>'
              + '<span class="atl-dt s2">叛乱</span></div>'
              + '<div class="atl-dc">乱兵 '+num(r.troops,0)+' 人　士气 '+num(r.morale,0)+'　已据 '+r.age+' 季</div>'
              + '<div class="atl-dn2">'+ (rk ? rk.desc : '') + (rk ? rk.src : '')
              + ' 此地地形'+ter.nm+'，守方战力×'+ter.def.toFixed(2)+'，城防×'+WAR.cityDefense(r.prov).toFixed(2)+'。'
              + (r.betrayed ? ' <b style="color:#c0392b">此辈已通'+WAR.ENEMY_POWERS[r.ally].nm+'为内应，其势益张。</b>' : '')
              + ' 若不早平，恐蔓延邻郡。</div>'
              + '<div class="atl-da"><div class="atl-dat">兴师平叛</div><div class="atl-dar">'
              + '<button class="atl-b" onclick="wzbOpenRebel(\''+r.id+'\')">发兵进剿</button>'
              + '<button class="atl-b" onclick="atlAmnesty(\''+r.id+'\')">招抚（散党归农）</button>'
              + '</div></div>';
            box.classList.add('on');
        } catch (e) {}
    };

    window.atlSuppress = function () {
        try {
            if (typeof WAR === 'undefined') return;
            var rid = window._atlRebelSel;
            var sel = document.getElementById('atl-sup');
            if (!rid || !sel) return;
            var res = WAR.suppressRebel(rid, parseInt(sel.value, 10));
            var box = document.getElementById('atlas-detail');
            if (!res.ok) {
                if (box) {
                    box.innerHTML = '<div class="atl-dh"><span class="atl-dn">平叛不得</span><span class="atl-dt s2">败</span></div>'
                      + '<div class="atl-dn2">'+clean(res.msg,'军饷不给')+'</div>';
                    box.classList.add('on');
                }
                return;
            }
            var r = res.result;
            if (typeof atlRenderNow === 'function') atlRenderNow();
            var box2 = document.getElementById('atlas-detail');
            if (box2) {
                box2.innerHTML = '<div class="atl-dh"><span class="atl-dn">'+res.rebel.provNm+'平叛</span>'
                  + '<span class="atl-dt s'+(r.atkWins?'0':'2')+'">'+(r.atkWins?'胜':'败')+'</span></div>'
                  + '<div class="atl-dn2">胜算 '+Math.round(r.chance*100)+'%，我军亡 '+r.atkLoss+'，叛军亡 '+r.defLoss+'。'
                  + '地形'+r.terrain+'（守方×'+r.terrainDef.toFixed(2)+'，城防×'+r.city.toFixed(2)+'）。'
                  + (r.atkWins?'乱势稍定。':'叛势益张。')+'</div>';
                box2.classList.add('on');
            }
        } catch (e) {}
    };

    window.atlAmnesty = function (rid) {
        try {
            if (typeof REBEL === 'undefined') return;
            var res = REBEL.amnesty(rid);
            if (typeof atlRenderNow === 'function') atlRenderNow();
            var box = document.getElementById('atlas-detail');
            if (!box) return;
            if (!res.ok) {
                box.innerHTML = '<div class="atl-dh"><span class="atl-dn">招抚不成</span><span class="atl-dt s2">拒</span></div>'
                  + '<div class="atl-dn2">'+clean(res.msg, '抚事不成')+'</div>';
            } else if (res.success) {
                box.innerHTML = '<div class="atl-dh"><span class="atl-dn">招抚成功</span><span class="atl-dt s0">抚</span></div>'
                  + '<div class="atl-dn2">'+clean('遣使抚谕，散其党羽，胁从归农。费帑 '+res.cost+' 两。','招抚已成')
                  + ' 此省怨望减三十，稳定 +5。</div>';
            } else {
                box.innerHTML = '<div class="atl-dh"><span class="atl-dn">抚而复叛</span><span class="atl-dt s2">叛</span></div>'
                  + '<div class="atl-dn2">'+clean('抚使至而众不受，反鼓其噪。费帑 '+res.cost+' 两。','抚事不成')+'</div>';
            }
            box.classList.add('on');
        } catch (e) {}
    };

    // ====== v8.3 舆图缩放平移 ======
    var ZOOM = { k: 1, x: 0, y: 0 };

    function atlApplyZoom() {
        try {
            var svg = document.querySelector('.atlas-svg');
            if (!svg) return;
            var k = Math.max(0.6, Math.min(4, ZOOM.k));
            ZOOM.k = k;
            // 以中心为基准变换
            var cx = 395, cy = 300;
            var tx = cx - (cx - ZOOM.x) * k;
            var ty = cy - (cy - ZOOM.y) * k;
            svg.setAttribute('viewBox', (-tx / k) + ' ' + (-ty / k) + ' ' + (790 / k) + ' ' + (600 / k));
            var zv = document.getElementById('atl-zv');
            if (zv) zv.textContent = Math.round(k * 100) + '%';
        } catch (e) {}
    }

    window.atlZoom = function (delta) {
        try {
            ZOOM.k = Math.max(0.6, Math.min(4, ZOOM.k + delta));
            atlApplyZoom();
        } catch (e) {}
    };
    window.atlZoomFit = function () {
        try {
            ZOOM = { k: 1, x: 0, y: 0 };
            var svg = document.querySelector('.atlas-svg');
            if (svg) svg.setAttribute('viewBox', '0 0 790 600');
            var zv = document.getElementById('atl-zv');
            if (zv) zv.textContent = '100%';
        } catch (e) {}
    };

    // 滚轮缩放 + 拖拽平移（事件委托，容忍重渲染）
    function atlBindZoom() {
        try {
            var stage = document.querySelector('.atlas-stage');
            if (!stage || stage._atlBound) return;
            stage._atlBound = true;
            stage.addEventListener('wheel', function (ev) {
                ev.preventDefault();
                ZOOM.k = Math.max(0.6, Math.min(4, ZOOM.k + (ev.deltaY < 0 ? 0.15 : -0.15)));
                atlApplyZoom();
            }, { passive: false });
            var dragging = false, sx0 = 0, sy0 = 0, ox = 0, oy = 0;
            stage.addEventListener('mousedown', function (ev) {
                if (ev.target.closest && ev.target.closest('.atl-p,.atl-ez,.atl-rb,.atl-mevnode,.atl-gnd,.atl-ghit')) return;
                dragging = true; sx0 = ev.clientX; sy0 = ev.clientY;
                ox = ZOOM.x; oy = ZOOM.y;
                stage.style.cursor = 'grabbing';
            });
            window.addEventListener('mousemove', function (ev) {
                if (!dragging) return;
                var svg = document.querySelector('.atlas-svg');
                if (!svg) return;
                var r = svg.getBoundingClientRect();
                var scale = 790 / (r.width / (ZOOM.k || 1));
                ZOOM.x = ox - (ev.clientX - sx0) / scale;
                ZOOM.y = oy - (ev.clientY - sy0) / scale;
                atlApplyZoom();
            });
            window.addEventListener('mouseup', function () {
                if (!dragging) return;
                dragging = false;
                var stage2 = document.querySelector('.atlas-stage');
                if (stage2) stage2.style.cursor = '';
            });
        } catch (e) {}
    }
    if (typeof document !== 'undefined') {
        document.addEventListener('DOMContentLoaded', atlBindZoom);
        setTimeout(atlBindZoom, 800);
    }

    window.atlRebelHover = function (rid) {
        try {
            if (typeof WAR === 'undefined') return;
            var w = WAR.state();
            var r = null;
            w.rebels.forEach(function (x) { if (x.id === rid) r = x; });
            if (!r) return;
            var tip = tipHost(); if (!tip) return;
            var rk2 = (typeof REBEL !== 'undefined' && REBEL.KINDS[r.kind]) ? REBEL.KINDS[r.kind] : null;
            tip.innerHTML = '<div class="atl-th">'+r.provNm+'·'+r.leader+'<i style="background:#8b2c1a">'+(rk2 ? rk2.nm : '叛乱')+'</i></div>'
              + '<div class="atl-ta">乱兵 '+num(r.troops,0)+' 人　士气 '+num(r.morale,0)+'</div>'
              + '<div class="atl-tn">'+r.leader+'据'+r.provNm+'自守，势渐张。点此可发兵平叛。</div>';
            place(tip); tip.classList.add('on');
        } catch (e) {}
    };

    window.renderAtlasTab = render;
    window.ATLAS_GC = GC;
    window.ATLAS_LIST = MING;
    window.ATLAS_GARRISONS = GARRISON;

    console.log('✓ v8.0 舆图·真实边界版已装载（19 布政使司 · 官方高精度省界）');
})();