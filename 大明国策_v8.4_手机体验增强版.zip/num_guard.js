// ============================================
// 《大明国策》v7.1 数值清洗层
// 铁律：界面上任何数字都不得出现 NaN / undefined / Infinity / 特殊符号
// 做法：全局兜底格式化 + 每季结算前把 stats 补齐
// ============================================

(function () {
    'use strict';
    if (window._v71SanitizeInstalled) return;
    window._v71SanitizeInstalled = true;

    // ---- 资源默认值（缺了就补 0，缺关键项补合理初值） ----
    var STAT_DEFAULTS = {
        treasury: 0, privyPurse: 0, food: 0, militaryFood: 0,
        gunpowder: 0, iron: 0, wood: 0, stone: 0, horses: 0,
        population: 0, stability: 50, prestige: 50,
        militaryPower: 0, navyPower: 0, mandate: 50,
        adminEfficiency: 30, corruption: 50, culture: 30, tech: 30,
        commerce: 30, agriculture: 30, canalEfficiency: 20, vassals: 0
    };

    // ---- 格式化：把任何脏值转成干净的中文数字串 ----
    // 返回 { n: 数字, s: 字符串 } 供模板直接取 s
    window.num = function (v, fallback) {
        var fb = (fallback === undefined) ? 0 : fallback;
        var n = (typeof v === 'number') ? v : parseFloat(v);
        if (!isFinite(n)) n = fb;
        return Math.round(n);
    };
    // 万两单位：超过 1 万显示"X.X万"
    window.numWan = function (v, fallback) {
        var n = window.num(v, fallback);
        var neg = n < 0;
        var a = Math.abs(n);
        if (a >= 10000) {
            return (neg ? '-' : '') + (a / 10000).toFixed(1) + '万';
        }
        return String(n);
    };
    // 纯文本清洗：清掉 NaN/undefined/null/∞ 与特殊符号
    window.clean = function (v, fallback) {
        var fb = (fallback === undefined || fallback === null) ? '—' : String(fallback);
        if (v === null || v === undefined) return fb;
        var s = String(v);
        if (s === 'NaN' || s.indexOf('NaN') >= 0) return fb;
        if (s === 'undefined' || s.indexOf('undefined') >= 0) return fb;
        if (s === 'Infinity' || s.indexOf('Infinity') >= 0) return fb;
        if (s.indexOf('null') >= 0) return fb;
        return s;
    };
    // 百分比
    window.pct = function (v, fallback) {
        var n = window.num(v, fallback);
        return Math.max(0, Math.min(100, n));
    };

    // ---- 补齐 GameState.stats 里所有数值字段 ----
    window.sanitizeStats = function () {
        try {
            if (typeof GameState === 'undefined' || !GameState) return;
            if (!GameState.stats) GameState.stats = {};
            var s = GameState.stats;
            for (var k in STAT_DEFAULTS) {
                if (!Object.prototype.hasOwnProperty.call(STAT_DEFAULTS, k)) continue;
                var v = s[k];
                var n = (typeof v === 'number') ? v : parseFloat(v);
                if (typeof n !== 'number' || !isFinite(n)) {
                    s[k] = STAT_DEFAULTS[k];
                }
            }
            // 派系
            if (!GameState.factions) GameState.factions = {};
            ['civil', 'military', 'royal', 'eunuch', 'consort'].forEach(function (f) {
                var fv = parseFloat(GameState.factions[f]);
                if (!isFinite(fv)) GameState.factions[f] = 50;
                else GameState.factions[f] = Math.max(0, Math.min(100, fv));
            });
            // 经济
            if (!GameState.econ) GameState.econ = {};
            if (!isFinite(parseFloat(GameState.econ.prosperity))) GameState.econ.prosperity = 50;
        } catch (e) {}
    };

    // ---- 全局兜底：拦截所有 innerHTML 写入，替换脏值 ----
    // 用 MutationObserver 太重，改用格式化函数 + 对已知脏点做定点替换
    function scrubText(t) {
        try {
            return t
                .replace(/>\s*(NaN|undefined|Infinity|null)\s*两</g, '>0两')
                .replace(/>\s*([+-]?)NaN\s*</g, '>$10<')
                .replace(/>\s*NaN\s*%/g, '>0%')
                .replace(/>\s*undefined\s*两</g, '>0两')
                .replace(/>\s*([+-]?)undefined\s*</g, '>$10<')
                .replace(/>\s*undefined\s*%/g, '>0%')
                .replace(/>\s*([+-]?)undefined\s*$/gm, '>$10')
                .replace(/>\s*NaN\s*$/gm, '>$10')
                .replace(/>\s*Infinity\s*</g, '>0<')
                .replace(/undefined两/g, '0两')
                .replace(/NaN两/g, '0两')
                .replace(/>(\s*)undefined(\s*)</g, '>$10<')
                .replace(/>(\s*)NaN(\s*)</g, '>$10<')
                .replace(/>(\s*)undefined\s*$/gm, '>$10')
                .replace(/>(\s*)NaN\s*$/gm, '>$10')
                .replace(/>(\s*)Infinity\s*$/gm, '>0')
                .replace(/\bundefined\b/g, '—')
                .replace(/\bNaN\b/g, '0')
                .replace(/\bInfinity\b/g, '0');
        } catch (e) { return t; }
    }

    // 挂到 Element.prototype.innerHTML setter 上太危险（会递归）
    // 改为包装最常用的几个写入点：panels
    function wrapPanelWrite() {
        try {
            var panelIds = ['center-panel', 'home-panel', 'home-mount', 'left-panel', 'right-panel'];
            panelIds.forEach(function (id) {
                var el = document.getElementById(id);
                if (!el || el.__v71Scrubbed) return;
                el.__v71Scrubbed = true;
                var mo = new MutationObserver(function (muts) {
                    muts.forEach(function (m) {
                        if (m.type === 'childList' && m.addedNodes.length) {
                            m.addedNodes.forEach(function (n) {
                                if (n.nodeType !== 1) return;
                                try {
                                    if (n.innerHTML && /NaN|undefined|Infinity/.test(n.innerHTML)) {
                                        var cleaned = scrubText(n.innerHTML);
                                        if (cleaned !== n.innerHTML) n.innerHTML = cleaned;
                                    }
                                    var txt = n.textContent || '';
                                    if (/NaN|undefined|Infinity/.test(txt)) {
                                        var ct = scrubText(txt);
                                        if (ct !== txt) n.textContent = ct;
                                    }
                                } catch (e) {}
                            });
                        }
                    });
                });
                mo.observe(el, { childList: true, subtree: true });
            });
        } catch (e) {}
    }

    // ---- 启动 ----
    function boot() {
        try {
            window.sanitizeStats();
            wrapPanelWrite();
        } catch (e) {}
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else { setTimeout(boot, 0); }

    // 每 500ms 检查一次 stats 是否被写脏
    var _iv = setInterval(function () {
        try { window.sanitizeStats(); } catch (e) {}
    }, 500);
    setTimeout(function () { clearInterval(_iv); }, 600000);

    console.log('✓ v7.1 数值清洗层已装载（NaN/undefined/∞ 归零）');
})();
