// ============================================
// 《大明国策》v8.3 数值审计台
// 把收支、战力、防御公式全部展开给玩家看
// 铁律：玩家有权知道钱去哪了、战力怎么算的
// ============================================

(function () {
    'use strict';
    if (window._v83Audit) return;
    window._v83Audit = true;

    // 注意：不可命名为 num（会覆盖全局 num 并自调用导致爆栈）
    function anum(v, fb) {
        var n = (typeof v === 'number') ? v : parseFloat(v);
        return isFinite(n) ? n : fb;
    }
    function n2(v) { return Math.round(anum(v, 0) * 100) / 100; }
    function pct(v) { return Math.round(anum(v, 0)) + '%'; }

    // ====== 1. 国库收支审计 ======
    function auditTreasury() {
        var rows = [];
        try {
            var s = GameState.stats;
            var inc = (typeof calculateIncome === 'function') ? calculateIncome() : { total: 0 };
            var exp = (typeof calculateExpense === 'function') ? calculateExpense() : { total: 0 };

            // 月入（按季入账 × 3）
            rows.push({ sec: '岁入（月）', nm: '田赋税银', v: inc.tax, note: '2400 × 贪腐折损 ' + pct(s.corruption) + ' × 吏治 ' + anum(s.adminEfficiency, 30) + '/50' });
            rows.push({ sec: '岁入（月）', nm: '漕粮折色', v: inc.caoyun, note: '漕运效率 ' + anum(s.canalEfficiency, 20) + '/50 × 市面折损' });
            rows.push({ sec: '岁入（月）', nm: '盐课', v: inc.salt, note: '商业 ' + anum(s.commerce, 30) + '/50' });
            rows.push({ sec: '岁入（月）', nm: '商税', v: inc.commerce, note: '商业 ' + anum(s.commerce, 30) + '/50 × 市面折损' });
            rows.push({ sec: '岁入（月）', nm: '市舶', v: inc.haigang, note: '开海则通商益盛' });

            rows.push({ sec: '岁出（月）', nm: '百官俸禄', v: -exp.salary, note: '常制' });
            rows.push({ sec: '岁出（月）', nm: '军费', v: -exp.military, note: '军力 ' + anum(s.militaryPower, 0) + ' × 0.5' });
            rows.push({ sec: '岁出（月）', nm: '宫廷用度', v: -exp.palace, note: '常制' });
            rows.push({ sec: '岁出（月）', nm: '营造修缮', v: -exp.construction, note: '常制' });
            rows.push({ sec: '岁出（月）', nm: '宗藩禄米', v: -exp.royal, note: '藩王岁禄，岁增' });
            rows.push({ sec: '岁出（月）', nm: '灾伤赈恤', v: -exp.relief, note: '稳定低于四十则加赈' });

            // 宗藩季支
            try {
                if (typeof zfTotalReward === 'function' && GameState.zongfan) {
                    var zr = zfTotalReward(GameState.zongfan);
                    rows.push({ sec: '岁出（季）', nm: '宗禄实支', v: -Math.floor(zr / 4), note: '占岁入 ' + pct(GameState.zongfan.fiefBurden * 100) + '（宗禄乃绞索）' });
                }
            } catch (e) {}

            // 营造
            try {
                if (typeof BUILD !== 'undefined') {
                    var up = 0, gin = 0, sin = 0;
                    BUILD.state().sites.forEach(function (s2) {
                        var t = BUILD.TYPES[s2.type];
                        if (!t) return;
                        up += t.up; gin += t.grain; sin += t.silver;
                    });
                    if (up) {
                        rows.push({ sec: '岁出（季）', nm: '诸处营造岁修', v: -up, note: '烽燧关隘卫所，岁修乃费' });
                        rows.push({ sec: '岁入（季）', nm: '市镇屯田所出', v: sin, note: '入银 ' + sin + ' 两，入粮 ' + gin + ' 石' });
                    }
                }
            } catch (e) {}

            var monthNet = inc.total - exp.total;
            return { rows: rows, inc: inc, exp: exp, monthNet: monthNet, treasury: anum(s.treasury, 0) };
        } catch (e) { return { rows: [], monthNet: 0, treasury: 0 }; }
    }

    // ====== 2. 战力审计 ======
    function auditPower() {
        try {
            var s = GameState.stats;
            var mil = (GameState.factions && GameState.factions.military) || 50;
            var mand = anum(s.mandate, 50);
            var out = [];
            out.push({ nm: '军力（百万之师）', v: anum(s.militaryPower, 0), note: '兵员总数' });
            out.push({ nm: '武将集团', v: mil, note: '派系值 / 100 → 士气 +' + Math.round(mil * 0.2) });
            out.push({ nm: '天命', v: mand, note: '统率士气基（58 + (统率-70)×0.4 + 军心×0.2）' });
            out.push({ nm: '军粮', v: anum(s.militaryFood, 0), note: '出征按兵数×月数耗' });
            out.push({ nm: '粮道折漕承压', v: -pct(anum(s.canalEfficiency, 20) < 20 ? 4 : 0), note: '漕运效率低于二十则每季折粮' });
            return out;
        } catch (e) { return []; }
    }

    // ====== 3. 防御系数审计（逐省） ======
    function auditDefense() {
        var rows = [];
        try {
            var list = (typeof ATLAS_LIST !== 'undefined') ? ATLAS_LIST : [];
            list.forEach(function (p) {
                var ter = (typeof WAR !== 'undefined') ? WAR.terrainOf(p.id) : { nm: '-', def: 1 };
                var city = (typeof WAR !== 'undefined') ? WAR.cityDefense(p.id) : 1;
                var mods = (typeof BUILD !== 'undefined') ? BUILD.provMods(p.id) : { defMul: 0, list: [] };
                rows.push({
                    id: p.id, nm: p.nm, ter: ter.nm, terDef: ter.def,
                    city: city, build: mods.defMul,
                    total: ter.def * city * (1 + mods.defMul)
                });
            });
            rows.sort(function (a, b) { return b.total - a.total; });
            return rows;
        } catch (e) { return []; }
    }

    // ====== 4. 战斗公式展开 ======
    function auditFormula() {
        try {
            var w = (typeof WAR !== 'undefined') ? WAR.state() : null;
            var lines = [];
            lines.push('【攻方战力】兵数 × 士气% × 补给% × 将领 × 兵种 × 火器加成 × 名将对敌加成');
            lines.push('【守方战力】兵数 × 士气% × 补给% × 地形防御 × 城防 × 营造加成');
            lines.push('【胜率】攻 ÷ (攻 + 守)，另有 ±12% 随机扰动，上下限 5%~95%');
            lines.push('【伤亡】胜方 8%~20%，败方 30%~60%');
            lines.push('');
            lines.push('【地形系数】');
            var T = (typeof WAR !== 'undefined') ? WAR.TERRAIN : {};
            Object.keys(T).forEach(function (k) {
                lines.push('　' + T[k].nm + '　守 ×' + T[k].def.toFixed(2) + '　攻 ×' + T[k].atk.toFixed(2) + '　' + T[k].desc);
            });
            return lines.join('\n');
        } catch (e) { return ''; }
    }

    // ====== 渲染面板 ======
    function renderAudit() {
        try {
            var h = '<div class="report-title">数值审计台 · 帐目与公式</div>';
            h += '<div class="report-summary">';
            var t = auditTreasury();
            h += '<div class="summary-item"><div class="summary-label">国库存银</div><div class="summary-value">' + n2(t.treasury) + ' 两</div></div>';
            h += '<div class="summary-item"><div class="summary-label">月入</div><div class="summary-value jade">+' + n2(t.inc.total) + '</div></div>';
            h += '<div class="summary-item"><div class="summary-label">月出</div><div class="summary-value ink">-' + n2(t.exp.total) + '</div></div>';
            h += '<div class="summary-item"><div class="summary-label">月净</div><div class="summary-value">' + (t.monthNet >= 0 ? '+' : '') + n2(t.monthNet) + '</div></div>';
            h += '</div>';

            h += '<h3 class="section-title">收支明细</h3><div class="finance-table">';
            var lastSec = '';
            t.rows.forEach(function (r) {
                if (r.sec !== lastSec) { h += '<div class="finance-sub">' + r.sec + '</div>'; lastSec = r.sec; }
                h += '<div class="finance-row">'
                    + '<span class="fr-label">' + r.nm + '<i class="fr-note">' + (r.note || '') + '</i></span>'
                    + '<span class="fr-value ' + (r.v >= 0 ? 'jade' : 'ink') + '">' + (r.v >= 0 ? '+' : '') + n2(r.v) + '</span>'
                    + '</div>';
            });
            h += '</div>';

            h += '<h3 class="section-title">战力构成</h3><div class="finance-table">';
            auditPower().forEach(function (r) {
                h += '<div class="finance-row"><span class="fr-label">' + r.nm + '<i class="fr-note">' + (r.note || '') + '</i></span>'
                    + '<span class="fr-value">' + n2(r.v) + '</span></div>';
            });
            h += '</div>';

            h += '<h3 class="section-title">各省防御系数（地形×城防×营造）</h3><div class="finance-table">';
            auditDefense().forEach(function (r) {
                h += '<div class="finance-row"><span class="fr-label">' + r.nm
                    + '<i class="fr-note">' + r.ter + ' ×' + r.terDef.toFixed(2)
                    + '　城防 ×' + r.city.toFixed(2)
                    + (r.build > 0 ? '　营造 +' + Math.round(r.build * 100) + '%' : '')
                    + '</i></span>'
                    + '<span class="fr-value">×' + r.total.toFixed(2) + '</span></div>';
            });
            h += '</div>';

            h += '<h3 class="section-title">攻防公式</h3>';
            h += '<pre class="audit-pre">' + auditFormula().replace(/[&<>]/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[c]; }) + '</pre>';
            return h;
        } catch (e) { return '<div class="report-title">数值审计台 · 出了岔子</div>'; }
    }

    // ====== 数值健康扫描（全表） ======
    function scan() {
        var bad = [];
        try {
            var s = GameState.stats;
            Object.keys(s).forEach(function (k) {
                var v = s[k];
                if (typeof v === 'number') {
                    if (!isFinite(v)) bad.push({ where: 'stats.' + k, v: String(v) });
                    else if (v < 0 && ['treasury', 'food', 'militaryFood', 'prestige', 'mandate', 'stability'].indexOf(k) < 0) {
                        bad.push({ where: 'stats.' + k, v: v });
                    }
                } else if (typeof v === 'string' && (v.indexOf('NaN') >= 0 || v.indexOf('undefined') >= 0 || v.indexOf('Infinity') >= 0)) {
                    bad.push({ where: 'stats.' + k, v: v });
                }
            });
            // 省份
            var box = (GameState.province && GameState.province.prov) ? GameState.province.prov : {};
            Object.keys(box).forEach(function (k) {
                Object.keys(box[k]).forEach(function (k2) {
                    var v = box[k][k2];
                    if (typeof v === 'number' && !isFinite(v)) bad.push({ where: 'prov.' + k + '.' + k2, v: String(v) });
                    if (typeof v === 'number' && (v < 0 || v > 100) && ['wealth','grain','arms','people','probity','disaffect'].indexOf(k2) >= 0) {
                        bad.push({ where: 'prov.' + k + '.' + k2, v: v });
                    }
                });
            });
            // 战争
            if (typeof WAR !== 'undefined') {
                var w = WAR.state();
                w.zones.forEach(function (z) {
                    if (!isFinite(anum(z.troops, 0))) bad.push({ where: 'war.zone.' + z.id + '.troops', v: z.troops });
                    if (anum(z.morale, 0) < 0 || anum(z.morale, 0) > 100) bad.push({ where: 'war.zone.' + z.id + '.morale', v: z.morale });
                });
                w.rebels.forEach(function (r) {
                    if (!isFinite(anum(r.troops, 0))) bad.push({ where: 'war.rebel.' + r.id + '.troops', v: r.troops });
                });
            }
        } catch (e) { bad.push({ where: 'scan', v: String(e && e.message) }); }
        return bad;
    }

    window.AUDIT = {
        render: renderAudit,
        treasury: auditTreasury,
        power: auditPower,
        defense: auditDefense,
        formula: auditFormula,
        scan: scan
    };

    console.log('✓ v8.3 数值审计台已装载');
})();
